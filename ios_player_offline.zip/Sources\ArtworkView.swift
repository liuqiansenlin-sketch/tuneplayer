// ArtworkView.swift
// 封面视图：优先用户自定义的专辑封面，其次是歌曲标签里的真实 ID3 封面，
// 否则显示由种子生成的稳定渐变 + 音符。先渲染占位，封面到达后自动淡入替换。
import SwiftUI
import UIKit

enum ArtworkSeed {
    /// 稳定哈希 → 0...1（渲染前确定性，同一文件永远同色）
    static func value(_ seed: String) -> Double {
        var hash: UInt64 = 1469598103934665603
        for scalar in seed.unicodeScalars {
            hash ^= UInt64(scalar.value)
            hash &*= 1099511628211
        }
        return Double(hash % 360) / 360.0
    }
}

struct ArtworkView: View {
    let url: URL?
    let seed: String
    let cornerRadius: CGFloat
    /// 若设置，优先显示该专辑的自定义封面
    let album: String?

    @State private var image: UIImage?

    private var hue: Double { ArtworkSeed.value(seed) }

    init(url: URL?, seed: String, cornerRadius: CGFloat, album: String? = nil) {
        self.url = url
        self.seed = seed
        self.cornerRadius = cornerRadius
        self.album = album
    }

    /// 任务标识：url / 专辑名 / 专辑封面版本号 任一变化都重新读取封面
    /// （Swift 元组不遵循 Equatable，必须拼成 String 才能用于 task(id:)）
    private var reloadKey: String {
        "\(url?.path ?? "")|\(album ?? "")|\(AlbumArtStore.shared.revision)"
    }

    var body: some View {
        ZStack {
            // 占位底：稳定色相渐变
            LinearGradient(
                colors: [
                    Color(hue: hue, saturation: 0.55, brightness: 0.78),
                    Color(hue: (hue + 0.12).truncatingRemainder(dividingBy: 1), saturation: 0.62, brightness: 0.42),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            // 找不到封面时的符号标识
            if image == nil {
                Image(systemName: "music.note")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.9))
            }

            // 真实封面（淡入）
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .transition(.opacity)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .stroke(Color.white.opacity(0.08), lineWidth: 0.5))
        .task(id: reloadKey) {
            // 先尝试用户为专辑设置的封面
            if let album, !album.isEmpty, let img = await AlbumArtStore.shared.image(for: album) {
                withAnimation(.easeIn(duration: 0.25)) {
                    image = img
                }
                return
            }
            // 回退到歌曲标签里的真实 ID3 封面
            guard let url else { return }
            let img: UIImage?
            if let cached = ArtworkStore.shared.cachedImage(for: url) {
                img = cached
            } else {
                img = await ArtworkStore.shared.image(for: url)
            }
            withAnimation(.easeIn(duration: 0.25)) {
                image = img
            }
        }
    }
}