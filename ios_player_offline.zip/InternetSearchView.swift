// InternetSearchView.swift
// 互联网免费音乐搜索：基于 Internet Archive（无需 API Key）
// 搜索结果下载后自动导入本地资料库
import SwiftUI

struct InternetSearchView: View {
    @StateObject private var searcher = InternetMusicSearcher()
    @State private var query = ""
    @EnvironmentObject var player: AudioPlayerModel

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 搜索框
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.55))
                    TextField("搜网络免费音乐（Internet Archive）", text: $query)
                        .foregroundStyle(.white)
                        .submitLabel(.search)
                        .onSubmit {
                            Task { await searcher.search(query) }
                        }
                    if !query.isEmpty {
                        Button { query = "" } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.white.opacity(0.5))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
                .frame(height: 44)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                .padding(.horizontal, 20)
                .padding(.top, 12)

                // 结果列表
                if searcher.isSearching {
                    ProgressView().padding()
                } else if let error = searcher.error {
                    VStack(spacing: 8) {
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundStyle(.red)
                            .font(.title2)
                        Text(error)
                            .foregroundStyle(.red)
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }
                    .padding()
                } else if searcher.results.isEmpty {
                    Text("输入关键词搜索互联网上的免费音乐\n（来源：Internet Archive）")
                        .foregroundStyle(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(searcher.results) { song in
                            InternetSongRow(song: song) {
                                await downloadAndImport(song)
                            }
                            .listRowBackground(Color.black)
                        }
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                }
            }
            .background(Color.black.ignoresSafeArea())
            .navigationTitle("互联网搜索")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    @MainActor
    private func downloadAndImport(_ song: InternetSong) async {
        searcher.downloadingID = song.id
        defer { searcher.downloadingID = nil }
        do {
            try await player.importInternetSong(song)
        } catch {
            searcher.error = "下载失败：\(error.localizedDescription)"
        }
    }
}

// MARK: - 歌曲行（含下载按钮）

struct InternetSongRow: View {
    let song: InternetSong
    let onDownload: () async -> Void
    @State private var isDownloading = false

    var body: some View {
        HStack(spacing: 12) {
            // 封面（Internet Archive 通常没有封面，用占位符）
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white.opacity(0.12))
                if isDownloading {
                    ProgressView()
                } else {
                    Image(systemName: "arrow.down.circle")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.red)
                }
            }
            .frame(width: 52, height: 52)

            VStack(alignment: .leading, spacing: 2) {
                Text(song.title)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(song.artist)
                    .font(.subheadline)
                    .foregroundStyle(.gray)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)

            if isDownloading {
                ProgressView()
                    .scaleEffect(0.7)
            } else {
                Button {
                    isDownloading = true
                    Task { await onDownload() }
                } label: {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.red)
                }
                .buttonStyle(.plain)
            }
        }
        .contentShape(Rectangle())
    }
}