// InternetMusicSearcher.swift
// 搜索互联网上免费可下载的音频（使用 Internet Archive，无需 API Key）
// 流程：高级搜索拿到候选列表 -> 取每个候选的 metadata -> 找到 mp3/ogg/flac 文件 -> 构造下载地址
import Foundation

enum InternetMusicError: Error {
    case invalidURL
    case networkError(Error)
    case decodeError(Error)
    case noResults
    case invalidResponse
}

@MainActor
final class InternetMusicSearcher: ObservableObject {
    @Published var results: [InternetSong] = []
    @Published var isSearching = false
    @Published var downloadingID: String?
    @Published var error: String?

    func search(_ keyword: String) async {
        let trimmed = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            results = []
            return
        }
        isSearching = true
        error = nil
        results = []

        // 1) 高级搜索（仅音频类型）
        var components = URLComponents(string: "https://archive.org/advancedsearch.php")!
        components.queryItems = [
            URLQueryItem(name: "q", value: "\(trimmed) AND mediatype:audio"),
            URLQueryItem(name: "output", value: "json"),
            URLQueryItem(name: "fl[]", value: "identifier"),
            URLQueryItem(name: "fl[]", value: "title"),
            URLQueryItem(name: "fl[]", value: "creator"),
            URLQueryItem(name: "fl[]", value: "duration"),
            URLQueryItem(name: "sort[]", value: "downloads desc"),
            URLQueryItem(name: "rows", value: "20"),
        ]
        guard let searchURL = components.url else {
            error = "构造搜索地址失败"
            isSearching = false
            return
        }

        do {
            let (data, response) = try await URLSession.shared.data(from: searchURL)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                error = "搜索服务返回异常"
                isSearching = false
                return
            }
            let root = try JSONDecoder().decode(InternetArchiveSearchResponse.self, from: data)
            let docs = root.response.docs

            // 2) 并发获取每个条目的 metadata，找到音频文件
            var songs: [InternetSong] = []
            await withTaskGroup(of: InternetSong?.self) { group in
                for doc in docs {
                    group.addTask { [weak self] in
                        await self?.fetchSong(from: doc)
                    }
                }
                for await song in group {
                    if let song { songs.append(song) }
                }
            }
            songs.sort { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
            self.results = songs
            if songs.isEmpty { self.error = "没有搜到可下载的免费音乐" }
        } catch {
            self.error = "搜索失败：\(error.localizedDescription)"
        }
        isSearching = false
    }

    /// 把某个搜索结果转换成可下载的歌曲（获取 metadata 找到音频文件）
    private func fetchSong(from doc: InternetArchiveSearchResponse.Doc) async -> InternetSong? {
        guard let identifier = doc.identifier else { return nil }
        guard let metadataURL = URL(string: "https://archive.org/metadata/\(identifier)") else { return nil }
        do {
            let (data, _) = try await URLSession.shared.data(from: metadataURL)
            let meta = try JSONDecoder().decode(InternetArchiveMetadata.self, from: data)
            let audioFiles = meta.files.filter { file in
                let name = (file.name ?? "").lowercased()
                return name.hasSuffix(".mp3") || name.hasSuffix(".ogg") || name.hasSuffix(".flac") || name.hasSuffix(".m4a")
            }
            guard let audio = audioFiles.first else { return nil }
            let audioURLString = "https://archive.org/download/\(identifier)/\(audio.name ?? "")"
            let folderURL = "https://archive.org/details/\(identifier)"
            let title = doc.title?.first ?? audio.title ?? identifier
            let artist = doc.creator?.first ?? "未知艺人"
            let duration = doc.duration?.first ?? audio.length ?? 0
            return InternetSong(
                id: identifier,
                title: title,
                artist: artist,
                album: nil,
                coverURL: nil,
                audioURL: audioURLString,
                duration: duration,
                sourceURL: folderURL
            )
        } catch {
            return nil
        }
    }
}

// MARK: - API 响应模型

private struct InternetArchiveSearchResponse: Codable {
    struct Doc: Codable {
        let identifier: String?
        let title: [String]?
        let creator: [String]?
        let duration: [Double]?
    }
    let response: Response
    struct Response: Codable {
        let docs: [Doc]
    }
}

private struct InternetArchiveMetadata: Codable {
    let files: [File]
    struct File: Codable {
        let name: String?
        let title: String?
        let length: TimeInterval?
    }
}