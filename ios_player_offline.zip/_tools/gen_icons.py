"""Generate the TunePlayer app icon (Apple Music-inspired, iOS full-bleed square)."""
from PIL import Image, ImageDraw, ImageFilter
import json
import os

OUT = r'C:\Users\afafaf\Documents\deepseek-harness\default-workspace\ios_player\Sources\Assets.xcassets\AppIcon.appiconset'
os.makedirs(OUT, exist_ok=True)

SZ = 1024

# ---------- 基底渐变：Apple Music 红渐变 ----------
base = Image.new('RGB', (SZ, SZ))
px = base.load()
for y in range(SZ):
    for x in range(SZ):
        t = y / (SZ - 1)
        # 顶部 #FC2E4E → 底部 #B3122F
        r = int(0xFC + (0xB3 - 0xFC) * t)
        g = int(0x2E + (0x12 - 0x2E) * t)
        b = int(0x4E + (0x2F - 0x4E) * t)
        # 左上角轻微提亮，中心偏左上 radial highlight
        dx, dy = x - SZ * 0.38, y - SZ * 0.28
        dist = (dx * dx + dy * dy) ** 0.5 / (SZ * 0.9)
        lighten = max(0.0, 1.0 - dist) ** 2 * 28
        # 顶部左右边缘加深（vignette）
        edge = abs(x / SZ - 0.5) * 2
        darken = (edge ** 2) * 18
        px[x, y] = (
            max(0, min(255, int(r + lighten - darken))),
            max(0, min(255, int(g + lighten * 0.4 - darken))),
            max(0, min(255, int(b + lighten * 0.6 - darken))),
        )

# ---------- 音符标志 ----------
def note_layer(draws_with_offset):
    """draw the beamed double-eighth-note glyph onto an RGBA layer"""
    layer = Image.new('RGBA', (SZ, SZ), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    head1 = (372, 660)
    head2 = (646, 610)
    stem_w = 46
    stem1_x = head1[0] + 64
    stem2_x = head2[0] + 64
    beam_top = 218
    beam_h = 76
    for off, fill in draws_with_offset:
        dx, dy = off
        # 茎
        d.rectangle([stem1_x + dx, beam_top + beam_h + dy - 8, stem1_x + stem_w + dx, head1[1] + dy + 6], fill=fill)
        d.rectangle([stem2_x + dx, beam_top + dy - 8, stem2_x + stem_w + dx, head2[1] + dy + 6], fill=fill)
        # 横梁（斜四边形）
        d.polygon([
            (stem1_x + dx, beam_top + dy),
            (stem2_x + stem_w + dx, beam_top - 42 + dy),
            (stem2_x + stem_w + dx, beam_top - 42 + beam_h + dy),
            (stem1_x + dx, beam_top + beam_h + dy),
        ], fill=fill)
        # 两个音头（倾斜椭圆）
        d.ellipse([head1[0] - 84 + dx, head1[1] - 60 + dy, head1[0] + 84 + dx, head1[1] + 60 + dy], fill=fill)
        d.ellipse([head2[0] - 84 + dx, head2[1] - 60 + dy, head2[0] + 84 + dx, head2[1] + 60 + dy], fill=fill)
    return layer

# 1) 阴影层（黑，模糊）
shadow = note_layer([((0, 18), (0, 0, 0, 120))])
shadow = shadow.filter(ImageFilter.GaussianBlur(14))
base_rgba = base.convert('RGBA')
base_rgba.alpha_composite(shadow)

# 2) 主音符层（白）
glyph = note_layer([((0, 0), (255, 255, 255, 255))])
base_rgba.alpha_composite(glyph)

icon = base_rgba.convert('RGB')
icon.save(os.path.join(OUT, 'icon-1024.png'), 'PNG')

# ---------- 派生尺寸 ----------
sizes = {
    'icon-40.png': 40,
    'icon-60.png': 60,
    'icon-58.png': 58,
    'icon-87.png': 87,
    'icon-80.png': 80,
    'icon-120-40.png': 120,
    'icon-120-60.png': 120,
    'icon-180.png': 180,
}
for name, s in sizes.items():
    icon.resize((s, s), Image.LANCZOS).save(os.path.join(OUT, name), 'PNG')

# ---------- Contents.json ----------
contents = {
    'images': [
        {'size': '20x20', 'idiom': 'iphone', 'filename': 'icon-40.png', 'scale': '2x'},
        {'size': '20x20', 'idiom': 'iphone', 'filename': 'icon-60.png', 'scale': '3x'},
        {'size': '29x29', 'idiom': 'iphone', 'filename': 'icon-58.png', 'scale': '2x'},
        {'size': '29x29', 'idiom': 'iphone', 'filename': 'icon-87.png', 'scale': '3x'},
        {'size': '40x40', 'idiom': 'iphone', 'filename': 'icon-80.png', 'scale': '2x'},
        {'size': '40x40', 'idiom': 'iphone', 'filename': 'icon-120-40.png', 'scale': '3x'},
        {'size': '60x60', 'idiom': 'iphone', 'filename': 'icon-120-60.png', 'scale': '2x'},
        {'size': '60x60', 'idiom': 'iphone', 'filename': 'icon-180.png', 'scale': '3x'},
        {'size': '1024x1024', 'idiom': 'ios-marketing', 'filename': 'icon-1024.png', 'scale': '1x'},
    ],
    'info': {'version': 1, 'author': 'xcode'},
}
with open(os.path.join(OUT, 'Contents.json'), 'w') as f:
    json.dump(contents, f, indent=2)

# Assets root Contents.json + empty AccentColor set not required; keep minimal asset catalog
with open(r'C:\Users\afafaf\Documents\deepseek-harness\default-workspace\ios_player\Sources\Assets.xcassets\Contents.json', 'w') as f:
    json.dump({'info': {'version': 1, 'author': 'xcode'}}, f)

# drag-us files into root directory check
print('wrote', len(os.listdir(OUT)), 'files to', OUT)
