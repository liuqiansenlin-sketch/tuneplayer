import glob
import sys

files = glob.glob(r'C:\Users\afafaf\Documents\deepseek-harness\default-workspace\ios_player\Sources\*.swift')
ok = True
for f in files:
    src = open(f, encoding='utf8').read()
    pairs = {')': '(', '}': '{', ']': '['}
    stack = []
    in_str = False
    esc = False
    line = 1
    i = 0
    err = None
    while i < len(src):
        ch = src[i]
        if ch == '\n':
            line += 1
            in_str = False
            esc = False
        elif in_str:
            if esc:
                esc = False
            elif ch == '\\':
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif src.startswith('//', i):
                while i < len(src) and src[i] != '\n':
                    i += 1
                continue
            elif ch in '([{':
                stack.append((ch, line))
            elif ch in ')]}':
                if not stack:
                    err = f'line {line}: extra {ch}'
                    break
                top, tl = stack.pop()
                if top != pairs[ch]:
                    err = f'line {line}: mismatch {top}(line {tl}) vs {ch}'
                    break
        i += 1
    if in_str:
        err = 'unterminated string'
    elif stack and not err:
        err = f'unclosed {stack[-1]}'
    name = f.rsplit('\\', 1)[-1]
    print(('OK ' if not err else 'ERR ') + name + ('' if not err else ' -> ' + err))
    ok = ok and not err
sys.exit(0 if ok else 1)
