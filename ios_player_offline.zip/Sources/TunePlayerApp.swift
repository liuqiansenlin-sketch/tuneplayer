// TunePlayerApp.swift
// 入口：暗色模式 + 注入 AudioPlayerModel 与 FavoritesStore
// 应用名/图标在 project.yml / Assets.xcassets 中配置
import SwiftUI

@main
struct TunePlayerApp: App {
    @StateObject private var player = AudioPlayerModel()
    @StateObject private var favorites = FavoritesStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
    }
}
