// InternetSong.swift
// 互联网搜索结果的歌曲模型（用于把网络上搜到的免费音乐下载后导入本地库）
import Foundation

struct InternetSong: Identifiable, Codable {
    let id: String
    let title: String
    let artist: String
    let album: String?
    let coverURL: String?
    let audioURL: String
    let duration: TimeInterval
}