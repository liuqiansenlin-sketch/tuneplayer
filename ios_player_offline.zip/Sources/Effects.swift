// Effects.swift
// 通用视觉/触觉特效组件（零第三方依赖）
//   - Haptics：轻/中/重触觉反馈
//   - PressableButtonStyle：按压缩放 + 触觉
//   - AudioSpectrumView：装饰性频谱柱（平滑随机包络，非麦克风采样）
//   - appearZoom()：全屏页进入时的缩放淡入
//   - breathing(_:)：封面播放时的呼吸缩放
import SwiftUI
import Combine
import UIKit

// MARK: - 触觉反馈

enum Haptics {
    static func light() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    static func medium() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
    static func heavy() {
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
    }
    static func selection() {
        UISelectionFeedbackGenerator().selectionChanged()
    }
}

// MARK: - 按压按钮样式

struct PressableButtonStyle: ButtonStyle {
    var scale: CGFloat = 0.92

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1.0)
            .opacity(configuration.isPressed ? 0.72 : 1.0)
            .animation(.spring(response: 0.24, dampingFraction: 0.7), value: configuration.isPressed)
            .onChange(of: configuration.isPressed) { pressed in
                if pressed { Haptics.light() }
            }
    }
}

// MARK: - 进入动画（全屏页缩放淡入）

private struct AppearZoomModifier: ViewModifier {
    @State private var appeared = false

    func body(content: Content) -> some View {
        content
            .scaleEffect(appeared ? 1.0 : 0.965)
            .opacity(appeared ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.28), value: appeared)
            .onAppear { appeared = true }
    }
}

extension View {
    func appearZoom() -> some View {
        modifier(AppearZoomModifier())
    }
}

// MARK: - 呼吸缩放（封面播放时）

private struct BreathingModifier: ViewModifier {
    let active: Bool
    @State private var expanded = false

    func body(content: Content) -> some View {
        content
            .scaleEffect(expanded ? 1.035 : 1.0)
            .animation(
                active
                    ? .easeInOut(duration: 2.2).repeatForever(autoreverses: true)
                    : .easeOut(duration: 0.3),
                value: expanded
            )
            .onAppear { if active { expanded = true } }
            .onChange(of: active) { isActive in
                expanded = isActive
            }
    }
}

extension View {
    func breathing(_ active: Bool) -> some View {
        modifier(BreathingModifier(active: active))
    }
}

// MARK: - 装饰性频谱

struct AudioSpectrumView: View {
    /// 播放中才跳动；暂停时缓慢回落
    var isActive: Bool
    var barCount: Int = 20
    var tint: Color = .red

    @State private var bars: [CGFloat]

    private let ticker = Timer.publish(every: 0.12, on: .main, in: .common).autoconnect()

    init(isActive: Bool, barCount: Int = 20, tint: Color = .red) {
        self.isActive = isActive
        self.barCount = barCount
        self.tint = tint
        _bars = State(initialValue: Array(repeating: 0.12, count: barCount))
    }

    var body: some View {
        HStack(alignment: .center, spacing: 3) {
            ForEach(bars.indices, id: \.self) { index in
                Capsule(style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [tint.opacity(0.95), tint.opacity(0.35)],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(width: 3, height: 36 * bars[index] + 3)
            }
        }
        .frame(height: 42)
        .animation(.easeOut(duration: 0.12), value: bars)
        .onReceive(ticker) { _ in
            updateBars()
        }
    }

    private func updateBars() {
        if isActive {
            bars = bars.map { old in
                let target = CGFloat.random(in: 0.12...1.0)
                let blended = old * 0.5 + target * 0.5
                return min(1.0, max(0.08, blended))
            }
        } else {
            bars = bars.map { old in
                max(0.08, old * 0.86)
            }
        }
    }
}

// MARK: - 全屏频谱背景（底部清晰，向上逐渐变模糊）

struct FullscreenSpectrumBackdrop: View {
    /// 播放中才跳动；暂停时缓慢回落
    var isActive: Bool
    var barCount: Int = 26
    var tint: Color = .red

    @State private var bars: [CGFloat]

    private let ticker = Timer.publish(every: 0.14, on: .main, in: .common).autoconnect()

    init(isActive: Bool, barCount: Int = 26, tint: Color = .red) {
        self.isActive = isActive
        self.barCount = barCount
        self.tint = tint
        _bars = State(initialValue: Array(repeating: 0.25, count: barCount))
    }

    var body: some View {
        GeometryReader { geo in
            let spacing: CGFloat = 4
            let barWidth = max(2, (geo.size.width - spacing * CGFloat(barCount + 1)) / CGFloat(barCount))
            VStack(spacing: 0) {
                Spacer(minLength: 0)
                HStack(alignment: .bottom, spacing: spacing) {
                    ForEach(bars.indices, id: \.self) { index in
                        Capsule(style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [tint.opacity(0.12), tint.opacity(0.85)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .frame(width: barWidth, height: max(6, bars[index] * geo.size.height))
                    }
                }
                .padding(.horizontal, spacing)
            }
        }
        .blur(radius: 2.5)
        .mask(
            LinearGradient(
                stops: [
                    Gradient.Stop(color: .white.opacity(0.0), location: 0.0),
                    Gradient.Stop(color: .white.opacity(0.35), location: 0.30),
                    Gradient.Stop(color: .white.opacity(0.85), location: 0.62),
                    Gradient.Stop(color: .white.opacity(1.0), location: 1.0)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
        )
        .animation(.easeOut(duration: 0.14), value: bars)
        .onReceive(ticker) { _ in
            if isActive {
                bars = bars.map { old in
                    let target = CGFloat.random(in: 0.18...1.0)
                    return min(1.0, max(0.08, old * 0.45 + target * 0.55))
                }
            } else {
                bars = bars.map { old in
                    max(0.08, old * 0.88)
                }
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - 原生磨砂渐变遮罩（底部无模糊 → 顶部完全磨砂）

struct FrostedFadeOverlay: View {
    var body: some View {
        ZStack {
            Rectangle()
                .fill(.ultraThinMaterial)
                .mask(
                    LinearGradient(
                        stops: [
                            Gradient.Stop(color: .clear, location: 0.0),
                            Gradient.Stop(color: .white.opacity(0.25), location: 0.42),
                            Gradient.Stop(color: .white.opacity(0.75), location: 0.75),
                            Gradient.Stop(color: .white, location: 1.0)
                        ],
                        startPoint: .bottom,
                        endPoint: .top
                    )
                )
            LinearGradient(
                colors: [.clear, Color(.systemBackground).opacity(0.9)],
                startPoint: .bottom,
                endPoint: .top
            )
            .mask(
                LinearGradient(
                    stops: [
                        Gradient.Stop(color: .clear, location: 0.0),
                        Gradient.Stop(color: .white.opacity(0.3), location: 0.55),
                        Gradient.Stop(color: .white, location: 0.95)
                    ],
                    startPoint: .bottom,
                    endPoint: .top
                )
            )
        }
        .allowsHitTesting(false)
    }
}
