// NowPlayingView.swift
// 全屏播放页
//   封面 = 用户自己给这首歌添加的照片 / 视频（右上角“添加封面”），否则用默认生成封面
//   顶部四个按钮：添加封面 / 收藏 / 队列 / 收起（平均分布、略靠右、不贴边）
//   任意位置下滑 = 回到资料库
import SwiftUI
import UIKit
import Photos
import PhotosUI
import UniformTypeIdentifiers

struct NowPlayingView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @Environment(\.dismiss) private var dismiss

    @State private var isDraggingSlider = false
    @State private var dragSeconds: TimeInterval = 0
    @State private var showQueue = false
    @State private var showCoverImporter = false
    @State private var pickedCoverItem: PhotosPickerItem?
    @State private var coverVersion = UUID()
    @State private var coverMessage: String?

    private var song: Song? { player.currentSong }

    private var isFavorite: Bool {
        if let url = song?.url { return favorites.isFavorite(url) }
        return false
    }

    private var shownSeconds: TimeInterval { isDraggingSlider ? dragSeconds : player.currentTime }
    private var totalSeconds: TimeInterval { max(player.duration, 1) }

    var body: some View {
        ZStack {
            backgroundGradient
                .ignoresSafeArea()

            VStack(spacing: 18) {
                topBar
                Spacer(minLength: 2)
                artwork
                    .frame(maxWidth: 330)
                    .shadow(color: .black.opacity(0.65), radius: 32, y: 18)
                songInfo
                progress
                controls
            }
        }
        .sheet(isPresented: $showQueue) {
            QueueView()
                .environmentObject(player)
        }
        .fileImporter(isPresented: $showCoverImporter,
                      allowedContentTypes: [.image, .movie],
                      allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first, let current = self.song else { return }
                do {
                    try CoverStore.importCover(from: url, for: current)
                    coverVersion = UUID()
                    coverMessage = nil
                } catch {
                    coverMessage = "添加封面失败：\(error.localizedDescription)"
                }
            case .failure(let error):
                coverMessage = "选择文件失败：\(error.localizedDescription)"
            }
        }
        // 从系统相册选中的封面
        .onChange(of: pickedCoverItem) { item in
            guard let item else { return }
            Task { await importPickedCover(item) }
        }
        // 页面内任意位置下滑返回
        .simultaneousGesture(
            DragGesture(minimumDistance: 25)
                .onEnded { value in
                    if value.translation.height > 90,
                       abs(value.translation.height) > abs(value.translation.width) {
                        dismiss()
                    }
                }
        )
        .id(song?.url)
    }

    /// 把相册里选中的照片/视频复制进来作为这首歌的封面
    @MainActor
    private func importPickedCover(_ item: PhotosPickerItem) async {
        guard let song else { return }
        do {
            guard let data = try await item.loadTransferable(type: Data.self) else {
                coverMessage = "读取照片失败"
                pickedCoverItem = nil
                return
            }
            let ext = item.supportedContentTypes.first?.preferredFilenameExtension ?? "jpg"
            let tempURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString + "." + ext)
            try data.write(to: tempURL, options: .atomic)
            defer { try? FileManager.default.removeItem(at: tempURL) }
            try CoverStore.importCover(from: tempURL, for: song)
            coverVersion = UUID()
            coverMessage = nil
        } catch {
            coverMessage = "添加封面失败：\(error.localizedDescription)"
        }
        pickedCoverItem = nil
    }

    // MARK: - 顶部四键

    private var topBar: some View {
        HStack(spacing: 14) {
            Spacer(minLength: 0)

            PhotosPicker(selection: $pickedCoverItem,
                         matching: .any(of: [.images, .videos])) {
                Image(systemName: "photo")
                    .font(.system(size: 17, weight: .semibold))
                    .overlay(alignment: .bottomTrailing) {
                        Image(systemName: "plus")
                            .font(.system(size: 9, weight: .black))
                            .offset(x: 6, y: 6)
                    }
                    .frame(width: 42, height: 42)
                    .contentShape(Circle())
                    .liquidGlassCircle()
                    .foregroundStyle(.white)
            }
            .accessibilityLabel("添加专辑照片")
            .contextMenu {
                Button {
                    showCoverImporter = true
                } label: {
                    Label("从文件选择照片/视频", systemImage: "folder")
                }
                if let song,
                   CoverStore.imageURL(for: song) != nil || CoverStore.videoURL(for: song) != nil {
                    Button(role: .destructive) {
                        CoverStore.removeCover(for: song)
                        coverVersion = UUID()
                    } label: {
                        Label("移除自定义封面", systemImage: "trash")
                    }
                }
            }

            Button {
                if let url = song?.url { favorites.toggleFavorite(url) }
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .font(.system(size: 17, weight: .semibold))
                    .frame(width: 42, height: 42)
                    .contentShape(Circle())
                    .liquidGlassCircle()
                    .foregroundStyle(isFavorite ? .red : .white)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("收藏")

            GlassIconButton(systemName: "list.bullet",
                            font: .system(size: 17, weight: .semibold),
                            size: 42,
                            action: { showQueue = true })

            GlassIconButton(systemName: "chevron.down",
                            font: .system(size: 17, weight: .semibold),
                            size: 42,
                            action: { dismiss() })
        }
        .padding(.leading, 18)
        .padding(.trailing, 24)
        .padding(.top, 6)
    }

    // MARK: - 封面（照片 / 视频 / 默认）

    @ViewBuilder private var artwork: some View {
        Group {
            if let song, let videoURL = CoverStore.videoURL(for: song) {
                LoopingVideoView(url: videoURL)
                    .aspectRatio(1, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            } else if let song,
                      let imageURL = CoverStore.imageURL(for: song),
                      let image = UIImage(contentsOfFile: imageURL.path) {
                Color.clear
                    .aspectRatio(1, contentMode: .fit)
                    .overlay(
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFill()
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            } else if let song {
                ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 14)
                    .aspectRatio(1, contentMode: .fit)
            } else {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white.opacity(0.06))
                    .aspectRatio(1, contentMode: .fit)
            }
        }
        .id(coverVersion)
        .contextMenu {
            if let song {
                Button(role: .destructive) {
                    CoverStore.removeCover(for: song)
                    coverVersion = UUID()
                } label: {
                    Label("移除自定义封面", systemImage: "trash")
                }
            }
        }
    }

    // MARK: - 歌曲信息

    private var songInfo: some View {
        VStack(spacing: 6) {
            Text(song?.title ?? "未选择歌曲")
                .font(.title2.weight(.bold))
                .foregroundStyle(.white)
                .lineLimit(2)
                .multilineTextAlignment(.center)
            Text(song?.artist ?? "未知艺人")
                .font(.body)
                .foregroundStyle(.gray)
                .lineLimit(1)

            if let coverMessage {
                Text(coverMessage)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(.horizontal, 26)
    }

    // MARK: - 进度条

    private var progress: some View {
        VStack(spacing: 2) {
            Slider(value: Binding(get: { shownSeconds },
                                  set: { dragSeconds = $0 }),
                   in: 0...totalSeconds,
                   onEditingChanged: { editing in
                       if editing { dragSeconds = player.currentTime }
                       isDraggingSlider = editing
                       if !editing { player.seek(to: dragSeconds) }
                   })
            .tint(.red)
            HStack {
                Text(formatTime(shownSeconds)).font(.caption.monospacedDigit()).foregroundStyle(.gray)
                Spacer()
                Text(formatTime(player.duration)).font(.caption.monospacedDigit()).foregroundStyle(.gray)
            }
        }
        .padding(.horizontal, 32)
    }

    // MARK: - 播放控制

    private var controls: some View {
        HStack(spacing: 14) {
            Button { player.toggleShuffle() } label: {
                Image(systemName: "shuffle")
                    .font(.system(size: 19, weight: .semibold))
                    .frame(width: 44, height: 44)
                    .contentShape(Circle())
                    .liquidGlassCircle()
                    .foregroundStyle(player.isShuffle ? .red : .white)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("随机播放")

            GlassIconButton(systemName: "backward.fill",
                            font: .system(size: 22, weight: .semibold),
                            size: 52,
                            action: { player.playPrevious() })
            GlassPrimaryButton(systemName: player.isPlaying ? "pause.fill" : "play.fill",
                               size: 46,
                               action: { player.togglePlayPause() })
            GlassIconButton(systemName: "forward.fill",
                            font: .system(size: 22, weight: .semibold),
                            size: 52,
                            action: { player.playNext() })

            Button { player.toggleRepeat() } label: {
                Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat")
                    .font(.system(size: 19, weight: .semibold))
                    .frame(width: 44, height: 44)
                    .contentShape(Circle())
                    .liquidGlassCircle()
                    .foregroundStyle(player.repeatMode == .none ? .white : .red)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("循环模式")
        }
        .padding(.bottom, 22)
    }

    private var backgroundGradient: some View {
        LinearGradient(colors: [
            Color(red: 0.30, green: 0.04, blue: 0.10),
            Color(red: 0.08, green: 0.02, blue: 0.04),
            Color.black,
        ], startPoint: .top, endPoint: .bottom)
    }

    private func formatTime(_ t: TimeInterval) -> String {
        guard t.isFinite, t >= 0 else { return "0:00" }
        let total = Int(t)
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
