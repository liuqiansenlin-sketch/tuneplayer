// NowPlayingView.swift
// 全屏播放页：Apple Music「动态专辑封面」风格
//   封面 = 同名动态视频（有则循环播放），否则 = 确定性流光 Canvas 兜底
//   控制键 = iOS 26 Liquid Glass 液态玻璃
import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @Environment(\.dismiss) private var dismiss
    @State private var isDraggingSlider = false
    @State private var dragSeconds: TimeInterval = 0
    @State private var showQueue = false

    private var song: Song? { player.currentSong }
    private var isFavorite: Bool {
        if let url = song?.url { return favorites.isFavorite(url) }
        return false
    }
    private var shownSeconds: TimeInterval { isDraggingSlider ? dragSeconds : player.currentTime }
    private var totalSeconds: TimeInterval { max(player.duration, 1) }

    var body: some View {
        ZStack {
            // 背景：与动态封面同色系的深色渐变 + 顶部氛围光
            backgroundGradient
                .ignoresSafeArea()

            VStack(spacing: 20) {
                // 顶部：收起把手 + 收起按钮（Liquid Glass）
                HStack {
                    Capsule()
                        .fill(Color.white.opacity(0.35))
                        .frame(width: 40, height: 5)
                    Spacer()
                    HStack(spacing: 10) {
                        // 收藏（Liquid Glass）
                        Button {
                            if let url = song?.url { favorites.toggleFavorite(url) }
                        } label: {
                            Image(systemName: isFavorite ? "heart.fill" : "heart")
                                .font(.system(size: 15, weight: .semibold))
                                .frame(width: 34, height: 34)
                                .contentShape(Circle())
                                .liquidGlassCircle()
                                .foregroundStyle(isFavorite ? .red : .white)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("收藏")

                        // 播放队列（Liquid Glass）
                        GlassIconButton(systemName: "play.square.stack",
                                        font: .system(size: 15, weight: .semibold),
                                        size: 34,
                                        action: { showQueue = true })

                        GlassIconButton(systemName: "chevron.down",
                                        font: .system(size: 14, weight: .semibold),
                                        size: 34,
                                        action: { dismiss() })
                    }
                }
                .padding(.horizontal, 18)
                .padding(.top, 10)

                Spacer(minLength: 4)

                // ── 核心：动态专辑封面 ─────────────────────────
                artwork
                    .frame(maxWidth: 330)
                    .shadow(color: .black.opacity(0.65), radius: 32, y: 18)

                // 歌曲信息
                VStack(spacing: 6) {
                    Text(song?.title ?? "未选择歌曲")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                        .multilineTextAlignment(.center)
                    Text(song?.artist ?? "未知艺人")
                        .font(.body)
                        .foregroundStyle(.gray)
                        .lineLimit(1)
                }
                .padding(.horizontal, 26)

                // 进度条
                VStack(spacing: 2) {
                    Slider(value: Binding(get: { shownSeconds },
                                          set: { dragSeconds = $0 }),
                           in: 0...totalSeconds,
                           onEditingChanged: { editing in
                               if editing { dragSeconds = player.currentTime }
                               isDraggingSlider = editing
                               if !editing { player.seek(to: dragSeconds) }
                           })
                    .tint(.red)
                    HStack {
                        Text(formatTime(shownSeconds)).font(.caption.monospacedDigit()).foregroundStyle(.gray)
                        Spacer()
                        Text(formatTime(player.duration)).font(.caption.monospacedDigit()).foregroundStyle(.gray)
                    }
                }
                .padding(.horizontal, 32)

                // ── Liquid Glass 控制键：随机播放 / 上一首 / 播放暂停 / 下一首 / 循环 ──
                HStack(spacing: 14) {
                    // 随机播放
                    Button { player.toggleShuffle() } label: {
                        Image(systemName: "shuffle")
                            .font(.system(size: 19, weight: .semibold))
                            .frame(width: 44, height: 44)
                            .contentShape(Circle())
                            .liquidGlassCircle()
                            .foregroundStyle(player.isShuffle ? .red : .white)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("随机播放")

                    GlassIconButton(systemName: "backward.fill",
                                    font: .system(size: 22, weight: .semibold),
                                    size: 52,
                                    action: { player.playPrevious() })
                    GlassPrimaryButton(systemName: player.isPlaying ? "pause.fill" : "play.fill",
                                       size: 46,
                                       action: { player.togglePlayPause() })
                    GlassIconButton(systemName: "forward.fill",
                                    font: .system(size: 22, weight: .semibold),
                                    size: 52,
                                    action: { player.playNext() })
                    // 循环：none → all → one
                    Button { player.toggleRepeat() } label: {
                        Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat")
                            .font(.system(size: 19, weight: .semibold))
                            .frame(width: 44, height: 44)
                            .contentShape(Circle())
                            .liquidGlassCircle()
                            .foregroundStyle(player.repeatMode == .none ? .white : .red)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("循环模式")
                }
                .padding(.bottom, 22)
            }
        }
        .sheet(isPresented: $showQueue) {
            QueueView()
                .environmentObject(player)
        }
        // 动态封面：歌曲换了立即重建（重新定位视频/噪声轨迹）
        .id(song?.url)
    }

    /// 动态专辑封面：视频优先，Canvas 兜底
    @ViewBuilder private var artwork: some View {
        if let videoURL = song?.videoURL {
            LoopingVideoView(url: videoURL)
                .aspectRatio(1, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.white.opacity(0.10), lineWidth: 0.5))
        } else {
            DynamicArtworkCanvas(seed: song?.url.path ?? "unknown")
                .aspectRatio(1, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.white.opacity(0.10), lineWidth: 0.5))
        }
    }

    private var backgroundGradient: some View {
        // 动态封面同色系的氛围背景（酒红 → 近黑 + 顶部柔光）
        LinearGradient(colors: [
            Color(red: 0.30, green: 0.04, blue: 0.10),
            Color(red: 0.08, green: 0.02, blue: 0.04),
            Color.black,
        ], startPoint: .top, endPoint: .bottom)
    }

    private func formatTime(_ t: TimeInterval) -> String {
        guard t.isFinite, t >= 0 else { return "0:00" }
        let total = Int(t)
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
