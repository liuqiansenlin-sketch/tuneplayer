// DynamicVideoResolver.swift
// Apple Music「动态专辑封面 / Motion Artwork」的本地实现：
// 为一首歌曲寻找循环播放的动态封面视频。
//
// 查找顺序（全部存在才采用，否则走 Canvas 动态视觉兜底）：
//  1. 与音频同目录同名文件： song.mp3 → song.mp4 / song.mov / song.m4v
//  2. Documents/Videos/同名文件：Documents/Videos/song.mp4 等
//  3. Documents/Videos/_default.mov|mp4|m4v（全局默认动态封面）
//
// 视频建议：H.264，竖屏 3:4/9:16 或方形 1:1，循环 5–20 秒；文件里不必包含声音。
import Foundation

enum DynamicVideoResolver {
    static let videoExtensions = ["mp4", "mov", "m4v"]

    static func videoURL(for songFileURL: URL) -> URL? {
        let base = songFileURL.deletingPathExtension()

        // 1) 与音频同目录同名
        for ext in videoExtensions {
            let candidate = base.appendingPathExtension(ext)
            if FileManager.default.fileExists(atPath: candidate.path) {
                return candidate
            }
        }

        // 2) ~ Documents/Videos/同名
        if let videos = videosFolderURL() {
            let name = base.lastPathComponent
            for ext in videoExtensions {
                let candidate = videos.appendingPathComponent("\(name).\(ext)")
                if FileManager.default.fileExists(atPath: candidate.path) {
                    return candidate
                }
            }
            // 3) ~ Documents/Videos/_default.*
            for ext in videoExtensions {
                let candidate = videos.appendingPathComponent("_default.\(ext)")
                if FileManager.default.fileExists(atPath: candidate.path) {
                    return candidate
                }
            }
        }
        return nil
    }

    /// 返回 Documents/Videos（并创建空目录，方便用户投放视频）
    static func videosFolderURL() -> URL? {
        guard let docs = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true) else {
            return nil
        }
        let videos = docs.appendingPathComponent("Videos", isDirectory: true)
        if !FileManager.default.fileExists(atPath: videos.path) {
            try? FileManager.default.createDirectory(at: videos, withIntermediateDirectories: true)
        }
        return videos
    }
}
