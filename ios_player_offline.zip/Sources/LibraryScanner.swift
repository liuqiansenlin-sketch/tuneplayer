// LibraryScanner.swift
// 从应用的 Documents/Music 文件夹递归扫描音频文件，
// 并用 AVFoundation 读取时长、标题、艺术家、专辑等标签。
import Foundation
import AVFoundation

enum LibraryScanner {
    static let supportedExtensions: Set<String> = ["mp3", "m4a", "aac", "flac", "wav", "alac"]

    /// 将音乐文件复制到应用 Documents/Music（供文件导入使用）
    @discardableResult
    static func importFile(from sourceURL: URL) throws -> URL {
        let folder = try musicFolderURL()
        let dest = folder.appendingPathComponent(sourceURL.lastPathComponent)
        // 文件会与已有时一起存放；若重名则覆盖
        if FileManager.default.fileExists(atPath: dest.path) {
            try FileManager.default.removeItem(at: dest)
        }
        // UIDocumentPicker 返回的是“安全域 URL”，需要访问权限
        let needSecurityStop = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if needSecurityStop { sourceURL.stopAccessingSecurityScopedResource() }
        }
        try FileManager.default.copyItem(at: sourceURL, to: dest)
        return dest
    }

    /// 返回（并创建）应用的 Documents/Music 文件夹
    static func musicFolderURL() throws -> URL {
        let docs = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let folder = docs.appendingPathComponent("Music", isDirectory: true)
        if !FileManager.default.fileExists(atPath: folder.path) {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        }
        return folder
    }

    /// 递归扫描并返回按标题排序的歌曲列表
    static func scan() async -> [Song] {
        guard let folder = try? musicFolderURL() else { return [] }
        var songs: [Song] = []
        let enumerator = FileManager.default.enumerator(at: folder,
                                                        includingPropertiesForKeys: nil,
                                                        options: [.skipsHiddenFiles])
        while let item = enumerator?.nextObject() as? URL {
            guard supportedExtensions.contains(item.pathExtension.lowercased()) else { continue }
            let song = await readMetadata(at: item)
            songs.append(song)
        }
        return songs.sorted { $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }
    }

    /// 单文件元数据读取（失败时退回文件名）
    private static func readMetadata(at url: URL) async -> Song {
        let asset = AVURLAsset(url: url)
        // 时长
        var duration: Double = 0
        if let loaded = try? await asset.load(.duration) {
            duration = CMTimeGetSeconds(loaded)
        }
        // 公共元数据：标题/艺术家/专辑（用 load 的异步属性，避免 commonMetadata 废弃警告）
        var title: String?
        var artist: String?
        var album: String?
        if let metadata = try? await asset.load(.commonMetadata) {
            for item in metadata {
                let keyRaw = item.commonKey?.rawValue
                guard let keyRaw, ["title", "artist", "albumName"].contains(keyRaw) else { continue }
                let raw = try? await item.load(.value)
                switch keyRaw {
                case "title": title = (raw as? String) ?? title
                case "artist": artist = (raw as? String) ?? artist
                case "albumName": album = (raw as? String) ?? album
                default: break
                }
            }
        }
        let finalTitle = repairMojibake((title?.isEmpty == false ? title! : (url.deletingPathExtension().lastPathComponent)))
        return Song(url: url, title: finalTitle, artist: repairMojibake(artist), album: repairMojibake(album), durationSeconds: duration, videoURL: videoURL)
    }

    /// 修复“UTF-8/GBK 字节被按 Latin-1 解码”造成的乱码（常见于国内 MP3 的 ID3 标签）
    /// 策略：先尝试 Latin-1→UTF-8 重解码；若无效再按 GB18030 重解码；都不行就原样返回
    private static func repairMojibake(_ input: String?) -> String? {
        guard let s = input, !s.isEmpty else { return input }
        // 含有中文字符说明解码正确，不需要修复
        if s.unicodeScalars.contains(where: { (0x4E00...0x9FFF).contains($0.value) }) { return s }
        // 统计“可疑”的高位 Latin-1 字符（0xC0–0xFF 连续出现是 UTF-8 被误解码的典型特征）
        let suspicious = s.unicodeScalars.filter { $0.value >= 0x80 }
        guard suspicious.count >= 2 else { return s }
        guard let bytes = s.data(using: .isoLatin1) ?? s.data(using: .windowsCP1252) else { return s }
        // 1) 按 UTF-8 重解码
        if let fixed = String(data: bytes, encoding: .utf8),
           fixed.unicodeScalars.contains(where: { (0x4E00...0x9FFF).contains($0.value) }) {
            return fixed
        }
        // 2) 按 GB18030（兼容 GBK）重解码
        let gbEnc = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000))
        if let fixed = String(data: bytes, encoding: gbEnc),
           fixed.unicodeScalars.contains(where: { (0x4E00...0x9FFF).contains($0.value) }) {
            return fixed
        }
        return s
    }
}
