// LibraryView.swift
// 资料库：Apple Music「资料库」标签页风格
//   大标题 + 顶部分段控制（歌曲 / 专辑 / 艺人 / 已收藏）+ 下方内容列表
import SwiftUI
import UniformTypeIdentifiers

// MARK: - 分类

enum LibraryCategory: String, CaseIterable, Identifiable {
    case songs, albums, artists, favorites

    var id: String { rawValue }

    var title: String {
        switch self {
        case .songs: return "歌曲"
        case .albums: return "专辑"
        case .artists: return "艺人"
        case .favorites: return "已收藏"
        }
    }
}

// MARK: - 资料库首页

struct LibraryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @State private var showImporter = false
    @State private var selectedCategory: LibraryCategory = .songs

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                categoryPicker

                Group {
                    if player.songs.isEmpty {
                        emptyState
                    } else {
                        categoryContent
                    }
                }
            }
            .navigationTitle("资料库")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [.audio],
                          allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls):
                    Task { await player.importMusic(from: urls) }
                case .failure(let error):
                    print("导入失败：\(error)")
                }
            }
            .refreshable { await player.loadLibrary() }
            .background(Color.black)
        }
        .task { await player.loadLibrary() }
    }

    // MARK: - 顶部分段控制（Apple Music 风格）

    private var categoryPicker: some View {
        Picker("分类", selection: $selectedCategory) {
            ForEach(LibraryCategory.allCases) { category in
                Text(category.title).tag(category)
            }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
        .tint(.red)
    }

    // MARK: - 各分类内容

    @ViewBuilder
    private var categoryContent: some View {
        switch selectedCategory {
        case .songs:
            songList(player.songs, ordered: true)
        case .favorites:
            let favorited = player.songs.filter { favorites.isFavorite($0.url) }
            if favorited.isEmpty {
                hint("没有收藏的歌曲\n在播放页点击心形图标即可收藏")
            } else {
                songList(favorited, ordered: false)
            }
        case .albums:
            let albums = Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty }).sorted()
            List(albums, id: \.self) { album in
                NavigationLink {
                    AlbumDetailView(album: album, songs: player.songs.filter { $0.album == album })
                        .environmentObject(player)
                        .environmentObject(favorites)
                } label: {
                    albumRow(title: album,
                             subtitle: "\(player.songs.filter { $0.album == album }.count) 首歌曲",
                             artworkURL: player.songs.first { $0.album == album }?.url,
                             symbol: "square.stack")
                }
                .listRowBackground(Color.black)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
        case .artists:
            let artists = Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty }).sorted()
            List(artists, id: \.self) { artist in
                NavigationLink {
                    ArtistDetailView(artist: artist, songs: player.songs.filter { $0.artist == artist })
                        .environmentObject(player)
                        .environmentObject(favorites)
                } label: {
                    albumRow(title: artist,
                             subtitle: "\(player.songs.filter { $0.artist == artist }.count) 首歌曲",
                             artworkURL: player.songs.first { $0.artist == artist }?.url,
                             symbol: "person.2.fill")
                }
                .listRowBackground(Color.black)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
        }
    }

    private func songList(_ songs: [Song], ordered: Bool) -> some View {
        List {
            ForEach(Array(songs.enumerated()), id: \.element.id) { index, song in
                SongRowView(song: song, visibleOrder: songs, position: ordered ? index + 1 : nil)
                    .environmentObject(player)
                    .environmentObject(favorites)
                    .listRowBackground(Color.black)
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
    }

    private func albumRow(title: String, subtitle: String, artworkURL: URL?, symbol: String) -> some View {
        HStack(spacing: 12) {
            Group {
                if let artworkURL {
                    ArtworkView(url: artworkURL, seed: artworkURL.path, cornerRadius: 5)
                } else {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.white.opacity(0.1))
                        .overlay(Image(systemName: symbol).foregroundStyle(.gray))
                }
            }
            .frame(width: 52, height: 52)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.gray)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 4)
    }

    private func hint(_ text: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "heart")
                .font(.system(size: 46))
                .foregroundStyle(.gray)
            Text(text)
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
