// LibraryView.swift
// 资料库：从 Documents/Music 扫描出的歌曲；支持点击播放、文件导入、收藏筛选
import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @State private var showImporter = false
    @State private var showFavoritesOnly = false

    private var filteredSongs: [Song] {
        showFavoritesOnly ? player.songs.filter { favorites.isFavorite($0.url) } : player.songs
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 顶部筛选：全部 / 已收藏
                Picker("筛选", selection: $showFavoritesOnly) {
                    Text("全部").tag(false)
                    Text("已收藏").tag(true)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16)
                .padding(.top, 4)
                .padding(.bottom, 6)

                if player.songs.isEmpty {
                    emptyState
                } else if filteredSongs.isEmpty {
                    favoritesEmptyState
                } else {
                    songList
                }
            }
            .navigationTitle("资料库")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: {
                        Image(systemName: "plus").frame(width: 30, height: 30)
                    }
                    .liquidGlassCapsule()
                    .foregroundStyle(.red)
                }
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [.audio],
                          allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls):
                    Task { await player.importMusic(from: urls) }
                case .failure(let error):
                    print("导入失败：\(error)")
                }
            }
            .refreshable { await player.loadLibrary() }
            .background(Color.black)
        }
        .task { await player.loadLibrary() }
    }

    private var songList: some View {
        List(filteredSongs) { song in
            HStack(spacing: 8) {
                // 点封面区域播放
                Button { player.playSong(song, in: filteredSongs) } label: {
                    HStack(spacing: 12) {
                        ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8)
                            .frame(width: 52, height: 52)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(song.title)
                                .font(.body.weight(.semibold))
                                .foregroundStyle(.white)
                                .lineLimit(1)
                            Text([song.artist, song.album].compactMap { $0 }.joined(separator: " · "))
                                .font(.subheadline)
                                .foregroundStyle(.gray)
                                .lineLimit(1)
                        }
                        Spacer(minLength: 0)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                // 爱心收藏
                Button {
                    favorites.toggleFavorite(song.url)
                } label: {
                    Image(systemName: favorites.isFavorite(song.url) ? "heart.fill" : "heart")
                        .font(.system(size: 18))
                        .foregroundStyle(.red)
                        .frame(width: 44, height: 44)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(favorites.isFavorite(song.url) ? "取消收藏" : "收藏")
            }
            .listRowBackground(Color.black)
        }
        .scrollContentBackground(.hidden)
        .listStyle(.plain)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var favoritesEmptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "heart")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("还没有收藏的歌")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点列表行右侧的 ♡ 给歌曲加收藏")
                .font(.subheadline)
                .foregroundStyle(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
