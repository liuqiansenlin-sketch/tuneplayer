// LibraryView.swift
// 资料库：Apple Music「资料库」标签页风格
//   大标题 + 顶部分段控制（歌曲 / 专辑 / 艺人 / 已收藏）+ 下方内容列表
import SwiftUI
import UniformTypeIdentifiers

// MARK: - 分类

enum LibraryCategory: String, CaseIterable, Identifiable {
    case songs, albums, artists, favorites

    var id: String { rawValue }

    var title: String {
        switch self {
        case .songs: return "歌曲"
        case .albums: return "专辑"
        case .artists: return "艺人"
        case .favorites: return "已收藏"
        }
    }
}

// MARK: - 资料库首页

struct LibraryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @State private var showImporter = false
    @State private var selectedCategory: LibraryCategory = .songs

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                categoryPicker
                Group {
                    if player.songs.isEmpty {
                        emptyState
                    } else {
                        categoryContent
                    }
                }
            }
            .navigationTitle("资料库")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .refreshable { await player.loadLibrary() }
            .background(Color(.systemBackground))
        }
        .task { await player.loadLibrary() }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [.audio],
                      allowsMultipleSelection: true) { result in
            if case .success(let urls) = result {
                Task { await player.importMusic(from: urls) }
            }
        }
    }

    // MARK: - 顶部分段控制（Apple Music 风格）

    private var categoryPicker: some View {
        Picker("分类", selection: $selectedCategory) {
            ForEach(LibraryCategory.allCases) { category in
                Text(category.title).tag(category)
            }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
        .tint(.red)
    }

    // MARK: - 各分类内容

    @ViewBuilder
    private var categoryContent: some View {
        switch selectedCategory {
        case .songs:
            songList(player.songs, ordered: true)
        case .favorites:
            let favorited = player.songs.filter { favorites.isFavorite($0.url) }
            if favorited.isEmpty {
                emptyFavoritesView
                    .frame(maxHeight: .infinity)
            } else {
                songList(favorited, ordered: false)
            }
        case .albums:
            let albums = Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty }).sorted()
            List {
                ForEach(albums, id: \.self) { album in
                    NavigationLink {
                        AlbumDetailView(album: album, songs: player.songs.filter { $0.album == album })
                            .environmentObject(player)
                            .environmentObject(favorites)
                    } label: {
                        HStack {
                            Image(systemName: "music.note")
                                .foregroundStyle(.blue)
                            Text(album)
                                .foregroundStyle(.primary)
                            Spacer()
                            Text("\(player.songs.filter { $0.album == album }.count) 首歌曲")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .listStyle(.plain)
            .listRowBackground(Color(.systemBackground))
            .scrollContentBackground(.hidden)
            .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
        case .artists:
            let artists = Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty }).sorted()
            List {
                ForEach(artists, id: \.self) { artist in
                    NavigationLink {
                        ArtistDetailView(artist: artist, songs: player.songs.filter { $0.artist == artist })
                            .environmentObject(player)
                            .environmentObject(favorites)
                    } label: {
                        HStack {
                            Image(systemName: "person.2.fill")
                                .foregroundStyle(.orange)
                            Text(artist)
                                .foregroundStyle(.primary)
                            Spacer()
                            Text("\(player.songs.filter { $0.artist == artist }.count) 首歌曲")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .listRowBackground(Color(.systemBackground))
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
        }
    }

    private func songList(_ songs: [Song], ordered: Bool) -> some View {
        List {
            ForEach(Array(songs.enumerated()), id: \.element.id) { index, song in
                SongRowView(song: song, visibleOrder: songs, position: ordered ? index + 1 : nil)
                    .environmentObject(player)
                    .environmentObject(favorites)
                    .listRowBackground(Color(.systemBackground))
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyFavoritesView: some View {
        VStack(spacing: 20) {
            Image(systemName: "heart")
                .font(.system(size: 48))
                .foregroundStyle(.secondary)
            Text("没有收藏的歌曲")
                .font(.title3.weight(.medium))
                .foregroundStyle(.primary)
            Text("在播放页点击心形图标即可收藏")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .listRowBackground(Color.clear)
        .frame(maxWidth: .infinity, minHeight: 200)
    }

    private var emptySongsView: some View {
        VStack(spacing: 20) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)
            Text("没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .listRowBackground(Color.clear)
        .frame(maxWidth: .infinity, minHeight: 200)
    }
}