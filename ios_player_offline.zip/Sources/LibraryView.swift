// LibraryView.swift
// 资料库（Apple Music「Library」）：歌曲 / 专辑 / 艺人 / 收藏 分段 + 大标题
import SwiftUI
import UniformTypeIdentifiers

enum LibraryCategory: String, CaseIterable, Identifiable {
    case songs, albums, artists, favorites

    var id: String { rawValue }

    var title: String {
        switch self {
        case .songs: return "歌曲"
        case .albums: return "专辑"
        case .artists: return "艺人"
        case .favorites: return "收藏"
        }
    }

    var icon: String {
        switch self {
        case .songs: return "music.note"
        case .albums: return "square.stack.fill"
        case .artists: return "person.2.fill"
        case .favorites: return "heart.fill"
        }
    }
}

struct LibraryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    @State private var showImporter = false
    @State private var selectedCategory: LibraryCategory = .songs

    private var albums: [String] {
        Array(Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })).sorted()
    }

    private var artists: [String] {
        Array(Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty })).sorted()
    }

    private var favoritedSongs: [Song] {
        player.songs.filter { favorites.isFavorite($0.url) }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                categoryChips
                Group {
                    if player.songs.isEmpty {
                        emptyState
                    } else {
                        categoryContent
                    }
                }
            }
            .navigationTitle("资料库")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: {
                        Image(systemImage: "plus")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .refreshable { await player.refreshLibrary() }
            .background(Color(.systemBackground))
        }
        .task { await player.refreshLibrary() }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [.audio],
                      allowsMultipleSelection: true) { result in
            if case .success(let urls) = result {
                Task { await player.importMusic(from: urls) }
            }
        }
    }

    // MARK: - 分类胶囊（Apple Music Library 风格）

    private var categoryChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(LibraryCategory.allCases) { category in
                    Button {
                        Haptics.selection()
                        selectedCategory = category
                    } label: {
                        HStack(spacing: 5) {
                            Image(systemName: category.icon)
                                .font(.system(size: 12, weight: .semibold))
                            Text(category.title)
                                .font(.subheadline.weight(.semibold))
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .foregroundStyle(selectedCategory == category ? Color.white : Color(.label))
                        .background(selectedCategory == category ? Color.red : Color(.systemGray6))
                        .clipShape(Capsule())
                    }
                    .buttonStyle(PressableButtonStyle(scale: 0.94))
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
    }

    // MARK: - 分类内容

    @ViewBuilder
    private var categoryContent: some View {
        switch selectedCategory {
        case .songs:
            songList(player.songs)
        case .favorites:
            if favoritedSongs.isEmpty {
                emptyFavorites
            } else {
                songList(favoritedSongs)
            }
        case .albums:
            albumGrid
        case .artists:
            artistList
        }
    }

    private func songList(_ songs: [Song]) -> some View {
        List {
            ForEach(songs) { song in
                SongRowView(song: song, visibleOrder: songs)
                    .environmentObject(player)
                    .environmentObject(favorites)
                    .listRowBackground(Color(.systemBackground))
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
    }

    private var albumGrid: some View {
        let columns = [
            GridItem(.flexible(), spacing: 12),
            GridItem(.flexible(), spacing: 12),
            GridItem(.flexible(), spacing: 12)
        ]
        return ScrollView {
            LazyVGrid(columns: columns, spacing: 18) {
                ForEach(albums, id: \.self) { album in
                    NavigationLink {
                        AlbumDetailView(album: album,
                                        songs: player.songs.filter { $0.album == album })
                    } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            AlbumArtworkThumb(album: album, side: 0)
                                .aspectRatio(1, contentMode: .fit)
                            Text(album)
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(.primary)
                                .lineLimit(2)
                            Text("\(player.songs.filter { $0.album == album }.count) 首歌曲")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(16)
        }
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
    }

    private var artistList: some View {
        List {
            ForEach(artists, id: \.self) { artist in
                NavigationLink {
                    ArtistDetailView(artist: artist, songs: player.songs.filter { $0.artist == artist })
                        .environmentObject(player)
                        .environmentObject(favorites)
                } label: {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(Color(.systemGray5))
                            Image(systemName: "person.fill")
                                .foregroundStyle(.secondary)
                        }
                        .frame(width: 44, height: 44)
                        Text(artist)
                            .foregroundStyle(.primary)
                        Spacer()
                        Text("\(player.songs.filter { $0.artist == artist }.count) 首歌曲")
                            .foregroundStyle(.secondary)
                    }
                }
                .listRowBackground(Color(.systemBackground))
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
    }

    // MARK: - 空状态

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer(minLength: 40)
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
            Spacer(minLength: 40)
        }
        .frame(maxWidth: .infinity)
    }

    private var emptyFavorites: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "heart")
                .font(.system(size: 48))
                .foregroundStyle(.secondary)
            Text("没有收藏的歌曲")
                .font(.title3.weight(.medium))
                .foregroundStyle(.primary)
            Text("在播放页点击心形图标即可收藏")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Spacer()
        }
        .frame(maxWidth: .infinity)
    }
}
