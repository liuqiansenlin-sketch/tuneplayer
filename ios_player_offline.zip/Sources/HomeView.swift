// HomeView.swift
// 首页（Apple Music「Home」）：最近播放 + 你的专辑 + 收藏歌曲
import SwiftUI
import UniformTypeIdentifiers

struct HomeView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @ObservedObject private var history = HistoryStore.shared

    @State private var showImporter = false

    private var favoritedSongs: [Song] {
        player.songs.filter { favorites.isFavorite($0.url) }
    }

    private var albums: [String] {
        Array(Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })).sorted()
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    if player.songs.isEmpty {
                        emptyState
                    } else {
                        recentlyPlayedSection
                        albumsSection
                        if !favoritedSongs.isEmpty {
                            favoritesSection
                        }
                    }
                }
                .padding(.top, 8)
                .padding(.bottom, 90) // 给悬浮迷你播放器留空间
            }
            .navigationTitle("首页")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .refreshable { await player.refreshLibrary() }
            .task { await player.refreshLibrary() }
            .background(Color(.systemBackground))
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [.audio],
                      allowsMultipleSelection: true) { result in
            if case .success(let urls) = result {
                Task { await player.importMusic(from: urls) }
            }
        }
    }

    // MARK: - 最近播放（横向卡片）

    private var recentlyPlayedSection: some View {
        let recent = history.recentSongs(from: player.songs, limit: 20)
        return VStack(alignment: .leading, spacing: 10) {
            sectionTitle("最近播放")
            if recent.isEmpty {
                Text("还没有播放记录，点一首歌开始听吧")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 16)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 14) {
                        ForEach(recent) { song in
                            recentCard(song)
                        }
                    }
                    .padding(.horizontal, 16)
                }
            }
        }
    }

    private func recentCard(_ song: Song) -> some View {
        Button {
            Haptics.light()
            player.playSong(song, in: history.recentSongs(from: player.songs, limit: 50))
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 12, album: song.album)
                    .frame(width: 150, height: 150)
                    .shadow(color: .black.opacity(0.25), radius: 8, y: 4)
                Text(song.title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(song.artist ?? "未知艺人")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            .frame(width: 150, alignment: .leading)
        }
        .buttonStyle(PressableButtonStyle(scale: 0.95))
    }

    // MARK: - 你的专辑（横向卡片）

    private var albumsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("你的专辑")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(albums, id: \.self) { album in
                        NavigationLink {
                            AlbumDetailView(album: album,
                                            songs: player.songs.filter { $0.album == album })
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                AlbumArtworkThumb(album: album, side: 150)
                                Text(album)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                Text("\(player.songs.filter { $0.album == album }.count) 首歌曲")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(width: 150, alignment: .leading)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    // MARK: - 收藏（横向卡片）

    private var favoritesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("收藏")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(favoritedSongs) { song in
                        Button {
                            Haptics.light()
                            player.playSong(song, in: favoritedSongs)
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 12, album: song.album)
                                    .frame(width: 150, height: 150)
                                Text(song.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                Text(song.artist ?? "未知艺人")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            .frame(width: 150, alignment: .leading)
                        }
                        .buttonStyle(PressableButtonStyle(scale: 0.95))
                    }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    // MARK: - 通用小件

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.title2.weight(.bold))
            .foregroundStyle(.primary)
            .padding(.horizontal, 16)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer(minLength: 40)
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
            Spacer(minLength: 40)
        }
        .frame(maxWidth: .infinity)
    }
}
