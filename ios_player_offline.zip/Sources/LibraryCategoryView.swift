// LibraryCategoryView.swift
// 资料库分类详情页：albums / artists / favorites
import SwiftUI
import UniformTypeIdentifiers

struct LibraryCategoryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let category: LibraryCategory

    var body: some View {
        List {
            switch category {
            case .albums:
                albumsSection
            case .artists:
                artistsSection
            case .favorites:
                favoritesSection
            case .songs:
                songsSection
            }
        }
        .navigationTitle(category.title)
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(Color.black)
    }

    private var albumsSection: some View {
        let albums = Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })
            .sorted()
        return ForEach(albums, id: \.self) { album in
            NavigationLink {
                AlbumDetailView(album: album, songs: player.songs.filter { $0.album == album })
                    .environmentObject(player)
                    .environmentObject(favorites)
            } label: {
                HStack {
                    Image(systemName: "music.note")
                        .foregroundStyle(.blue)
                    Text(album)
                        .foregroundStyle(.white)
                    Spacer()
                    Text("\(player.songs.filter { $0.album == album }.count)")
                        .foregroundStyle(.gray)
                }
            }
        }
    }

    private var artistsSection: some View {
        let artists = Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty })
            .sorted()
        return ForEach(artists, id: \.self) { artist in
            NavigationLink {
                ArtistDetailView(artist: artist, songs: player.songs.filter { $0.artist == artist })
                    .environmentObject(player)
                    .environmentObject(favorites)
            } label: {
                HStack {
                    Image(systemName: "person.2.fill")
                        .foregroundStyle(.orange)
                    Text(artist)
                        .foregroundStyle(.white)
                    Spacer()
                    Text("\(player.songs.filter { $0.artist == artist }.count)")
                        .foregroundStyle(.gray)
                }
            }
        }
    }

    private var favoritesSection: some View {
        let favoritedSongs = player.songs.filter { favorites.isFavorite($0.url) }
        if favoritedSongs.isEmpty {
            return AnyView(emptyFavoritesView)
        }
        return AnyView(
            ForEach(favoritedSongs) { song in
                SongRowView(song: song, visibleOrder: favoritedSongs)
                    .environmentObject(player)
                    .environmentObject(favorites)
            }
        )
    }

    private var songsSection: some View {
        let songs = player.songs
        if songs.isEmpty {
            return AnyView(emptySongsView)
        }
        return AnyView(
            ForEach(songs) { song in
                SongRowView(song: song, visibleOrder: songs)
                    .environmentObject(player)
                    .environmentObject(favorites)
            }
        )
    }

    private var emptyFavoritesView: some View {
        VStack(spacing: 20) {
            Image(systemName: "heart")
                .font(.system(size: 48))
                .foregroundStyle(.gray)
            Text("没有收藏的歌曲")
                .font(.title3.weight(.medium))
                .foregroundStyle(.white)
            Text("在播放页点击心形图标即可收藏")
                .font(.subheadline)
                .foregroundStyle(.gray)
        }
        .listRowBackground(Color.clear)
        .frame(maxWidth: .infinity, minHeight: 200)
    }

    private var emptySongsView: some View {
        VStack(spacing: 20) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
        }
        .listRowBackground(Color.clear)
        .frame(maxWidth: .infinity, minHeight: 200)
    }
}

// MARK: - AlbumDetailView
struct AlbumDetailView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let album: String
    let songs: [Song]

    var body: some View {
        List {
            Section {
                ForEach(songs) { song in
                    SongRowView(song: song, visibleOrder: songs)
                        .environmentObject(player)
                        .environmentObject(favorites)
                }
            } header: {
                HStack {
                    Image(systemName: "square.stack")
                        .foregroundStyle(.blue)
                    Text(album)
                        .font(.headline)
                        .foregroundStyle(.white)
                }
            }
        }
        .navigationTitle(album)
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(Color.black)
    }
}

// MARK: - ArtistDetailView
struct ArtistDetailView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let artist: String
    let songs: [Song]

    var body: some View {
        List {
            Section {
                ForEach(songs) { song in
                    SongRowView(song: song, visibleOrder: songs)
                        .environmentObject(player)
                        .environmentObject(favorites)
                }
            } header: {
                HStack {
                    Image(systemName: "person.2.fill")
                        .foregroundStyle(.orange)
                    Text(artist)
                        .font(.headline)
                        .foregroundStyle(.white)
                }
            }
        }
        .navigationTitle(artist)
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(Color.black)
    }
}

// MARK: - SongRowView
struct SongRowView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let song: Song
    let visibleOrder: [Song]

    private var isFavorite: Bool {
        favorites.isFavorite(song.url)
    }

    var body: some View {
        Button {
            player.playSong(song, in: visibleOrder)
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "music.note")
                    .foregroundStyle(.gray)
                    .frame(width: 28)

                VStack(alignment: .leading, spacing: 3) {
                    Text(song.title)
                        .font(.body.weight(.medium))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                    HStack {
                        Text(song.artist ?? "")
                            .font(.caption)
                            .foregroundStyle(.gray)
                            .lineLimit(1)
                        Spacer()
                        Text(song.formattedDuration)
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.gray)
                    }
                }

                Button {
                    favorites.toggleFavorite(song.url)
                } label: {
                    Image(systemName: isFavorite ? "heart.fill" : "heart")
                        .foregroundStyle(isFavorite ? .red : .gray)
                }
                .buttonStyle(.plain)
            }
            .padding(.vertical, 4)
        }
        .listRowBackground(Color.clear)
        .buttonStyle(.plain)
    }
}
