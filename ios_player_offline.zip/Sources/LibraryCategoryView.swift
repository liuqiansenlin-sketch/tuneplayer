// LibraryCategoryView.swift
// 资料库子视图：AlbumArtworkThumb / AlbumDetailView / ArtistDetailView / SongRowView
// Apple Music 风格：专辑详情页头部大封面 + "播放 / 随机播放" 红胶囊按钮 + 歌曲列表
import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - 专辑封面缩略图（自动读取 Documents/Covers/Albums/<乐团>.jpg）

struct AlbumArtworkThumb: View {
    let album: String
    var side: CGFloat = 150

    @State private var image: UIImage?

    private var reloadKey: String { "\(album)|\(AlbumArtStore.shared.revision)" }

    private var hue: Double { ArtworkSeed.value(album) }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(hue: hue, saturation: 0.55, brightness: 0.78),
                    Color(hue: (hue + 0.12).truncatingRemainder(dividingBy: 1), saturation: 0.62, brightness: 0.42),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            if image == nil {
                Image(systemName: "square.stack.fill")
                    .font(.system(size: side > 60 ? 34 : 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }

            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
            .stroke(Color.glassHighlight(0.08), lineWidth: 0.5))
        .task(id: reloadKey) {
            image = await AlbumArtStore.shared.image(for: album)
        }
        .modifier(FlexibleSquareFrame(side: side))
    }
}

/// side > 0 → 固定正方形；side == 0 → 按可用宽度保持正方形
private struct FlexibleSquareFrame: ViewModifier {
    let side: CGFloat

    @ViewBuilder
    func body(content: Content) -> some View {
        if side > 0 {
            content.frame(width: side, height: side)
        } else {
            content.aspectRatio(1, contentMode: .fit)
        }
    }
}

// MARK: - 专辑详情页（Apple Music Album 风格）

struct AlbumDetailView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    let album: String
    let songs: [Song]

    private var totalDuration: TimeInterval {
        songs.reduce(0) { $0 + $1.durationSeconds }
    }

    private var artists: String {
        Array(Set(songs.compactMap { $0.artist }.filter { !$0.isEmpty })).sorted().joined(separator: " / ")
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                // 头部：大封面 + 专辑信息 + 播放按钮
                HStack(alignment: .top, spacing: 16) {
                    AlbumArtworkThumb(album: album, side: 170)
                        .shadow(color: .black.opacity(0.3), radius: 12, y: 6)

                    VStack(alignment: .leading, spacing: 6) {
                        Text("专辑")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(album)
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.primary)
                            .lineLimit(3)
                        if !artists.isEmpty {
                            Text(artists)
                                .font(.headline)
                                .foregroundStyle(.red)
                                .lineLimit(1)
                        }
                        Text("\(songs.count) 首歌曲 · \(formatTime(totalDuration))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .padding(16)

                HStack(spacing: 10) {
                    Button {
                        Haptics.medium()
                        if let first = songs.first {
                            player.playSong(first, in: songs)
                        }
                    } label: {
                        Label("播放", systemImage: "play.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color.red)
                            .foregroundStyle(.white)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(PressableButtonStyle(scale: 0.95))

                    Button {
                        Haptics.medium()
                        let shuffled = songs.shuffled()
                        if let first = shuffled.first {
                            player.playSong(first, in: shuffled)
                        }
                    } label: {
                        Label("随机播放", systemImage: "shuffle")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color(.systemGray6))
                            .foregroundStyle(.primary)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(PressableButtonStyle(scale: 0.95))
                }
                .padding(.horizontal, 16)

                Divider().padding(.horizontal, 16)

                // 曲目列表
                VStack(spacing: 0) {
                    ForEach(songs) { song in
                        SongRowView(song: song, visibleOrder: songs)
                            .environmentObject(player)
                            .environmentObject(favorites)
                        Divider().padding(.leading, 74)
                    }
                }
                .padding(.bottom, 120)
            }
        }
        .navigationTitle(album)
        .navigationBarTitleDisplayMode(.inline)
        .background(Color(.systemBackground))
    }

    private func formatTime(_ seconds: TimeInterval) -> String {
        let total = Int(seconds.rounded())
        let m = total / 60
        let s = total % 60
        return String(format: "%d:%02d", m, s)
    }
}

// MARK: - 艺人详情页

struct ArtistDetailView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    let artist: String
    let songs: [Song]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(
                                colors: [Color(hue: ArtworkSeed.value(artist), saturation: 0.5, brightness: 0.72),
                                         Color(hue: ArtworkSeed.value(artist), saturation: 0.6, brightness: 0.38)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing))
                        Image(systemName: "person.fill")
                            .font(.system(size: 44, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    .frame(width: 110, height: 110)

                    VStack(alignment: .leading, spacing: 6) {
                        Text("艺人")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(artist)
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.primary)
                            .lineLimit(2)
                        Text("\(songs.count) 首歌曲")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .padding(16)

                Button {
                    Haptics.medium()
                    if let first = songs.first {
                        player.playSong(first, in: songs)
                    }
                } label: {
                    Label("播放", systemImage: "play.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.red)
                        .foregroundStyle(.white)
                        .clipShape(Capsule())
                }
                .buttonStyle(PressableButtonStyle(scale: 0.96))
                .padding(.horizontal, 16)

                Divider().padding(.horizontal, 16)

                VStack(spacing: 0) {
                    ForEach(songs) { song in
                        SongRowView(song: song, visibleOrder: songs)
                            .environmentObject(player)
                            .environmentObject(favorites)
                        Divider().padding(.leading, 74)
                    }
                }
                .padding(.bottom, 120)
            }
        }
        .navigationTitle(artist)
        .navigationBarTitleDisplayMode(.inline)
        .background(Color(.systemBackground))
    }
}

// MARK: - 歌曲行（Apple Music 风格：封面 + 标题/艺人 + 时长 + 当前播放指示）

struct SongRowView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    let song: Song
    let visibleOrder: [Song]

    @State private var showingEditSheet = false

    private var isPlayingThis: Bool { player.currentSong?.url == song.url }
    private var isFavorite: Bool { favorites.isFavorite(song.url) }

    var body: some View {
        Button {
            Haptics.light()
            player.playSong(song, in: visibleOrder)
        } label: {
            HStack(spacing: 12) {
                ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8, album: song.album)
                    .frame(width: 46, height: 46)
                VStack(alignment: .leading, spacing: 2) {
                    Text(song.title)
                        .font(.body.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(song.artist ?? "未知艺人")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
                if isPlayingThis {
                    Image(systemName: "speaker.wave.2.fill")
                        .font(.system(size: 14))
                        .foregroundStyle(.red)
                }
                Text(song.formattedDuration)
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button {
                player.insertSongAfterCurrent(song)
            } label: {
                Label("插播", systemImage: "text.insert")
            }
            Button {
                player.addToQueue(song)
            } label: {
                Label("加入队列", systemImage: "text.badge.plus")
            }
            Button {
                favorites.toggleFavorite(song.url)
            } label: {
                Label(isFavorite ? "取消收藏" : "收藏", systemImage: isFavorite ? "heart.slash" : "heart")
            }
            Button {
                showingEditSheet = true
            } label: {
                Label("编辑信息", systemImage: "pencil")
            }
            Button(role: .destructive) {
                player.deleteSong(song)
            } label: {
                Label("删除", systemImage: "trash")
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            SongEditSheet(song: song)
                .environmentObject(player)
        }
    }
}
