// SongEditSheet.swift
// 编辑歌曲：导入动态视频（循环封面视频）
// 用 .sheet 呈现
import SwiftUI
import UniformTypeIdentifiers

struct SongEditSheet: View {
    @Environment(\.dismiss) private var dismiss

    let song: Song

    @State private var showVideoImporter = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Button {
                        showVideoImporter = true
                    } label: {
                        Label("导入动态视频", systemImage: "video")
                    }
                }
            }
            .navigationTitle("编辑歌曲")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
            .fileImporter(isPresented: $showVideoImporter,
                          allowedContentTypes: [.movie, .video],
                          allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    do {
                        try CoverStore.importCover(from: url, for: song)
                    } catch {
                        print("导入动态视频失败：\(error)")
                    }
                case .failure(let error):
                    print("选择视频失败：\(error)")
                }
            }
        }
    }
}
