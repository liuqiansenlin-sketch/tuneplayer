// DynamicAlbumView.swift
// 动态专辑：全屏无缝循环播放本地 mp4/mov（用户自己准备的动态专辑资源）
// 资源目录：Documents/DynamicAlbum/（在页面内用“+”导入，或手动放进去）
// 支持多段视频左右滑动切换，记住上次选择
import SwiftUI
import Foundation
import UniformTypeIdentifiers

enum DynamicAlbumStore {
    static let folderName = "DynamicAlbum"

    /// Documents/DynamicAlbum（不存在则创建）
    static func folderURL() -> URL? {
        guard let docs = try? FileManager.default.url(for: .documentDirectory,
                                                      in: .userDomainMask,
                                                      appropriateFor: nil,
                                                      create: true) else { return nil }
        let dir = docs.appendingPathComponent(folderName, isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    /// 目录下所有视频（按文件名排序）
    static func videos() -> [URL] {
        guard let dir = folderURL(),
              let names = try? FileManager.default.contentsOfDirectory(atPath: dir.path) else { return [] }
        let exts: Set<String> = ["mp4", "mov", "m4v"]
        return names
            .filter { exts.contains(($0 as NSString).pathExtension.lowercased()) }
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
            .map { dir.appendingPathComponent($0) }
    }

    /// 把选择的视频复制进资源目录
    @discardableResult
    static func importFile(from sourceURL: URL) throws -> URL {
        guard let dir = folderURL() else {
            throw NSError(domain: "DynamicAlbum", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "无法创建动态专辑目录"])
        }
        let dest = dir.appendingPathComponent(sourceURL.lastPathComponent)
        if FileManager.default.fileExists(atPath: dest.path) {
            try FileManager.default.removeItem(at: dest)
        }
        let needStop = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if needStop { sourceURL.stopAccessingSecurityScopedResource() }
        }
        try FileManager.default.copyItem(at: sourceURL, to: dest)
        return dest
    }

    static func delete(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
    }
}

struct DynamicAlbumView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme

    @State private var videos: [URL] = []
    @State private var selection: Int = 0
    @State private var showImporter = false
    @State private var showDeleteConfirm = false
    @State private var importError: String?
    @GestureState private var dragOffset: CGFloat = 0
    @State private var finalDragOffset: CGFloat = 0

    @AppStorage("dynamicAlbum.lastVideoName") private var lastVideoName: String = ""

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()

            if videos.isEmpty {
                emptyState
            } else {
                videoPages
                overlays
            }
        }
        .onAppear(perform: reload)
        .confirmationDialog("删除当前这段动态专辑？",
                            isPresented: $showDeleteConfirm,
                            titleVisibility: .visible) {
            Button("删除", role: .destructive) { deleteCurrent() }
            Button("取消", role: .cancel) {}
        } message: {
            Text("视频文件会从 App 里移除。")
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [.movie, .mpeg4Movie, .quickTimeMovie],
                      allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                do {
                    let dest = try DynamicAlbumStore.importFile(from: url)
                    reload()
                    if let idx = videos.firstIndex(of: dest) {
                        selection = idx
                        lastVideoName = dest.lastPathComponent
                    }
                    importError = nil
                } catch {
                    importError = "导入失败：\(error.localizedDescription)"
                }
            case .failure(let error):
                importError = "选择文件失败：\(error.localizedDescription)"
            }
        }
        .gesture(
            DragGesture(minimumDistance: 10)
                .updating($dragOffset) { value, gestureState, _ in
                    gestureState = max(0, value.translation.height)
                }
                .onEnded { value in
                    let height = value.translation.height
                    let velocity = value.predictedEndTranslation.height - height
                    if height > 120 || velocity > 300 {
                        withAnimation(.interpolatingSpring(stiffness: 280, damping: 32)) {
                            finalDragOffset = UIScreen.main.bounds.height
                            dismiss()
                        }
                    } else {
                        withAnimation(.interpolatingSpring(stiffness: 350, damping: 36)) {
                            finalDragOffset = 0
                        }
                    }
                }
        )
        .offset(y: finalDragOffset)
    }

    /// 重新扫描视频目录，并恢复上次播放到的那一段
    private func reload() {
        videos = DynamicAlbumStore.videos()
        if let index = videos.firstIndex(where: { $0.lastPathComponent == lastVideoName }) {
            selection = index
        } else {
            selection = 0
        }
    }

    /// 删除当前这一段动态专辑
    private func deleteCurrent() {
        guard videos.indices.contains(selection) else { return }
        DynamicAlbumStore.delete(videos[selection])
        if lastVideoName == videos[selection].lastPathComponent {
            lastVideoName = ""
        }
        reload()
    }

    // MARK: - 视频翻页

    private var videoPages: some View {
        TabView(selection: $selection) {
            ForEach(videos.indices, id: \.self) { index in
                LoopingVideoView(url: videos[index])
                    .ignoresSafeArea()
                    .tag(index)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .ignoresSafeArea()
        .onChange(of: selection) { idx in
            if videos.indices.contains(idx) {
                lastVideoName = videos[idx].lastPathComponent
            }
        }
    }

    // MARK: - 覆盖层

    private var overlays: some View {
        VStack {
            HStack {
                GlassIconButton(systemName: "xmark",
                                font: .system(size: 15, weight: .semibold),
                                size: 38,
                                action: { dismiss() })
                Spacer()
                GlassIconButton(systemName: "trash",
                                font: .system(size: 16, weight: .semibold),
                                size: 38,
                                action: { showDeleteConfirm = true })
                GlassIconButton(systemName: "plus",
                                font: .system(size: 16, weight: .semibold),
                                size: 38,
                                action: { showImporter = true })
            }
            .padding(.horizontal, 18)
            .padding(.top, 10)

            Spacer()

            VStack(spacing: 6) {
                if let song = player.currentSong {
                    Text(song.title)
                        .font(.title3.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(song.artist ?? "未知艺人")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                if videos.indices.contains(selection) {
                    Text(videos[selection].deletingPathExtension().lastPathComponent)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                pageDots
                    .padding(.top, 4)
            }
            .padding(.horizontal, 28)
            .padding(.bottom, 26)
        }
        // 媒体暗角：恒定黑色（叠加在视频/图片上，不属于主题色）
        .background(
            LinearGradient(colors: [Color.black.opacity(0.45), .clear],
                           startPoint: .top, endPoint: .center)
                .ignoresSafeArea()
                .allowsHitTesting(false)
        )
        .background(
            LinearGradient(colors: [.clear, Color.black.opacity(0.55)],
                           startPoint: .center, endPoint: .bottom)
                .ignoresSafeArea()
                .allowsHitTesting(false)
        )
    }

    private var pageDots: some View {
        HStack(spacing: 6) {
            ForEach(Array(videos.indices), id: \.self) { idx in
                Circle()
                    .fill(idx == selection ? Color.appPrimaryText : Color.glassHighlight(0.28))
                    .frame(width: idx == selection ? 7 : 5, height: idx == selection ? 7 : 5)
            }
        }
        .animation(.easeInOut(duration: 0.2), value: selection)
    }

    // MARK: - 空状态

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "wand.and.stars")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)

            Text("还没有动态专辑")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)

            Text("导入一段 mp4/mov 作为动态专辑，\n点一下就能全屏循环播放。")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Button {
                showImporter = true
            } label: {
                Label("导入动态专辑", systemImage: "plus")
                    .font(.headline)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 10)
                    .liquidGlassCapsule()
            }
            .buttonStyle(.plain)
            .foregroundStyle(.primary)
            .padding(.top, 4)

            if let importError {
                Text(importError)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
        }
        .padding(.horizontal, 28)
    }
}
