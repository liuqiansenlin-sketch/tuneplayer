// RadioView.swift
// 电台（Apple Music「Radio」的离线实现）：收藏电台 / 最近播放 / Top 25 / 全部随机播放
import SwiftUI

struct RadioView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @ObservedObject private var history = HistoryStore.shared

    private var favoriteSongs: [Song] {
        player.songs.filter { favorites.isFavorite($0.url) }
    }

    private var recentSongs: [Song] {
        history.recentSongs(from: player.songs, limit: 50)
    }

    private var topSongs: [Song] {
        history.topSongs(from: player.songs, limit: 25)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if player.songs.isEmpty {
                        emptyState
                    } else {
                        stationCard(title: "收藏电台",
                                    subtitle: "播放你收藏的 \(favoriteSongs.count) 首歌",
                                    icon: "heart.fill",
                                    colors: [Color.red, Color.pink],
                                    songs: favoriteSongs)

                        stationCard(title: "最近播放电台",
                                    subtitle: "按你最近听过的顺序播放",
                                    icon: "clock.arrow.circlepath",
                                    colors: [Color.orange, Color.yellow],
                                    songs: recentSongs)

                        stationCard(title: "Top 25 电台",
                                    subtitle: "按播放次数排序的热门歌曲",
                                    icon: "chart.line.uptrend.xyaxis",
                                    colors: [Color.blue, Color.cyan],
                                    songs: topSongs)

                        stationCard(title: "全部随机电台",
                                    subtitle: "打乱 \(player.songs.count) 首歌，无限循环",
                                    icon: "shuffle",
                                    colors: [Color.purple, Color.indigo],
                                    songs: player.songs.shuffled())
                    }
                }
                .padding(.top, 12)
                .padding(.horizontal, 16)
                .padding(.bottom, 90)
            }
            .navigationTitle("电台")
            .navigationBarTitleDisplayMode(.large)
            .refreshable { await player.refreshLibrary() }
            .task { await player.refreshLibrary() }
            .background(Color(.systemBackground))
        }
    }

    // MARK: - 电台卡片（点击即播放该电台）

    private func stationCard(title: String,
                             subtitle: String,
                             icon: String,
                             colors: [Color],
                             songs: [Song]) -> some View {
        Button {
            Haptics.medium()
            guard let first = songs.first else { return }
            player.playSong(first, in: songs)
        } label: {
            ZStack(alignment: .leading) {
                LinearGradient(colors: colors,
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .shadow(color: colors[0].opacity(0.35), radius: 10, y: 6)

                HStack(spacing: 16) {
                    Image(systemName: icon)
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 64, height: 64)
                        .background(.white.opacity(0.22))
                        .clipShape(Circle())

                    VStack(alignment: .leading, spacing: 4) {
                        Text(title)
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.white)
                        Text(subtitle)
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.85))
                            .lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
                .padding(18)
            }
            .frame(height: 108)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(songs.isEmpty)
        .opacity(songs.isEmpty ? 0.55 : 1.0)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer(minLength: 40)
            Image(systemName: "dot.radiowaves.left.and.right")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            Text("在资料库导入音乐后，这里会出现专属电台")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Spacer(minLength: 40)
        }
        .frame(maxWidth: .infinity)
    }
}
