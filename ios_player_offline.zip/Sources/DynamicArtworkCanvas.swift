// DynamicArtworkCanvas.swift
// 无视频时的「动态专辑封面」兜底：确定性的流光极光画面
// 同一首歌的种子恒定 → 色相、轨迹、配色组合稳定不跳动（走视觉品牌一致）
// TimelineView + Canvas，30fps，完全不依赖外部素材
import SwiftUI

struct DynamicArtworkCanvas: View {
    let seed: String

    // 稳定 hash → 0...1
    private func hash01(_ s: String) -> Double {
        var h: UInt64 = 1469598103934665603
        for scalar in s.unicodeScalars {
            h ^= UInt64(scalar.value)
            h &*= 1099511628211
        }
        return Double(h % 1_000_000) / 1_000_000.0
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 24.0)) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                let baseHue = hash01(seed + "#base")

                // 底色：深酒红 → 近黑，微对角
                context.fill(
                    Path(CGRect(origin: .zero, size: size)),
                    with: .linearGradient(Gradient(colors: [
                        Color(hue: baseHue, saturation: 0.62, brightness: 0.34),
                        Color(hue: (baseHue + 0.08).truncatingRemainder(dividingBy: 1), saturation: 0.55, brightness: 0.16),
                        Color.black,
                    ]), startPoint: CGPoint(x: 0, y: 0), endPoint: CGPoint(x: size.width, y: size.height))
                )

                // 5 团极光：Lissajous 轨迹 + 加性混合
                context.blendMode = .plusLighter
                let blobs = [
                    (speed: 0.31, sizeF: 0.85, sat: 0.90, hueOff: 0.00),
                    (speed: 0.23, sizeF: 0.65, sat: 0.85, hueOff: 0.09),
                    (speed: 0.36, sizeF: 0.50, sat: 0.80, hueOff: 0.16),
                    (speed: 0.17, sizeF: 0.75, sat: 0.75, hueOff: -0.06),
                    (speed: 0.28, sizeF: 0.42, sat: 0.95, hueOff: 0.03),
                ]
                for (i, blob) in blobs.enumerated() {
                    let p1 = hash01(seed + "#p\(i)a") * .pi * 2
                    let p2 = hash01(seed + "#p\(i)b") * .pi * 2
                    let ampX = 0.30 + hash01(seed + "#ax\(i)") * 0.18
                    let ampY = 0.26 + hash01(seed + "#ay\(i)") * 0.18
                    let x = (sin(t * blob.speed + p1) * ampX + 0.5) * size.width
                    let y = (cos(t * blob.speed * 1.15 + p2) * ampY + 0.5) * size.height
                    let radius = min(size.width, size.height) * blob.sizeF * (0.72 + 0.28 * sin(t * 0.6 + Double(i)))
                    let hue = (baseHue + blob.hueOff + t * 0.01).truncatingRemainder(dividingBy: 1)
                    let gradient = Gradient(stops: [
                        .init(color: Color(hue: hue, saturation: blob.sat, brightness: 0.95, opacity: 0.9), location: 0),
                        .init(color: Color(hue: hue, saturation: blob.sat, brightness: 0.62, opacity: 0.45), location: 0.45),
                        .init(color: Color(hue: hue, saturation: blob.sat, brightness: 0.35, opacity: 0.0), location: 1),
                    ])
                    let rect = CGRect(x: x - radius, y: y - radius, width: radius * 2, height: radius * 2)
                    context.fill(
                        Path(ellipseIn: rect),
                        with: .radialGradient(gradient, center: CGPoint(x: x, y: y), startRadius: 0, endRadius: radius)
                    )
                }

                // 电影感颗粒：思路一致的位置稳定噪点（低 alpha）
                context.blendMode = .normal
                // 中心轻微高光
                let core = Gradient(colors: [Color.white.opacity(0.10), Color.white.opacity(0.0)])
                context.fill(
                    Path(ellipseIn: CGRect(x: size.width * 0.25, y: size.height * 0.18, width: size.width * 0.5, height: size.height * 0.42)),
                    with: .radialGradient(core, center: CGPoint(x: size.width / 2, y: size.height / 2), startRadius: 0, endRadius: size.width * 0.35)
                )
            }
        }
    }
}
