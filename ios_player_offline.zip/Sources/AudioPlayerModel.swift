// AudioPlayerModel.swift
// 播放引擎：AVPlayer + 定时器驱动的进度观察 + 锁屏/控制中心集成
// 结构：songs = 资料库（扫描结果）；queue = 播放队列（Apple Music Up Next）
import Foundation
import AVFoundation
import MediaPlayer
import Combine
import UIKit

// MARK: - 循环模式
enum RepeatMode {
    case none   // 播完当前队列就停
    case all    // 队列播完从头循环
    case one    // 单曲循环
}

@MainActor
final class AudioPlayerModel: ObservableObject {
    // MARK: - 公开状态（驱动 UI）
    @Published private(set) var songs: [Song] = []        // 资料库（启动时扫描）
    @Published private(set) var queue: [Song] = []        // 播放队列
    @Published private(set) var currentIndex: Int = -1    // 队列内当前位置
    @Published private(set) var isPlaying = false
    @Published private(set) var currentTime: TimeInterval = 0
    @Published private(set) var duration: TimeInterval = 0
    @Published private(set) var isLoading = false
    @Published private(set) var isShuffle = false
    @Published private(set) var repeatMode: RepeatMode = .none

    var currentSong: Song? {
        guard queue.indices.contains(currentIndex) else { return nil }
        return queue[currentIndex]
    }

    // MARK: - 私有
    private let player = AVPlayer()
    private var timeObserver: Any?
    private var interruptionObserver: NSObjectProtocol?
    private var itemEndObserver: NSObjectProtocol?

    // 续播记忆：按文件路径记录上次停的位置（听完自动清除）
    private let resumeKey = "resumePositions"
    private var resumePositions: [String: TimeInterval] = [:]

    init() {
        configureSession()
        configureRemoteCommands()
        observeInterruptions()
        loadResumePositions()
        timeObserver = player.addPeriodicTimeObserver(
            forInterval: CMTime(seconds: 0.5, preferredTimescale: 600),
            queue: .main
        ) { [weak self] time in
            Task { @MainActor in
                self?.currentTime = CMTime(seconds: time)
            }
        }
    }

    deinit {
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        if let interruptionObserver { NotificationCenter.default.removeObserver(interruptionObserver) }
        if let itemEndObserver { NotificationCenter.default.removeObserver(itemEndObserver) }
    }

    // MARK: - 续播记忆
    private func loadResumePositions() {
        guard let data = UserDefaults.standard.data(forKey: resumeKey),
              let decoded = try? JSONDecoder().decode([String: TimeInterval].self, from: data) else { return }
        resumePositions = decoded
    }

    private func persistResumePositions() {
        if let data = try? JSONEncoder().encode(resumePositions) {
            UserDefaults.standard.set(data, forKey: resumeKey)
        }
    }

    private func resumeKey(for url: URL) -> String { url.standardizedFileURL.path }

    private func saveResumePosition(for song: Song?, at position: TimeInterval) {
        guard let song else { return }
        let key = resumeKey(for: song.url)
        if position > 3 {
            resumePositions[key] = position
        } else {
            resumePositions[key] = nil
        }
        persistResumePositions()
    }

    private func clearResumePosition(for key: String) {
        resumePositions[key] = nil
        persistResumePositions()
    }

    // MARK: - 会话（后台播放 + 电源管理）
    private func configureSession() {
        let session = AVAudioSession.sharedInstance()
        do {
            // 音乐播放类别：后台继续播放、尊重系统音量、正确路由到耳机/CarPlay/AirPlay
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true)
        } catch {
            print("AVAudioSession 设置失败：\(error)")
        }
    }

    /// 被中断（电话、Siri、其他 App 开始播放）后自动暂停，恢复时不强制继续
    private func observeInterruptions() {
        interruptionObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance(),
            queue: .main
        ) { [weak self] notification in
            guard let self,
                  let userInfo = notification.userInfo,
                  let typeValue = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: typeValue) else { return }
            if type == .began {
                Task { @MainActor in
                    self.pause()
                }
            }
        }
    }

    // MARK: - 语料库管理
    func loadLibrary() async {
        songs = await LibraryScanner.scan()
    }

    func refreshLibrary() async {
        await loadLibrary()
        // 如果正在播放的歌因重命名 URL 变了，用同名匹配修复 currentSong
        if let playing = currentSong,
           !songs.contains(where: { $0.url == playing.url }),
           let newSong = songs.first(where: { $0.title == playing.title && $0.artist == playing.artist }) {
            queue = queue.map { $0.url == playing.url ? newSong : $0 }
            if let idx = queue.firstIndex(where: { $0.url == newSong.url }) {
                currentIndex = idx
            }
        }
    }

    func importMusic(from urls: [URL]) async {
        for url in urls {
            _ = try? LibraryScanner.importFile(from: url)
        }
        await loadLibrary()
    }

    // MARK: - 播放队列

    /// 第 N 首开始播放（队列已设置时调用）
    private func beginPlayback(at index: Int, saveContinuity: Bool = true) {
        guard queue.indices.contains(index) else { return }
        // 1) 保存“正在播的旧歌”的位置
        if saveContinuity { saveResumePosition(for: currentSong, at: currentTime) }

        let song = queue[index]
        currentIndex = index
        let url = song.url
        let key = resumeKey(for: url)
        let resumeSeconds = resumePositions[key] ?? 0

        let item = AVPlayerItem(url: url)
        if let itemEndObserver { NotificationCenter.default.removeObserver(itemEndObserver) }
        itemEndObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.handleTrackEnd(key: key) }
        }
        isLoading = true
        player.replaceCurrentItem(with: item)
        // 2) 有上次停的位置就接着播
        if resumeSeconds > 3 {
            player.seek(to: CMTime(seconds: resumeSeconds, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
            currentTime = resumeSeconds
        } else {
            currentTime = 0
        }
        player.play()
        isPlaying = true
        duration = song.durationSeconds
        updateNowPlayingInfo()
    }

    /// 点库里某首歌：以“当前可见顺序”重建队列并从该曲开始
    func playSong(_ song: Song, in visibleOrder: [Song]) {
        guard let index = visibleOrder.firstIndex(where: { $0.url == song.url }) else { return }
        saveResumePosition(for: currentSong, at: currentTime)
        queue = visibleOrder
        beginPlayback(at: index, saveContinuity: false)
    }

    /// 跳到队列里第 N 首（浏览 Up Next 时点某行）
    func playQueueItem(at index: Int) {
        guard queue.indices.contains(index) else { return }
        beginPlayback(at: index)
    }

    /// 拖动重排队列；若被拖的是当前歌，自动校正 currentIndex
    func moveQueueItems(from source: IndexSet, to destination: Int) {
        let playingKey = currentSong.map { resumeKey(for: $0.url) }
        let moving = source.sorted().map { queue[$0] }
        let below = source.filter { $0 < destination }.count

        var items = queue
        for i in source.sorted().reversed() { items.remove(at: i) }
        let insertAt = min(max(0, destination - below), items.count)
        items.insert(contentsOf: moving, at: insertAt)
        queue = items

        if let playingKey {
            if let newIndex = queue.firstIndex(where: { resumeKey(for: $0.url) == playingKey }) {
                currentIndex = newIndex
            }
        }
    }

    func togglePlayPause() {
        if isPlaying { pause() } else { play() }
    }

    func play() {
        guard currentIndex >= 0 else {
            // 上次启动后还没播过：以资料库顺序建立队列并从第 1 首开始
            if !songs.isEmpty {
                saveResumePosition(for: currentSong, at: currentTime)
                queue = songs
                beginPlayback(at: 0, saveContinuity: false)
            }
            return
        }
        player.play()
        isPlaying = true
        updateNowPlayingInfo()
    }

    func pause() {
        player.pause()
        isPlaying = false
        saveResumePosition(for: currentSong, at: currentTime)
        updateNowPlayingInfo()
    }

    /// 曲目自然结束：根据 repeatMode 决定重播本曲 / 下一首 / 停止
    private func handleTrackEnd(key: String) {
        switch repeatMode {
        case .one:
            clearResumePosition(for: key)
            player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero)
            currentTime = 0
            player.play()
            updateNowPlayingInfo()
        case .all:
            clearResumePosition(for: key)
            playNext()
        case .none:
            if currentIndex + 1 < queue.count {
                playNext()
            } else {
                // 队尾：整页停下并回到开头
                clearResumePosition(for: key)
                player.pause()
                isPlaying = false
                currentIndex = -1
                currentTime = 0
                player.seek(to: .zero)
                updateNowPlayingInfo()
            }
        }
    }

    func toggleShuffle() {
        isShuffle.toggle()
    }

    /// 循环模式 无 → 队列循环 → 单曲循环 之间切换
    func toggleRepeat() {
        switch repeatMode {
        case .none: repeatMode = .all
        case .all: repeatMode = .one
        case .one: repeatMode = .none
        }
    }

    func playNext() {
        guard !queue.isEmpty else { return }
        let next: Int
        if isShuffle && queue.count > 1 {
            // 随机一首（不含当前）
            let pool = queue.indices.filter { $0 != currentIndex }
            next = pool.randomElement() ?? currentIndex
        } else if currentIndex + 1 >= queue.count {
            // 队尾：按 repeatMode 包回来 或 保持在队列尽头（由 handleTrackEnd 决定停不停）
            next = repeatMode == .all || repeatMode == .one ? 0 : queue.count - 1
            if repeatMode == .none { return }
        } else {
            next = currentIndex + 1
        }
        beginPlayback(at: next)
    }

    /// 插播：把这首歌插到当前歌曲之后，并立即播放
    func insertSongAfterCurrent(_ song: Song) {
        let insertAt = max(0, currentIndex + 1)
        queue.insert(song, at: insertAt)
        beginPlayback(at: insertAt, saveContinuity: false)
    }

    /// 加入队列尾部
    func addToQueue(_ song: Song) {
        queue.append(song)
    }

    /// 删除歌曲：移除本地文件，并从库与队列里去掉
    func deleteSong(_ song: Song) {
        if currentSong?.url == song.url { pause() }
        queue.removeAll { $0.url == song.url }
        songs.removeAll { $0.url == song.url }
        CoverStore.removeCover(for: song)
        try? FileManager.default.removeItem(at: song.url)
    }

    /// 重命名：把文件改名为新标题（.mp3/.m4a 等），然后重新扫描资料库
    func renameSong(_ song: Song, to newTitle: String) {
        let trimmed = newTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let oldURL = song.url
        let ext = oldURL.pathExtension
        let newURL = oldURL.deletingLastPathComponent().appendingPathComponent(trimmed + "." + ext)
        guard newURL != oldURL else { return }
        do {
            if FileManager.default.fileExists(atPath: newURL.path) {
                try FileManager.default.removeItem(at: newURL)
            }
            try FileManager.default.moveItem(at: oldURL, to: newURL)
            // 重新构建 Song 对象用于 CoverStore
            let oldSong = Song(url: oldURL, title: song.title, artist: song.artist, album: song.album, durationSeconds: song.durationSeconds, videoURL: song.videoURL)
            let newSong = Song(url: newURL, title: trimmed, artist: song.artist, album: song.album, durationSeconds: song.durationSeconds, videoURL: song.videoURL)
            // CoverStore 里的封面文件是按文件名缓存的，同步移动
            CoverStore.moveCover(from: oldSong, to: newSong)
            // 重新扫描资料库，让 songs 数组指向新 URL
            Task { await refreshLibrary() }
        } catch {
            print("重命名失败：\(error)")
        }
    }

    func playPrevious() {
        guard !queue.isEmpty else { return }
        // 播放超过 3 秒则先回到开头
        if currentTime > 3 { seek(to: 0); return }
        let prev: Int
        if isShuffle && queue.count > 1 {
            let pool = queue.indices.filter { $0 != currentIndex }
            prev = pool.randomElement() ?? 0
        } else {
            prev = (currentIndex - 1 + queue.count) % queue.count
        }
        beginPlayback(at: prev)
    }

    func seek(to seconds: TimeInterval) {
        let time = CMTime(seconds: seconds, preferredTimescale: 600)
        player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
        currentTime = seconds
        saveResumePosition(for: currentSong, at: seconds)
        updateNowPlayingInfo()
    }

    // MARK: - 锁屏 / 控制中心
    private func configureRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.play() }; return .success
        }
        center.pauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.pause() }; return .success
        }
        center.togglePlayPauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.togglePlayPause() }; return .success
        }
        center.nextTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.playNext() }; return .success
        }
        center.previousTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.playPrevious() }; return .success
        }
        center.changePlaybackPositionCommand.addTarget { [weak self] event in
            if let e = event as? MPChangePlaybackPositionCommandEvent {
                Task { @MainActor in self?.seek(to: e.positionTime) }
            }
            return .success
        }
    }

    private func updateNowPlayingInfo() {
        guard let song = currentSong else {
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
            return
        }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: song.title,
            MPMediaItemPropertyArtist: song.artist ?? "未知艺人",
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: currentTime,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0,
        ]
        if let album = song.album { info[MPMediaItemPropertyAlbumTitle] = album }
        let artworkSize = CGSize(width: 700, height: 700)
        if let cached = ArtworkStore.shared.cachedImage(for: song.url) {
            // 有缓存封面：同步带过去
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: artworkSize) { _ in cached }
        } else {
            // 未命中则先显示无封面，读到后异步补上（就算是没有封面也不会阻塞播放）
            let url = song.url
            Task { @MainActor in
                if let img = await ArtworkStore.shared.image(for: url) {
                    var current = MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:]
                    current[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: artworkSize) { _ in img }
                    MPNowPlayingInfoCenter.default().nowPlayingInfo = current
                }
            }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}
