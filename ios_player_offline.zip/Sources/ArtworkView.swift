// ArtworkView.swift
// 封面视图：有真实 ID3 封面时填充，否则显示由种子生成的稳定渐变 + 音符
// 先渲染占位（同步），封面到达后自动淡入替换
import SwiftUI
import UIKit

enum ArtworkSeed {
    /// 稳定哈希 → 0...1（渲染前确定性，同一文件永远同色）
    static func value(_ seed: String) -> Double {
        var hash: UInt64 = 1469598103934665603
        for scalar in seed.unicodeScalars {
            hash ^= UInt64(scalar.value)
            hash &*= 1099511628211
        }
        return Double(hash % 360) / 360.0
    }
}

struct ArtworkView: View {
    let url: URL?
    let seed: String
    let cornerRadius: CGFloat

    @State private var image: UIImage?

    private var hue: Double { ArtworkSeed.value(seed) }

    var body: some View {
        ZStack {
            // 占位底：稳定色相渐变
            LinearGradient(
                colors: [
                    Color(hue: hue, saturation: 0.55, brightness: 0.78),
                    Color(hue: (hue + 0.12).truncatingRemainder(dividingBy: 1), saturation: 0.62, brightness: 0.42),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            // 找不到封面时的符号标识
            if image == nil {
                Image(systemName: "music.note")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.9))
            }

            // 真实封面（淡入）
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .transition(.opacity)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
            .stroke(Color.white.opacity(0.08), lineWidth: 0.5))
        .task(id: url) {
            guard let url else { return }
            let img = ArtworkStore.shared.cachedImage(for: url) ?? await ArtworkStore.shared.image(for: url)
            withAnimation(.easeIn(duration: 0.25)) {
                image = img
            }
        }
    }
}
