import SwiftUI

// 全局自适应颜色：跟随系统深色/浅色模式，不需要每个 View 都加 @Environment
extension Color {
    /// 玻璃/高光：深色下偏白，浅色下偏黑
    static func glassHighlight(_ opacity: Double) -> Color {
        Color(uiColor: UIColor { trait in
            trait.userInterfaceStyle == .dark
                ? UIColor.white.withAlphaComponent(opacity)
                : UIColor.black.withAlphaComponent(opacity)
        })
    }

    /// 玻璃描边：深色下偏白，浅色下偏黑
    static func glassStroke(_ opacity: Double) -> Color {
        Color(uiColor: UIColor { trait in
            trait.userInterfaceStyle == .dark
                ? UIColor.white.withAlphaComponent(opacity)
                : UIColor.black.withAlphaComponent(opacity)
        })
    }

    /// 深色/浅色自适应背景色
    static var appBackground: Color {
        Color(uiColor: .systemBackground)
    }

    /// 自适应主文字色
    static var appPrimaryText: Color {
        Color(uiColor: .label)
    }

    /// 自适应次要文字色
    static var appSecondaryText: Color {
        Color(uiColor: .secondaryLabel)
    }

    /// 自适应分隔线/弱化背景
    static var appDivider: Color {
        Color(uiColor: .separator)
    }

    /// 自适应浅灰背景（用于卡片、列表行）
    static var appCardBackground: Color {
        Color(uiColor: .secondarySystemBackground)
    }
}