// GlassChrome.swift
// iOS 26 Liquid Glass（液态玻璃）按键/容器效果；旧 SDK 编译时自动退回磨砂玻璃（ultraThinMaterial）
//
// 设计：iOS 26 专属符号仅在 compiler(>=6.2) 分支内编译。
// 这样 macOS 15 runner（Xcode 16）也能通过构建；在 Xcode 26/macOS 26 上则启用原生 Liquid Glass。
import SwiftUI

extension View {
    /// 胶囊形液态玻璃（用于“+”导入按钮、导航芯片等）
    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Capsule(style: .continuous))
        } else {
            glassFallbackCapsule()
        }
        #else
        glassFallbackCapsule()
        #endif
    }

    /// 圆形液态玻璃（Now Playing 控制按钮）
    @ViewBuilder
    func liquidGlassCircle() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Circle())
        } else {
            glassFallbackCircle()
        }
        #else
        glassFallbackCircle()
        #endif
    }

    /// 大圆角矩形液态玻璃（底部迷你播放条 / 面板）
    @ViewBuilder
    func liquidGlassRoundedRect(_ radius: CGFloat = 16) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
        } else {
            glassFallbackRoundedRect(radius)
        }
        #else
        glassFallbackRoundedRect(radius)
        #endif
    }

    @ViewBuilder
    private func glassFallbackCapsule() -> some View {
        self.background(.ultraThinMaterial, in: Capsule(style: .continuous))
            .overlay(Capsule(style: .continuous)
                .stroke(Color.white.opacity(0.14), lineWidth: 0.5))
    }

    @ViewBuilder
    private func glassFallbackCircle() -> some View {
        self.background(.ultraThinMaterial, in: Circle())
            .overlay(Circle()
                .stroke(Color.white.opacity(0.14), lineWidth: 0.5))
    }

    @ViewBuilder
    private func glassFallbackRoundedRect(_ radius: CGFloat) -> some View {
        self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                .stroke(Color.white.opacity(0.12), lineWidth: 0.5))
    }
}

/// 液态玻璃圆形图标按钮（上一曲/下一曲/收起/导入）
struct GlassIconButton: View {
    let systemName: String
    let font: Font
    let size: CGFloat
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(font)
                .frame(width: size, height: size)
                .contentShape(Circle())
                .liquidGlassCircle()
                .foregroundStyle(.white)
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(.isButton)
    }
}

/// 液态玻璃主键（播放 / 暂停）：
/// Xcode 26 上是带折射+触摸反馈的玻璃圆；旧 SDK 上是磨砂玻璃圆
struct GlassPrimaryButton: View {
    let systemName: String
    let size: CGFloat
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size, weight: .semibold))
                .frame(width: size + 26, height: size + 26)
                .contentShape(Circle())
                .foregroundStyle(.white)
                .modifier(PrimaryGlassButtonStyle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(.isButton)
    }
}

private struct PrimaryGlassButtonStyle: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.interactive(), in: Circle())
        } else {
            fallbackStyle(content)
        }
        #else
        fallbackStyle(content)
        #endif
    }

    @ViewBuilder
    private func fallbackStyle(_ content: Content) -> some View {
        content.background(.ultraThinMaterial, in: Circle())
            .overlay(Circle().stroke(Color.white.opacity(0.22), lineWidth: 0.5))
    }
}
