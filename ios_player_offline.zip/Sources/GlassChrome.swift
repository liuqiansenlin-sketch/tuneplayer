// GlassChrome.swift
// iOS 26 Liquid Glass（液态玻璃）按键/容器效果；在旧系统上退回磨砂玻璃（ultraThinMaterial）
//
// 设计：所有 iOS 26 专属符号集中在此文件并以 #available(iOS 26.0, *) 保护；
// 若个别 API 名在你的 SDK 版本略有差异，改这一处即可。
//
// 使用到的 iOS 26 API（显式 Shape 构造，避免任何缩写歧义）：
//   .glassEffect(.regular, in: Capsule())
//   .glassEffect(.regular.interactive(), in: Circle())
//   .glassEffect(.regular, in: RoundedRectangle(cornerRadius:, style:))
import SwiftUI

// MARK: - iOS 26 与旧系统二选一的玻璃实现
@ViewBuilder
private func glassOrFallback<S: InsettableShape>(fill: some View, shape: S, interactive: Bool, strokeOpacity: Double) -> some View {
    if #available(iOS 26.0, *) {
        fill.glassEffect(interactive ? .regular.interactive() : .regular, in: shape)
    } else {
        fill.background(.ultraThinMaterial, in: shape)
            .overlay(shape.stroke(Color.white.opacity(strokeOpacity), lineWidth: 0.5))
    }
}

extension View {
    /// 胶囊形液态玻璃（用于“+”导入按钮、导航芯片等）
    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        glassOrFallback(fill: self, shape: Capsule(style: .continuous), interactive: true, strokeOpacity: 0.14)
    }

    /// 圆形液态玻璃（Now Playing 控制按钮）
    @ViewBuilder
    func liquidGlassCircle() -> some View {
        glassOrFallback(fill: self, shape: Circle(), interactive: true, strokeOpacity: 0.14)
    }

    /// 大圆角矩形液态玻璃（底部迷你播放条 / 面板）
    @ViewBuilder
    func liquidGlassRoundedRect(_ radius: CGFloat = 16) -> some View {
        // 非交互玻璃（面板本身不可点按）
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(Color.white.opacity(0.12), lineWidth: 0.5))
        }
    }
}

/// 液态玻璃圆形图标按钮（上一曲/下一曲/收起/导入）
struct GlassIconButton: View {
    let systemName: String
    let font: Font
    let size: CGFloat
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(font)
                .frame(width: size, height: size)
                .contentShape(Circle())
                .liquidGlassCircle()
                .foregroundStyle(.white)
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(.isButton)
    }
}

/// 液态玻璃主键（播放 / 暂停）：
/// iOS 26 上是带折射+触摸反馈的玻璃圆；旧系统上是更实心的白盘（主次分明）
struct GlassPrimaryButton: View {
    let systemName: String
    let size: CGFloat
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size, weight: .semibold))
                .frame(width: size + 26, height: size + 26)
                .contentShape(Circle())
                .foregroundStyle(.white)
                .modifier(PrimaryGlassButtonStyle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(.isButton)
    }
}

private struct PrimaryGlassButtonStyle: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            // 主控制键：更大的交互玻璃圆 + 白色图标
            content.glassEffect(.regular.interactive(), in: Circle())
        } else {
            content.background(.white.opacity(0.24), in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.22), lineWidth: 0.5))
        }
    }
}
