// GlassChrome.swift
// iOS 26 Liquid Glass（液态玻璃）按键/容器效果；旧 SDK 编译时自动退回磨砂玻璃（ultraThinMaterial）
//
// 设计：iOS 26 专属符号仅在 compiler(>=6.2) 分支内编译。
// 这样 macOS 15 runner（Xcode 16）也能通过构建；在 Xcode 26/macOS 26 上则启用原生 Liquid Glass。
// 旧 SDK fallback 增加了内部高光、描边渐变和柔和投影，避免“突兀”的扁平磨砂感。
import SwiftUI

extension View {
    /// 胶囊形液态玻璃（用于迷你播放条、底部三键栏等）
    @ViewBuilder
    func liquidGlassCapsule() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Capsule(style: .continuous))
        } else {
            glassFallbackCapsule()
        }
        #else
        glassFallbackCapsule()
        #endif
    }

    /// 圆形液态玻璃（导入按钮、播放控制等）
    @ViewBuilder
    func liquidGlassCircle() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Circle())
        } else {
            glassFallbackCircle()
        }
        #else
        glassFallbackCircle()
        #endif
    }

    /// 大圆角矩形液态玻璃（底部迷你播放条 / 面板）
    @ViewBuilder
    func liquidGlassRoundedRect(_ radius: CGFloat = 16) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
        } else {
            glassFallbackRoundedRect(radius)
        }
        #else
        glassFallbackRoundedRect(radius)
        #endif
    }

    /// Liquid Glass 大胶囊容器（底部三键栏）
    @ViewBuilder
    func liquidGlassBar() -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            self.glassEffect(.regular.interactive(), in: Capsule(style: .continuous))
        } else {
            self.background(.ultraThinMaterial, in: Capsule(style: .continuous))
                .overlay(innerHighlight(Capsule(style: .continuous)))
                .overlay(Capsule(style: .continuous)
                    .strokeBorder(
                        LinearGradient(colors: [Color.glassHighlight(0.38), Color.glassHighlight(0.06)],
                                       startPoint: .top, endPoint: .bottom),
                        lineWidth: 0.8))
                .shadow(color: Color.glassShadow, radius: 18, y: 8)
        }
        #else
        self.background(.ultraThinMaterial, in: Capsule(style: .continuous))
            .overlay(innerHighlight(Capsule(style: .continuous)))
            .overlay(Capsule(style: .continuous)
                .strokeBorder(
                    LinearGradient(colors: [Color.glassHighlight(0.38), Color.glassHighlight(0.06)],
                                   startPoint: .top, endPoint: .bottom),
                    lineWidth: 0.8))
            .shadow(color: Color.glassShadow, radius: 18, y: 8)
        #endif
    }

    @ViewBuilder
    private func glassFallbackCapsule() -> some View {
        self.background(.ultraThinMaterial, in: Capsule(style: .continuous))
            .overlay(innerHighlight(Capsule(style: .continuous)))
            .overlay(Capsule(style: .continuous)
                .strokeBorder(
                    LinearGradient(colors: [Color.glassHighlight(0.32), Color.glassHighlight(0.04)],
                                   startPoint: .top, endPoint: .bottom),
                    lineWidth: 0.6))
            .shadow(color: Color.glassShadow, radius: 10, y: 4)
    }

    @ViewBuilder
    private func glassFallbackCircle() -> some View {
        self.background(.ultraThinMaterial, in: Circle())
            .overlay(innerHighlight(Circle()))
            .overlay(Circle()
                .strokeBorder(
                    LinearGradient(colors: [Color.glassHighlight(0.32), Color.glassHighlight(0.04)],
                                   startPoint: .top, endPoint: .bottom),
                    lineWidth: 0.6))
            .shadow(color: Color.glassShadow, radius: 10, y: 4)
    }

    @ViewBuilder
    private func glassFallbackRoundedRect(_ radius: CGFloat) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        self.background(.ultraThinMaterial, in: shape)
            .overlay(innerHighlight(shape))
            .overlay(shape.strokeBorder(
                LinearGradient(colors: [Color.glassHighlight(0.32), Color.glassHighlight(0.04)],
                               startPoint: .top, endPoint: .bottom),
                lineWidth: 0.6))
            .shadow(color: Color.glassShadow, radius: 12, y: 5)
    }

    /// 顶部高光：让磨砂玻璃有“液体”的反射感，而不是一块灰
    @ViewBuilder
    private func innerHighlight<S: Shape>(_ shape: S) -> some View {
        shape
            .fill(
                LinearGradient(
                    colors: [Color.glassHighlight(0.16), Color.glassHighlight(0.02), Color.clear],
                    startPoint: .topLeading,
                    endPoint: .center
                )
            )
            .compositingGroup()
    }
}

/// 液态玻璃圆形图标按钮（上一曲/下一曲/收起/导入）
struct GlassIconButton: View {
    let systemName: String
    let font: Font
    let size: CGFloat
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(font)
                .frame(width: size, height: size)
                .contentShape(Circle())
                .liquidGlassCircle()
                .foregroundStyle(.primary)
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(.isButton)
    }
}

/// 液态玻璃主键（播放 / 暂停）：
/// Xcode 26 上是带折射+触摸反馈的玻璃圆；旧 SDK 上是磨砂玻璃圆
struct GlassPrimaryButton: View {
    let systemName: String
    let size: CGFloat
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: size, weight: .semibold))
                .frame(width: size + 26, height: size + 26)
                .contentShape(Circle())
                .foregroundStyle(.primary)
                .modifier(PrimaryGlassButtonStyle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(.isButton)
    }
}

private struct PrimaryGlassButtonStyle: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.interactive(), in: Circle())
        } else {
            fallbackStyle(content)
        }
        #else
        fallbackStyle(content)
        #endif
    }

    @ViewBuilder
    private func fallbackStyle(_ content: Content) -> some View {
        content.background(.ultraThinMaterial, in: Circle())
            .overlay(
                Circle().fill(
                    LinearGradient(colors: [Color.glassHighlight(0.18), Color.clear],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                )
            )
            .overlay(Circle().strokeBorder(
                LinearGradient(colors: [Color.glassHighlight(0.35), Color.glassHighlight(0.06)],
                               startPoint: .top, endPoint: .bottom),
                lineWidth: 0.8))
            .shadow(color: Color.glassShadow, radius: 14, y: 6)
    }
}
