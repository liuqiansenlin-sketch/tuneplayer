// FavoritesStore.swift
// 收藏功能：按「文件标准化路径」记录喜欢的歌曲，UserDefaults 持久化
// 不依赖数据库；同一首歌文件再导入/路径不变时，收藏状态依然保留
import Foundation
import Combine

@MainActor
final class FavoritesStore: ObservableObject {
    @Published private(set) var favoritePaths: Set<String> = []

    private let defaults = UserDefaults.standard
    private let key = "favoriteSongPaths"

    init() {
        favoritePaths = Set(defaults.stringArray(forKey: key) ?? [])
    }

    private func path(for url: URL) -> String {
        url.standardizedFileURL.path
    }

    func isFavorite(_ url: URL) -> Bool {
        favoritePaths.contains(path(for: url))
    }

    func toggleFavorite(_ url: URL) {
        let p = path(for: url)
        if favoritePaths.contains(p) {
            favoritePaths.remove(p)
        } else {
            favoritePaths.insert(p)
        }
        defaults.set(Array(favoritePaths), forKey: key)
    }
}
