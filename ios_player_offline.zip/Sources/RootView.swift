import SwiftUI

struct RootView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    
    @State private var showNowPlaying = false
    @State private var showDynamicAlbum = false
    @State private var showLyrics = false
    @State private var showLocalSearch = false
    
    var body: some View {
        ZStack(alignment: .bottom) {
            LibraryView()
            
            VStack(spacing: 10) {
                if let song = player.currentSong {
                    miniPlayer(song: song)
                        .padding(.horizontal, 14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
            }
                
                bottomBar
                    .padding(.horizontal, 18)
                    .padding(.bottom, 6)
            }
        }
        .animation(.spring(response: 0.36, dampingFraction: 0.86), value: player.currentSong?.url)
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
        .fullScreenCover(isPresented: $showDynamicAlbum) {
            DynamicAlbumView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showLyrics) {
            LyricsView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showLocalSearch) {
            LocalSearchView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
    }
    
    // MARK: - 底部迷你播放器（当前歌曲）
    
    @ViewBuilder
    private func miniPlayer(song: Song) -> some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.glassHighlight(0.08))
                .frame(width: 46, height: 46)
                .overlay(
                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8, album: song.album)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                )
            VStack(alignment: .leading, spacing: 2) {
                Text(song.title)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(song.artist ?? "未知艺人")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            HStack(spacing: 14) {
                Button { Haptics.medium(); player.togglePlayPause() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 28, height: 28)
                } .buttonStyle(PressableButtonStyle(scale: 0.88))
                Button { Haptics.light(); player.playNext() } label: {
                    Image(systemName: "forward.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 28, height: 28)
                } .buttonStyle(PressableButtonStyle(scale: 0.88))
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        // 与底部三键栏一致的磨砂玻璃（iOS 26 为液态玻璃，旧系统为 ultraThinMaterial）
        .liquidGlassRoundedRect(16)
        .contentShape(Rectangle())
        .onTapGesture {
            showNowPlaying = true
        }
    }
    
    private var bottomBar: some View {
        HStack(spacing: 0) {
            barButton(icon: "wand.and.stars", title: "动态专辑") {
                showDynamicAlbum = true
            }
            barButton(icon: "quote.bubble", title: "歌词") {
                showLyrics = true
            }
            barButton(icon: "magnifyingglass", title: "本地搜索") {
                showLocalSearch = true
            }
        }
        .padding(.vertical, 9)
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity)
        .liquidGlassBar()
    }
    
    private func barButton(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .semibold))
                Text(title)
                    .font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(.primary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(BarButtonStyle())
        .accessibilityLabel(title)
    }
}

private struct BarButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.75 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}