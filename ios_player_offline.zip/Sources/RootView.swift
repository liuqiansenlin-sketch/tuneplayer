// RootView.swift
// 根视图：资料库列表 + 底部迷你播放条（Liquid Glass，有歌时出现）
// 点迷你播放条 → 全屏播放页
import SwiftUI

struct RootView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @State private var showNowPlaying = false

    var body: some View {
        ZStack(alignment: .bottom) {
            LibraryView()

            // 迷你播放条：只在有选中歌曲时显示
            if let song = player.currentSong {
                miniPlayer(song: song)
                    .padding(.horizontal, 12)
                    .padding(.bottom, 6)
            }
        }
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
    }

    private func miniPlayer(song: Song) -> some View {
        HStack(spacing: 10) {
            // 点封面/信息 → 全屏页
            Button { showNowPlaying = true } label: {
                HStack(spacing: 10) {
                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8)
                        .frame(width: 44, height: 44)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(song.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).lineLimit(1)
                        Text(song.artist ?? "未知艺人").font(.caption).foregroundStyle(.gray).lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            // 液态玻璃按钮：播放/暂停、下一首
            GlassIconButton(systemName: player.isPlaying ? "pause.fill" : "play.fill",
                            font: .system(size: 15, weight: .semibold),
                            size: 38,
                            action: { player.togglePlayPause() })
            GlassIconButton(systemName: "forward.fill",
                            font: .system(size: 15, weight: .semibold),
                            size: 38,
                            action: { player.playNext() })
        }
        .padding(.horizontal, 10)
        .frame(height: 62)
        .liquidGlassRoundedRect(16)
        .shadow(color: .black.opacity(0.35), radius: 16, y: 4)

    }
}
