import SwiftUI

struct RootView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    
    @State private var showNowPlaying = false
    @State private var showDynamicAlbum = false
    @State private var showLyrics = false
    @State private var showLocalSearch = false
    @State private var showInternetSearch = false
    
    var body: some View {
        ZStack(alignment: .bottom) {
            LibraryView()
            
            VStack(spacing: 10) {
                if let song = player.currentSong {
                    miniPlayer(song: song)
                        .padding(.horizontal, 14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                
                bottomBar
                    .padding(.horizontal, 18)
                    .padding(.bottom, 6)
            }
            .animation(.spring(response: 0.36, dampingFraction: 0.86), value: player.currentSong?.url)
        }
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environmentObject(player)
                .environmentObject(favorites)
                .transition(.move(edge: .bottom).combined(with: .opacity))
        }
        .fullScreenCover(isPresented: $showDynamicAlbum) {
            DynamicAlbumView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showLyrics) {
            LyricsView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showLocalSearch) {
            LocalSearchView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
        .fullScreenCover(isPresented: $showInternetSearch) {
            InternetSearchView()
                .environmentObject(player)
        }
    }
    
    private var bottomBar: some View {
        HStack(spacing: 0) {
            barButton(icon: "wand.and.stars", title: "动态专辑") {
                showDynamicAlbum = true
            }
            barButton(icon: "quote.bubble", title: "歌词") {
                showLyrics = true
            }
            barButton(icon: "magnifyingglass", title: "本地搜索") {
                showLocalSearch = true
            }
            barButton(icon: "globe", title: "互联网搜索") {
                showInternetSearch = true
            }
        }
        .padding(.vertical, 9)
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity)
        .frame(maxHeight: .infinity)
        .liquidGlassBar()
    }
    
    private func barButton(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .semibold))
                    .frame(height: 22)
                Text(title)
                    .font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(BarButtonStyle())
        .accessibilityLabel(title)
    }
}

private struct BarButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.75 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}