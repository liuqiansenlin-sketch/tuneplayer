// RootView.swift
// 根视图：资料库列表 + 迷你播放条 + 底部三键 Liquid Glass 栏
//   左：动态专辑（全屏循环 mp4）  中：歌词（LRC 滚动渐变）  右：搜索
import SwiftUI

struct RootView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    @State private var showNowPlaying = false
    @State private var showDynamicAlbum = false
    @State private var showLyrics = false
    @State private var showSearch = false

    var body: some View {
        ZStack(alignment: .bottom) {
            LibraryView()

            VStack(spacing: 10) {
                if let song = player.currentSong {
                    miniPlayer(song: song)
                        .padding(.horizontal, 14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                bottomBar
                    .padding(.horizontal, 18)
                    .padding(.bottom, 6)
            }
            .animation(.spring(response: 0.36, dampingFraction: 0.86), value: player.currentSong?.url)
        }
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
        .fullScreenCover(isPresented: $showDynamicAlbum) {
            DynamicAlbumView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showLyrics) {
            LyricsView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showSearch) {
            SearchView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
    }

    // MARK: - 底部三键（同一个玻璃胶囊里）

    private var bottomBar: some View {
        HStack(spacing: 0) {
            barButton(icon: "wand.and.stars", title: "动态专辑") {
                showDynamicAlbum = true
            }
            barButton(icon: "quote.bubble", title: "歌词") {
                showLyrics = true
            }
            barButton(icon: "magnifyingglass", title: "搜索") {
                showSearch = true
            }
        }
        .padding(.vertical, 9)
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity)
        .liquidGlassBar()
    }

    private func barButton(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .semibold))
                    .frame(height: 22)
                Text(title)
                    .font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(BarButtonStyle())
        .accessibilityLabel(title)
    }

    // MARK: - 迷你播放条

    private func miniPlayer(song: Song) -> some View {
        HStack(spacing: 10) {
            Button { showNowPlaying = true } label: {
                HStack(spacing: 10) {
                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 9)
                        .frame(width: 44, height: 44)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(song.title)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text(song.artist ?? "未知艺人")
                            .font(.caption)
                            .foregroundStyle(.gray)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            GlassIconButton(systemName: player.isPlaying ? "pause.fill" : "play.fill",
                            font: .system(size: 15, weight: .semibold),
                            size: 38,
                            action: { player.togglePlayPause() })
            GlassIconButton(systemName: "forward.fill",
                            font: .system(size: 15, weight: .semibold),
                            size: 38,
                            action: { player.playNext() })
        }
        .padding(.horizontal, 10)
        .frame(height: 62)
        .liquidGlassRoundedRect(18)
        .shadow(color: .black.opacity(0.35), radius: 16, y: 4)
    }
}

/// 三键栏的按压反馈：轻微缩放 + 降透明度，模拟玻璃回弹
private struct BarButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.75 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}
