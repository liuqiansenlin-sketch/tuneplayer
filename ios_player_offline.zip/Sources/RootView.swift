// RootView.swift
// 入口根视图：Apple Music 风格 5 标签（首页 / 新歌 / 电台 / 资料库 / 搜索）
// + 迷你播放器（悬浮于标签栏上方）+ 全屏 Now Playing
import SwiftUI

struct RootView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    @State private var showNowPlaying = false

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView {
                HomeView()
                    .tabItem { Label("首页", systemImage: "house.fill") }

                BrowseView()
                    .tabItem { Label("新歌", systemImage: "sparkles") }

                RadioView()
                    .tabItem { Label("电台", systemImage: "dot.radiowaves.left.and.right") }

                LibraryView()
                    .tabItem { Label("资料库", systemImage: "music.note.list") }

                SearchView()
                    .tabItem { Label("搜索", systemImage: "magnifyingglass") }
            }
            .tint(.red)

            if let song = player.currentSong {
                miniPlayer(song: song)
                    .padding(.horizontal, 12)
                    .padding(.bottom, 58)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.spring(response: 0.36, dampingFraction: 0.86), value: player.currentSong?.url)
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environmentObject(player)
                .environmentObject(favorites)
        }
    }

    // MARK: - 迷你播放器（悬浮于标签栏上方，Apple Music 风格）

    @ViewBuilder
    private func miniPlayer(song: Song) -> some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.glassHighlight(0.08))
                .frame(width: 46, height: 46)
                .overlay(
                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8, album: song.album)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                )
            VStack(alignment: .leading, spacing: 2) {
                Text(song.title)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(song.artist ?? "未知艺人")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            HStack(spacing: 14) {
                Button { Haptics.medium(); player.togglePlayPause() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 28, height: 28)
                }
                .buttonStyle(PressableButtonStyle(scale: 0.88))
                Button { Haptics.light(); player.playNext() } label: {
                    Image(systemName: "forward.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 28, height: 28)
                }
                .buttonStyle(PressableButtonStyle(scale: 0.88))
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .liquidGlassRoundedRect(16)
        .contentShape(Rectangle())
        .onTapGesture {
            Haptics.light()
            showNowPlaying = true
        }
    }
}
