// SearchView.swift
// 搜索（Apple Music「Search」）：大标题 + 搜索框；空查询时展示"浏览全部"（专辑/艺人网格），输入后过滤歌曲
import SwiftUI

struct SearchView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    @State private var query = ""
    @FocusState private var focused: Bool

    private var results: [Song] {
        let keyword = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !keyword.isEmpty else { return [] }
        return player.songs.filter { song in
            song.title.localizedCaseInsensitiveContains(keyword)
                || (song.artist?.localizedCaseInsensitiveContains(keyword) ?? false)
                || (song.album?.localizedCaseInsensitiveContains(keyword) ?? false)
        }
    }

    private var albums: [String] {
        Array(Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })).sorted()
    }

    private var artists: [String] {
        Array(Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty })).sorted()
    }

    private var isSearching: Bool { !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                searchBar
                if isSearching {
                    searchResults
                } else {
                    browseSections
                }
            }
            .navigationTitle("搜索")
            .navigationBarTitleDisplayMode(.large)
            .background(Color(.systemBackground))
        }
    }

    // MARK: - 搜索框

    private var searchBar: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.secondary)

            TextField("歌曲、艺人或专辑", text: $query)
                .textFieldStyle(.plain)
                .foregroundStyle(.primary)
                .focused($focused)
                .submitLabel(.search)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)

            if !query.isEmpty {
                Button {
                    query = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("清除")
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 40)
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .padding(.bottom, 10)
    }

    // MARK: - 搜索结果

    @ViewBuilder
    private var searchResults: some View {
        if results.isEmpty {
            VStack {
                Spacer(minLength: 60)
                Text("没有找到“\(query)”")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.secondary)
                Text("试试其他关键词，或者导入更多音乐")
                    .font(.subheadline)
                    .foregroundStyle(.tertiary)
                    .padding(.top, 4)
                Spacer()
            }
        } else {
            List(results) { song in
                SongRowView(song: song, visibleOrder: results)
                    .environmentObject(player)
                    .environmentObject(favorites)
                    .listRowBackground(Color(.systemBackground))
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 150) }
        }
    }

    // MARK: - 浏览区（空查询时）

    private var browseSections: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if albums.isEmpty && artists.isEmpty {
                    VStack {
                        Spacer(minLength: 40)
                        Text("资料库中还没有内容")
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(.secondary)
                        Text("在资料库导入音乐后，这里会展示全部专辑与艺人")
                            .font(.subheadline)
                            .foregroundStyle(.tertiary)
                            .padding(.top, 4)
                        Spacer()
                    }
                }

                if !albums.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("浏览专辑")
                            .font(.title2.weight(.bold))
                            .padding(.horizontal, 16)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(albums, id: \.self) { album in
                                    NavigationLink {
                                        AlbumDetailView(album: album,
                                                        songs: player.songs.filter { $0.album == album })
                                    } label: {
                                        VStack(alignment: .leading, spacing: 6) {
                                            AlbumArtworkThumb(album: album, side: 140)
                                            Text(album)
                                                .font(.subheadline.weight(.semibold))
                                                .foregroundStyle(.primary)
                                                .lineLimit(2)
                                        }
                                        .frame(width: 140, alignment: .leading)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                    }
                }

                if !artists.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("浏览艺人")
                            .font(.title2.weight(.bold))
                            .padding(.horizontal, 16)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(artists, id: \.self) { artist in
                                    NavigationLink {
                                        ArtistDetailView(artist: artist,
                                                         songs: player.songs.filter { $0.artist == artist })
                                    } label: {
                                        HStack(spacing: 10) {
                                            ZStack {
                                                Circle()
                                                    .fill(Color(.systemGray5))
                                                Image(systemName: "person.fill")
                                                    .foregroundStyle(.secondary)
                                            }
                                            .frame(width: 58, height: 58)
                                            Text(artist)
                                                .font(.subheadline.weight(.semibold))
                                                .foregroundStyle(.primary)
                                                .lineLimit(2)
                                        }
                                        .padding(.horizontal, 14)
                                        .padding(.vertical, 8)
                                        .background(Color(.systemGray6))
                                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                    }
                }
            }
            .padding(.top, 6)
            .padding(.bottom, 90)
        }
    }
}
