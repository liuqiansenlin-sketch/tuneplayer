// BrowseView.swift
// 新歌（Apple Music「New / Top Charts」的离线实现）：随机播放 + Top 25 + 专辑浏览
import SwiftUI
import UniformTypeIdentifiers

struct BrowseView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @ObservedObject private var history = HistoryStore.shared

    @State private var showImporter = false

    private var topSongs: [Song] {
        history.topSongs(from: player.songs, limit: 25)
    }

    private var albums: [String] {
        Array(Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })).sorted()
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    if player.songs.isEmpty {
                        emptyState
                    } else {
                        surpriseMeCard
                        topChartsSection
                        albumsSection
                    }
                }
                .padding(.top, 8)
                .padding(.bottom, 90)
            }
            .navigationTitle("新歌")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showImporter = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .refreshable { await player.refreshLibrary() }
            .task { await player.refreshLibrary() }
            .background(Color(.systemBackground))
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [.audio],
                      allowsMultipleSelection: true) { result in
            if case .success(let urls) = result {
                Task { await player.importMusic(from: urls) }
            }
        }
    }

    // MARK: - 随机播放（Surprise Me）

    private var surpriseMeCard: some View {
        Button {
            Haptics.medium()
            let all = player.songs.shuffled()
            if let first = all.first {
                player.playSong(first, in: all)
            }
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    LinearGradient(
                        colors: [Color.red.opacity(0.85), Color.purple.opacity(0.85)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    Image(systemName: "shuffle")
                        .font(.system(size: 26, weight: .semibold))
                        .foregroundStyle(.white)
                }
                .frame(width: 72, height: 72)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                VStack(alignment: .leading, spacing: 4) {
                    Text("随机播放")
                        .font(.title3.weight(.bold))
                        .foregroundStyle(.primary)
                    Text("打乱播放整个资料库，来点新鲜感")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .padding(14)
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16)
    }

    // MARK: - Top 25（按播放次数）

    private var topChartsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("Top 25")
            Text("按播放次数排序")
                .font(.caption)
                .foregroundStyle(.tertiary)
                .padding(.horizontal, 16)
            VStack(spacing: 0) {
                ForEach(Array(topSongs.enumerated()), id: \.element.id) { index, song in
                    chartRow(index: index + 1, song: song)
                    if index < topSongs.count - 1 {
                        Divider().padding(.leading, 76)
                    }
                }
            }
            .padding(.vertical, 4)
            .background(Color(.systemGray6))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .padding(.horizontal, 16)
        }
    }

    private func chartRow(index: Int, song: Song) -> some View {
        Button {
            Haptics.light()
            player.playSong(song, in: topSongs)
        } label: {
            HStack(spacing: 12) {
                Text("\(index)")
                    .font(.headline.monospacedDigit().weight(.semibold))
                    .foregroundStyle(index <= 3 ? Color.red : Color(.secondaryLabel))
                    .frame(width: 26)
                ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8, album: song.album)
                    .frame(width: 46, height: 46)
                VStack(alignment: .leading, spacing: 2) {
                    Text(song.title)
                        .font(.body.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(song.artist ?? "未知艺人")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
                Text("\(history.count(for: song.url))")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: - 专辑

    private var albumsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("你的专辑")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(albums, id: \.self) { album in
                        NavigationLink {
                            AlbumDetailView(album: album,
                                            songs: player.songs.filter { $0.album == album })
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                AlbumArtworkThumb(album: album, side: 150)
                                Text(album)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                Text("\(player.songs.filter { $0.album == album }.count) 首歌曲")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            .frame(width: 150, alignment: .leading)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    private func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.title2.weight(.bold))
            .foregroundStyle(.primary)
            .padding(.horizontal, 16)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer(minLength: 40)
            Image(systemName: "sparkles")
                .font(.system(size: 52))
                .foregroundStyle(.secondary)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.primary)
            Text("点右上角 “+” 导入音乐后，这里会出现 Top 25")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
            Spacer(minLength: 40)
        }
        .frame(maxWidth: .infinity)
    }
}
