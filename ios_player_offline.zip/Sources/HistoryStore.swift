// HistoryStore.swift
// 播放历史 + 播放次数（Apple Music「最近播放 / Top 25」的离线实现）
// UserDefaults 持久化；与 AudioPlayerModel 通过单例握手
import Foundation
import Combine

@MainActor
final class HistoryStore: ObservableObject {
    static let shared = HistoryStore()

    @Published private(set) var playCounts: [String: Int] = [:]
    @Published private(set) var historyPaths: [String] = []

    private let countsKey = "playCounts"
    private let historyKey = "playHistory"
    private let maxHistory = 50

    private init() {
        load()
    }

    private func load() {
        if let data = UserDefaults.standard.data(forKey: countsKey),
           let decoded = try? JSONDecoder().decode([String: Int].self, from: data) {
            playCounts = decoded
        }
        historyPaths = UserDefaults.standard.stringArray(forKey: historyKey) ?? []
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(playCounts) {
            UserDefaults.standard.set(data, forKey: countsKey)
        }
        UserDefaults.standard.set(historyPaths, forKey: historyKey)
    }

    private func path(for url: URL) -> String { url.standardizedFileURL.path }

    func recordPlay(_ song: Song) {
        let p = path(for: song.url)
        playCounts[p, default: 0] += 1
        var history = historyPaths
        history.removeAll { $0 == p }
        history.append(p)
        if history.count > maxHistory {
            history.removeFirst(history.count - maxHistory)
        }
        historyPaths = history
        persist()
    }

    func count(for url: URL) -> Int { playCounts[path(for: url)] ?? 0 }

    /// 最近播放的歌曲（按最近顺序，去重）
    func recentSongs(from library: [Song], limit: Int = 20) -> [Song] {
        var byPath: [String: Song] = [:]
        for song in library { byPath[path(for: song.url)] = song }
        var result: [Song] = []
        for p in historyPaths.reversed() {
            if let song = byPath[p] { result.append(song) }
            if result.count >= limit { break }
        }
        return result
    }

    /// Top 25：按播放次数排序；没播过任何歌时退回资料库前 25 首
    func topSongs(from library: [Song], limit: Int = 25) -> [Song] {
        let played = library
            .filter { count(for: $0.url) > 0 }
            .sorted { count(for: $0.url) > count(for: $1.url) }
        if played.isEmpty { return Array(library.prefix(limit)) }
        return Array(played.prefix(limit))
    }

    /// 按次数排序的全部歌曲
    func rankedSongs(from library: [Song]) -> [Song] {
        library.sorted { count(for: $0.url) > count(for: $1.url) }
    }
}
