// Song.swift
// 资料库中的一首歌曲（无需持久化，启动时扫描重建）
import Foundation

struct Song: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let title: String
    let artist: String?
    let album: String?
    let durationSeconds: TimeInterval
    /// 动态专辑视频（同名 mp4/mov 或 Videos/ 里的默认视频）；nil → 用 Canvas 动态视觉
    let videoURL: URL?

    var formattedDuration: String {
        let total = Int(durationSeconds.rounded())
        let m = total / 60
        let s = total % 60
        return String(format: "%d:%02d", m, s)
    }
}
