// ArtworkStore.swift
// 真实封面：从每个音频文件的 ID3/MP4 标签读取专辑封面（.commonKeyArtwork）
// NSCache 缓存 UIImage，重复进入不再解码
import Foundation
import AVFoundation
import UIKit

final class ArtworkStore: @unchecked Sendable {
    static let shared = ArtworkStore()

    private let imageCache = NSCache<NSURL, UIImage>()
    private init() {
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 64 * 1024 * 1024 // 64MB
    }

    /// 同步看缓存（不命中返回 nil，不解码）
    func cachedImage(for url: URL) -> UIImage? {
        imageCache.object(forKey: url as NSURL)
    }

    /// 异步读取封面；找不到返回 nil（上层继续显示占位图）
    func image(for url: URL) async -> UIImage? {
        if let cached = imageCache.object(forKey: url as NSURL) { return cached }
        guard let data = await Self.readArtworkData(at: url), let image = UIImage(data: data) else {
            return nil
        }
        imageCache.setObject(image, forKey: url as NSURL, cost: data.count)
        return image
    }

    private static func readArtworkData(at url: URL) async -> Data? {
        let asset = AVURLAsset(url: url)
        let metadata = asset.commonMetadata
        for item in metadata {
            guard let key = item.commonKey?.rawValue, key == "artwork" else { continue }
            if let raw = try? await item.load(.value), let data = raw as? Data {
                return data
            }
        }
        return nil
    }
}
