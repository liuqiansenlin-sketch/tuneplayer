// LoopingVideoView.swift
// 无缝循环、静音、无控件的动态封面视频层（AVQueuePlayer + AVPlayerLooper）
// 用 UIViewRepresentable 包装 AVQueuePlayer 的 AVPlayerLayer
import SwiftUI
import AVFoundation

struct LoopingVideoView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> LoopingPlayerUIView {
        let view = LoopingPlayerUIView(url: url)
        return view
    }

    func updateUIView(_ uiView: LoopingPlayerUIView, context: Context) {
        // url 不随组件更新而变化（歌曲变化时上层用 .id() 强制重建）
    }

    static func dismantleUIView(_ uiView: LoopingPlayerUIView, coordinator: ()) {
        uiView.stop()
    }
}

final class LoopingPlayerUIView: UIView {
    private(set) var queuePlayer: AVQueuePlayer?
    private var looper: AVPlayerLooper?
    private let playerLayer = AVPlayerLayer()

    init(url: URL) {
        super.init(frame: .zero)
        backgroundColor = .clear
        isOpaque = false
        setup(url: url)
    }

    required init?(coder: NSCoder) { fatalError("LoopingPlayerUIView 必须用代码初始化") }

    private func setup(url: URL) {
        let item = AVPlayerItem(url: url)
        let queue = AVQueuePlayer()
        // 无限循环播放（AVFoundation 内置循环机制，过渡最平滑）
        looper = AVPlayerLooper(player: queue, templateItem: item)
        queue.isMuted = true
        queue.automaticallyWaitsToMinimizeStalling = true
        queuePlayer = queue

        playerLayer.player = queue
        playerLayer.videoGravity = .resizeAspectFill
        playerLayer.backgroundColor = UIColor.clear.cgColor
        layer.addSublayer(playerLayer)

        queue.play()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        playerLayer.frame = bounds
    }

    func stop() {
        queuePlayer?.pause()
        looper?.disableLooping()
        queuePlayer = nil
        looper = nil
    }
}
