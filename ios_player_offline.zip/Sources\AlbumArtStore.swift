// AlbumArtStore.swift
// 专辑封面：用户为专辑手动添加的图片，存到 Documents/Covers/Albums/<专辑名>.jpg
// NSCache 缓存 UIImage；导入/移除后 revision +1，视图把 revision 纳入 task id 以触发重载
import Foundation
import UIKit

final class AlbumArtStore: @unchecked Sendable {
    static let shared = AlbumArtStore()

    private let cache = NSCache<NSString, UIImage>()
    private let io = DispatchQueue(label: "AlbumArtStore", qos: .utility)
    /// 每次导入/移除封面时 +1
    private(set) var revision = 0

    private init() {
        cache.countLimit = 60
        cache.totalCostLimit = 32 * 1024 * 1024
    }

    static func folderURL() -> URL? {
        guard let docs = try? FileManager.default.url(for: .documentDirectory,
                                                      in: .userDomainMask,
                                                      appropriateFor: nil,
                                                      create: true) else { return nil }
        let dir = docs.appendingPathComponent("Covers/Albums", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    private func sanitized(_ name: String) -> String {
        let invalid = CharacterSet(charactersIn: "/:\\?%*|\"<>")
        let cleaned = name.components(separatedBy: invalid).joined()
        return cleaned.isEmpty ? "未命名专辑" : cleaned
    }

    func fileURL(for album: String) -> URL? {
        guard let dir = Self.folderURL() else { return nil }
        return dir.appendingPathComponent(sanitized(album) + ".jpg")
    }

    func cachedImage(for album: String) -> UIImage? {
        cache.object(forKey: album as NSString)
    }

    /// 异步读取专辑封面；未设置返回 nil（上层回退到歌曲标签封面/占位图）
    func image(for album: String) async -> UIImage? {
        if let cached = cachedImage(for: album) { return cached }
        guard let url = fileURL(for: album),
              let data = try? Data(contentsOf: url),
              let img = UIImage(data: data) else { return nil }
        cache.setObject(img, forKey: album as NSString, cost: data.count)
        return img
    }

    /// 复制用户选中的图片作为专辑封面（替换旧封面）
    func importCover(from sourceURL: URL, for album: String) {
        io.sync {
            let needStop = sourceURL.startAccessingSecurityScopedResource()
            defer { if needStop { sourceURL.stopAccessingSecurityScopedResource() } }
            guard let data = try? Data(contentsOf: sourceURL),
                  let img = UIImage(data: data),
                  let jpeg = img.jpegData(compressionQuality: 0.9),
                  let dest = self.fileURL(for: album) else { return }
            if FileManager.default.fileExists(atPath: dest.path) {
                try? FileManager.default.removeItem(at: dest)
            }
            try? jpeg.write(to: dest, options: .atomic)
            self.cache.setObject(img, forKey: album as NSString, cost: jpeg.count)
        }
        revision += 1
    }

    func removeCover(for album: String) {
        io.sync {
            if let url = self.fileURL(for: album) {
                try? FileManager.default.removeItem(at: url)
            }
            self.cache.removeObject(forKey: album as NSString)
        }
        revision += 1
    }
}
