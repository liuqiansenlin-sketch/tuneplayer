﻿// QueueView.swift
// 播放队列（Up Next）Sheet：展示队列、拖动重排、点击跳转
import SwiftUI

struct QueueView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.editMode) private var editMode

    private var queue: [Song] { player.queue }

    var body: some View {
        NavigationStack {
            Group {
                if queue.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "play.square.stack")
                            .font(.system(size: 46))
                            .foregroundStyle(.gray)
                        Text("队列是空的")
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("在资料库中点任意一首歌开始")
                            .font(.subheadline)
                            .foregroundStyle(.gray)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(Array(queue.enumerated()), id: \.element.id) { index, song in
                            let isCurrent = index == player.currentIndex
                            Button {
                                player.playQueueItem(at: index)
                                dismiss()
                            } label: {
                                HStack(spacing: 12) {
                                    // 当前曲用红色图标 + 音量波形
                                    if isCurrent {
                                        Image(systemName: "speaker.wave.2.fill")
                                            .font(.system(size: 15))
                                            .foregroundStyle(.red)
                                            .frame(width: 24)
                                    } else {
                                        Text("\(index + 1)")
                                            .font(.caption.monospacedDigit())
                                            .foregroundStyle(.gray)
                                            .frame(width: 24)
                                    }
                                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 6, album: song.album)
                                        .frame(width: 44, height: 44)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(song.title)
                                            .font(.body.weight(.semibold))
                                            .foregroundStyle(isCurrent ? .red : .white)
                                            .lineLimit(1)
                                        Text(song.artist ?? "未知艺人")
                                            .font(.subheadline)
                                            .foregroundStyle(.gray)
                                            .lineLimit(1)
                                    }
                                    Spacer()
                                    Text(song.formattedDuration)
                                        .font(.caption.monospacedDigit())
                                        .foregroundStyle(.gray)
                                }
                            }
                            .listRowBackground(Color(red: 0.09, green: 0.09, blue: 0.10))
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                Button(role: .destructive) {
                                    player.removeFromQueue(at: index)
                                } label: {
                                    Label("删除", systemImage: "trash")
                                }
                            }
                        }
                        .onMove(perform: player.moveQueueItems(from:to:))
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.plain)
                }
            }
            .navigationTitle("播放队列")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Text("\(queue.count) 首")
                        .font(.footnote.monospacedDigit())
                        .foregroundStyle(.gray)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    if !queue.isEmpty { EditButton() }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
}
