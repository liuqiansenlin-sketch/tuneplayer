import SwiftUI

// iOS 17+ 才有的 presentationBackgroundInteraction 的兼容封装
private struct BackgroundInteractionModifier: ViewModifier {
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.presentationBackgroundInteraction(.enabled)
        } else {
            content
        }
    }
}

private extension View {
    func sheetBackgroundInteraction() -> some View {
        modifier(BackgroundInteractionModifier())
    }
}

struct RootView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    @State private var showNowPlaying = false
    @State private var showDynamicAlbum = false
    @State private var showLyrics = false
    @State private var showLocalSearch = false
    @State private var showInternetSearch = false

    var body: some View {
        ZStack(alignment: .bottom) {
            LibraryView()

            VStack(spacing: 10) {
                if let song = player.currentSong {
                    miniPlayer(song: song)
                        .padding(.horizontal, 14)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                bottomBar
                    .padding(.horizontal, 18)
                    .padding(.bottom, 6)
            }
            .animation(.spring(response: 0.36, dampingFraction: 0.86), value: player.currentSong?.url)
        }
        // Apple Music 风格：sheet + presentationDetents([.large]) + presentationBackgroundInteraction(.enabled)
        .sheet(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environmentObject(player)
                .environmentObject(favorites)
                .presentationDetents([.large])
                .sheetBackgroundInteraction()
        }
        .sheet(isPresented: $showDynamicAlbum) {
            DynamicAlbumView()
                .environmentObject(player)
                .presentationDetents([.large])
                .sheetBackgroundInteraction()
        }
        .sheet(isPresented: $showLyrics) {
            LyricsView()
                .environmentObject(player)
                .presentationDetents([.large])
                .sheetBackgroundInteraction()
        }
        .sheet(isPresented: $showLocalSearch) {
            LocalSearchView()
                .environmentObject(player)
                .environmentObject(favorites)
                .presentationDetents([.large])
                .sheetBackgroundInteraction()
        }
        .sheet(isPresented: $showInternetSearch) {
            InternetSearchView()
                .environmentObject(player)
                .presentationDetents([.large])
                .sheetBackgroundInteraction()
        }
    }

    // MARK: - 底部迷你播放器（当前歌曲）

    @ViewBuilder
    private func miniPlayer(song: Song) -> some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.white.opacity(0.08))
                .frame(width: 46, height: 46)
                .overlay(
                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                )
            VStack(alignment: .leading, spacing: 2) {
                Text(song.title)
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(song.artist ?? "未知艺人")
                    .font(.subheadline)
                    .foregroundStyle(.gray)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            Button {
                showNowPlaying = true
            } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.6))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 6)
        .background(Color.black.opacity(0.5), in: RoundedRectangle(cornerRadius: 16))
    }

    private var bottomBar: some View {
        HStack(spacing: 0) {
            barButton(icon: "wand.and.stars", title: "动态专辑") {
                showDynamicAlbum = true
            }
            barButton(icon: "quote.bubble", title: "歌词") {
                showLyrics = true
            }
            barButton(icon: "magnifyingglass", title: "本地搜索") {
                showLocalSearch = true
            }
            barButton(icon: "globe", title: "互联网搜索") {
                showInternetSearch = true
            }
        }
        .padding(.vertical, 9)
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity)
        .frame(maxHeight: .infinity)
        .liquidGlassBar()
    }

    private func barButton(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .semibold))
                    .frame(height: 22)
                Text(title)
                    .font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(BarButtonStyle())
        .accessibilityLabel(title)
    }
}

private struct BarButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.75 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}