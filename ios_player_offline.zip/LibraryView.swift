// LibraryView.swift
// 资料库：Apple Music「Library」风格 —— 大标题 + 分类入口（歌曲/专辑/艺人/已收藏）
import SwiftUI
import UniformTypeIdentifiers

// MARK: - 分类

enum LibraryCategory: String, CaseIterable, Identifiable {
    case songs, albums, artists, favorites

    var id: String { rawValue }

    var title: String {
        switch self {
        case .songs: return "歌曲"
        case .albums: return "专辑"
        case .artists: return "艺人"
        case .favorites: return "已收藏"
        }
    }

    var icon: String {
        switch self {
        case .songs: return "music.note"
        case .albums: return "square.stack"
        case .artists: return "person.2"
        case .favorites: return "heart.fill"
        }
    }

    var color: Color {
        switch self {
        case .songs: return .red
        case .albums: return .blue
        case .artists: return .orange
        case .favorites: return .pink
        }
    }
}

// MARK: - 资料库首页

struct LibraryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @State private var showImporter = false

    var body: some View {
        NavigationStack {
            Group {
                if player.songs.isEmpty {
                    emptyState
                } else {
                    libraryList
                }
            }
            .navigationTitle("资料库")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    // 只保留一个干净的“+”，没有底色、没有外框
                    Button { showImporter = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [.audio],
                          allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls):
                    Task { await player.importMusic(from: urls) }
                case .failure(let error):
                    print("导入失败：\(error)")
                }
            }
            .refreshable { await player.loadLibrary() }
            .background(Color.black)
        }
        .task { await player.loadLibrary() }
    }

    private var libraryList: some View {
        List {
            Section {
                ForEach(LibraryCategory.allCases.filter { $0 != .songs }) { category in
                    NavigationLink {
                        LibraryCategoryView(category: category)
                            .environmentObject(player)
                            .environmentObject(favorites)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: category.icon)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(.white)
                                .frame(width: 30, height: 30)
                                .background(category.color,
                                            in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            Text(category.title)
                                .font(.body.weight(.medium))
                                .foregroundStyle(.white)
                            Spacer(minLength: 0)
                            Text(countText(for: category))
                                .font(.subheadline)
                                .foregroundStyle(.gray)
                        }
                        .padding(.vertical, 3)
                    }
                    .listRowBackground(Color.black)
                }
            }
            .listRowSeparator(.hidden)
            .contextMenu {  // 长按分类入口显示操作菜单
                Button { /* TODO: 新增歌曲 */ }
                label: {
                    Label("新增歌曲", systemImage: "plus")
                }
                Button { /* TODO: 管理库 */ }
                label: {
                    Label("管理", systemImage: "folder")
                }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        // 给底部迷你播放条 + 三键栏留出空间，列表最后一行不被遮住
        .safeAreaInset(edge: .bottom) {
            Color.clear.frame(height: 150)
        }
    }

    private func countText(for category: LibraryCategory) -> String {
        switch category {
        case .albums:
            let albums = Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })
            return "\(albums.count)"
        case .artists:
            let artists = Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty })
            return "\(artists.count)"
        case .favorites:
            let count = player.songs.filter { favorites.isFavorite($0.url) }.count
            return "\(count)"
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}