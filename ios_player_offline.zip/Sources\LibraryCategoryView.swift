// LibraryCategoryView.swift
// 资料库分类详情页：albums / artists / favorites
import SwiftUI
import UniformTypeIdentifiers

struct LibraryCategoryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let category: LibraryCategory

    var body: some View {
        List {
            switch category {
            case .albums:
                albumsSection
            case .artists:
                artistsSection
            case .favorites:
                favoritesSection
            case .songs:
                songsSection
            }
        }
        .navigationTitle(category.title)
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(Color.black)
    }

    private var albumsSection: some View {
        let albums = Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })
            .sorted()
        return ForEach(albums, id: \.self) { album in
            NavigationLink {
                AlbumDetailView(album: album, songs: player.songs.filter { $0.album == album })
                    .environmentObject(player)
                    .environmentObject(favorites)
            } label: {
                HStack(spacing: 12) {
                    AlbumArtworkThumb(album: album)
                        .frame(width: 44, height: 44)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(album)
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text("\(player.songs.filter { $0.album == album }.count) 首歌曲")
                            .font(.caption)
                            .foregroundStyle(.gray)
                    }
                }
            }
        }
    }

    private var artistsSection: some View {
        let artists = Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty })
            .sorted()
        return ForEach(artists, id: \.self) { artist in
            NavigationLink {
                ArtistDetailView(artist: artist, songs: player.songs.filter { $0.artist == artist })
                    .environmentObject(player)
                    .environmentObject(favorites)
            } label: {
                HStack {
                    Image(systemName: "person.2.fill")
                        .foregroundStyle(.orange)
                    Text(artist)
                        .foregroundStyle(.white)
                    Spacer()
                    Text("\(player.songs.filter { $0.artist == artist }.count)")
                        .foregroundStyle(.gray)
                }
            }
        }
    }

    private var favoritesSection: some View {
        let favoritedSongs = player.songs.filter { favorites.isFavorite($0.url) }
        if favoritedSongs.isEmpty {
            return AnyView(emptyFavoritesView)
        }
        return AnyView(
            ForEach(favoritedSongs) { song in
                SongRowView(song: song, visibleOrder: favoritedSongs)
                    .environmentObject(player)
                    .environmentObject(favorites)
            }
        )
    }

    private var songsSection: some View {
        let songs = player.songs
        if songs.isEmpty {
            return AnyView(emptySongsView)
        }
        return AnyView(
            ForEach(songs) { song in
                SongRowView(song: song, visibleOrder: songs)
                    .environmentObject(player)
                    .environmentObject(favorites)
            }
        )
    }

    private var emptyFavoritesView: some View {
        VStack(spacing: 20) {
            Image(systemName: "heart")
                .font(.system(size: 48))
                .foregroundStyle(.gray)
            Text("没有收藏的歌曲")
                .font(.title3.weight(.medium))
                .foregroundStyle(.white)
            Text("在播放页点击心形图标即可收藏")
                .font(.subheadline)
                .foregroundStyle(.gray)
        }
        .listRowBackground(Color.clear)
        .frame(maxWidth: .infinity, minHeight: 200)
    }

    private var emptySongsView: some View {
        VStack(spacing: 20) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
        }
        .listRowBackground(Color.clear)
        .frame(maxWidth: .infinity, minHeight: 200)
    }
}

// MARK: - AlbumArtworkThumb
/// 专辑缩略封面：有自定义封面显示图片，否则显示渐变占位
struct AlbumArtworkThumb: View {
    let album: String
    @State private var image: UIImage?

    init(album: String) {
        self.album = album
        _image = State(initialValue: nil)
    }

    var body: some View {
        ZStack {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .transition(.opacity)
            } else {
                LinearGradient(
                    colors: [
                        Color(hue: ArtworkSeed.value(album), saturation: 0.55, brightness: 0.78),
                        Color(hue: (ArtworkSeed.value(album) + 0.12).truncatingRemainder(dividingBy: 1), saturation: 0.62, brightness: 0.42),
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                Image(systemName: "square.stack")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.9))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
        .task(id: "\(album)|\(AlbumArtStore.shared.revision)") {
            image = await AlbumArtStore.shared.image(for: album)
        }
    }
}

// MARK: - AlbumDetailView
struct AlbumDetailView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let album: String
    let songs: [Song]

    @State private var showCoverImporter = false
    @State private var artworkRevision = 0

    var body: some View {
        List {
            Section {
                headerRow
                    .listRowBackground(Color.clear)
                ForEach(Array(songs.enumerated()), id: \.element.id) { index, song in
                    SongRowView(song: song, visibleOrder: songs, position: index + 1)
                        .environmentObject(player)
                        .environmentObject(favorites)
                }
            } header: {
                Text("歌曲")
            }
        }
        .navigationTitle(album)
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(Color.black)
        .fileImporter(isPresented: $showCoverImporter,
                      allowedContentTypes: [.image],
                      allowsMultipleSelection: false) { result in
            if case .success(let urls) = result, let url = urls.first {
                player.addAlbumArtwork(album, from: url)
                artworkRevision += 1
            }
        }
    }

    private var headerRow: some View {
        HStack(spacing: 14) {
            AlbumArtworkThumb(album: album)
                .id(artworkRevision)
                .frame(width: 96, height: 96)
            VStack(alignment: .leading, spacing: 6) {
                Text(album)
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                Text("\(songs.count) 首歌曲")
                    .font(.subheadline)
                    .foregroundStyle(.gray)
                Button {
                    showCoverImporter = true
                } label: {
                    Label(hasCover ? "更换专辑封面" : "添加专辑封面", systemImage: "photo.on.rectangle")
                        .font(.footnote.weight(.medium))
                }
                .buttonStyle(.bordered)
                .tint(.red)
                .padding(.top, 2)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 8)
        .id(artworkRevision)
    }

    private var hasCover: Bool {
        // 检查缓存中是否有该专辑的封面
        if AlbumArtStore.shared.cachedImage(for: album) != nil {
            return true
        }
        // 检查该专辑下第一首歌的标签封面
        if let firstSong = songs.first,
           let cached = ArtworkStore.shared.cachedImage(for: firstSong.url) {
            return true
        }
        return false
    }
}

// MARK: - ArtistDetailView
struct ArtistDetailView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let artist: String
    let songs: [Song]

    var body: some View {
        List {
            Section {
                ForEach(songs) { song in
                    SongRowView(song: song, visibleOrder: songs)
                        .environmentObject(player)
                        .environmentObject(favorites)
                }
            } header: {
                HStack {
                    Image(systemName: "person.2.fill")
                        .foregroundStyle(.orange)
                    Text(artist)
                        .font(.headline)
                        .foregroundStyle(.white)
                }
            }
        }
        .navigationTitle(artist)
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(Color.black)
    }
}

// MARK: - SongRowView
struct SongRowView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    let song: Song
    let visibleOrder: [Song]
    let position: Int?

    @State private var showingEditSheet: Bool = false

    init(song: Song, visibleOrder: [Song], position: Int? = nil) {
        self.song = song
        self.visibleOrder = visibleOrder
        self.position = position
    }

    private var isFavorite: Bool {
        favorites.isFavorite(song.url)
    }

    var body: some View {
        Button {
            player.playSong(song, in: visibleOrder)
        } label: {
            HStack(spacing: 12) {
                Group {
                    if let position {
                        Text("\(position)")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.gray)
                            .frame(width: 22)
                    } else {
                        Image(systemName: "music.note")
                            .foregroundStyle(.gray)
                            .frame(width: 22)
                    }
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(song.title)
                        .font(.body.weight(.medium))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                    HStack {
                        Text(song.artist ?? "")
                            .font(.caption)
                            .foregroundStyle(.gray)
                            .lineLimit(1)
                        Spacer()
                        Text(song.formattedDuration)
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.gray)
                    }
                }

                Button {
                    favorites.toggleFavorite(song.url)
                } label: {
                    Image(systemName: isFavorite ? "heart.fill" : "heart")
                        .foregroundStyle(isFavorite ? .red : .gray)
                }
                .buttonStyle(.plain)
            }
            .padding(.vertical, 4)
        }
        .listRowBackground(Color.clear)
        .buttonStyle(.plain)
        .contextMenu {
            Button {
                player.addToQueue(song)
            } label: {
                Label("加入队列", systemImage: "plus")
            }
            Button {
                player.insertSongAfterCurrent(song)
            } label: {
                Label("插播", systemImage: "text.insert")
            }
            Button {
                favorites.toggleFavorite(song.url)
            } label: {
                Label(isFavorite ? "取消收藏" : "收藏", systemImage: isFavorite ? "heart.slash" : "heart")
            }
            Button {
                showingEditSheet = true
            } label: {
                Label("编辑信息", systemImage: "pencil")
            }
            Button(role: .destructive) {
                player.deleteSong(song)
            } label: {
                Label("删除", systemImage: "trash")
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            SongEditSheet(song: song)
                .environmentObject(player)
        }
    }
}