// SearchView.swift
// 本地搜索：点进来自动弹出键盘，按标题 / 艺人 / 专辑过滤，点结果立即播放
import SwiftUI

struct LocalSearchView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @Environment(\.dismiss) private var dismiss

    @State private var query = ""
    @FocusState private var focused: Bool

    private var results: [Song] {
        let keyword = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !keyword.isEmpty else { return player.songs }
        return player.songs.filter { song in
            song.title.localizedCaseInsensitiveContains(keyword)
                || (song.artist?.localizedCaseInsensitiveContains(keyword) ?? false)
                || (song.album?.localizedCaseInsensitiveContains(keyword) ?? false)
        }
    }

    var body: some View {
        ZStack {
            background
            VStack(spacing: 0) {
                header
                searchField
                resultsList
            }
        }
        // 搜索页：快滑（速度大）返回上级；慢滑继续浏览列表
        .simultaneousGesture(
            DragGesture(minimumDistance: 10)
                .onChanged { _ in }
                .onEnded { value in
                    guard !focused else { return }
                    let height = value.translation.height
                    let velocity = value.predictedEndTranslation.height - height
                    if height > 0 && velocity > 600 {
                        withAnimation(.easeOut(duration: 0.2)) {
                            dismiss()
                        }
                    }
                }
        )
        .onAppear {
            // 进来就聚焦输入框，直接弹键盘
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                focused = true
            }
        }
    }

    // MARK: - 顶部

    private var header: some View {
        HStack {
            Text("搜索")
                .font(.largeTitle.weight(.bold))
                .foregroundStyle(.white)
            Spacer()
            GlassIconButton(systemName: "chevron.down",
                            font: .system(size: 14, weight: .semibold),
                            size: 38,
                            action: { dismiss() })
        }
        .padding(.horizontal, 20)
        .padding(.top, 14)
        .padding(.bottom, 10)
    }

    // MARK: - 搜索框

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.55))

            TextField("歌曲、艺人或专辑", text: $query)
                .textFieldStyle(.plain)
                .foregroundStyle(.white)
                .focused($focused)
                .submitLabel(.search)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)

            if !query.isEmpty {
                Button {
                    query = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.white.opacity(0.5))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("清除")
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 44)
        .liquidGlassRoundedRect(14)
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    // MARK: - 结果

    @ViewBuilder
    private var resultsList: some View {
        if player.songs.isEmpty {
            emptyHint("资料库里还没有歌")
        } else if results.isEmpty {
            emptyHint("没有找到“\(query)”")
        } else {
            List(results) { song in
                Button {
                    player.playSong(song, in: player.songs)
                    dismiss()
                } label: {
                    HStack(spacing: 12) {
                        ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8)
                            .frame(width: 46, height: 46)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(song.title)
                                .font(.body.weight(.semibold))
                                .foregroundStyle(.white)
                                .lineLimit(1)
                            Text([song.artist, song.album].compactMap { $0 }.joined(separator: " · "))
                                .font(.subheadline)
                                .foregroundStyle(.gray)
                                .lineLimit(1)
                        }
                        Spacer(minLength: 0)
                        if player.currentSong?.url == song.url {
                            Image(systemName: "speaker.wave.2.fill")
                                .foregroundStyle(.red)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
        }
    }

    private func emptyHint(_ text: String) -> some View {
        VStack {
            Spacer()
            Text(text)
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white.opacity(0.6))
            Spacer()
            Spacer()
        }
    }

    private var background: some View {
        LinearGradient(
            colors: [
                Color(red: 0.10, green: 0.06, blue: 0.16),
                Color(red: 0.04, green: 0.02, blue: 0.06),
                .black
            ],
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea()
    }
}
