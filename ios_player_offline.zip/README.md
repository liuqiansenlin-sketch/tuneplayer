# TunePlayer（调音播放器）— iPhone 原生音乐播放器

一个干净的、面向 iPhone 的本地音乐播放器。
**Apple Music 风格 + iOS 26 Liquid Glass**，本地“动态专辑封面”视频，可 shuffle / repeat，有专辑封面的锁屏页。
用 **SwiftUI + AVFoundation** 写成的原生 App，代码全部在 `Sources/`，无第三方依赖。

## 亮点

- 🔀 **随机播放 + 循环/单曲循环**：全屏页两个 Liquid Glass 按钮（红=生效），队列内随机避重复
- 🔒 **锁屏封面**：`MPNowPlayingInfoCenter` 现在带专辑封面（读不到时先显示锁屏文字，随后异步补上）
- 🎨 **动态专辑视频（核心）**：全屏播放页的封面是“活”的——
  有同名视频时为你循环播放（Apple Music Motion Artwork 的本地实现）；
  没有视频时播放由歌曲种子驱动的确定性极光画面（`TimelineView + Canvas`，零素材）
- 🫗 **iOS 26 Liquid Glass 液态玻璃按键**：全屏页控制键、迷你播放条、导航栏“+”全部是折射玻璃
  （`#available(iOS 26, *)`，旧系统自动退回磨砂玻璃）
- 🖼️ **真实 ID3 封面**：自动读取每首歌的专辑封面（`ArtworkStore` + NSCache），没封面时用稳定色调占位
- ❤️ **收藏功能**：列表行 ♡ / Now Playing 页 ♡，资料库顶部「全部 / 已收藏」筛选
- ⏯ **续播记忆**：暂停/退出后重开，自动从上次停的位置继续；听完自动清除记忆
- ⏭️ **播放队列（Up Next）**：资料库某行开始 → 以“当前可见顺序”建队列；队列页支持拖动重排、点击跳转（右上角 `play.square.stack` 图标打开）
- 后台播放、锁屏控制、耳机线控（`AVAudioSession.playback` + `MPNowPlayingInfoCenter` + `MPRemoteCommandCenter`）
- 中断处理（打电话回来自动暂停）
- 无需任何权限（不读系统音乐库、不要相册/相机）；只读 **App 自己的 Documents/Music**
- 文件导入：右上角 “+” → 从“文件”App 选择你的歌；或“文件”长按 → 分享 → TunePlayer（App 内）
- 从名字推断稳定封面底色（不依赖 ID3 封面，最稳）
- Dark Mode 全屏播放页，滑动进度、左右切歌、3 秒规则（回退到上一首）

## 环境要求

- macOS + **Xcode 15+**（部署目标 **iOS 16.0+**，约等 iPhone 8/X 以后）
- 命令行工具：`xcode-select --install`（如需要）
- **XcodeGen**：`brew install xcodegen`
- 若你选择走 **TestFlight** 分发：需要 **99 美元/年 Apple Developer Program**
- 若只是自己 + 朋友使用：**免费 Apple ID** 即可（但有团队签名限制，见下文）

## 从零到手机上（5 分钟）

```bash
# 1. 装 XcodeGen（首次）
brew install xcodegen

# 2. 生成 Xcode 工程
cd ios_player
xcodegen

# 3. 打开工程
open TunePlayer.xcodeproj
```

然后在 Xcode 中：

1. 左侧选 **TunePlayer** → ▸ **Signing & Capabilities** →
   **Team** 选你的 Apple ID（没有就在 Xcode → Settings → Accounts → + 登录）
   如提示 **Bundle Identifier** 不可用，改成 `com.<你的名字>.tuneplayer`
2. USB 连接 iPhone（或同一 WiFi 下无线调试），手机上允许“信任此电脑”
3. iPhone 首次安装需要在手机上：**设置 → 通用 → VPN 与设备管理 → 信任你的开发者应用**
4. 🔧 iOS 16+ 可能需要先在手机 **设置 → 隐私与安全性 → 开发者模式** 打开并重启
5. 点 Xcode 的 ▶ **Run**，装上手机

## ✨ 动态专辑视频（怎么用）

播放页里的封面是**动态的**，有两种来源（按优先级自动选择）：

1. **同名动态视频**（Apple Music 官方同款效果）：
   把 `晴天.mp3` 旁边的 `晴天.mp4` 放在同一文件夹（都在 `Documents/Music/` 里），
   或复制到 `Documents/Videos/` 下并保持同名（`晴天.mp4` / `.mov` / `.m4v`）。
   支持的格式：H.264 的 mp4 / mov / m4v；建议方形 1:1 或竖屏，5–20 秒循环。
   视频不必带声音——我们播放时始终静音，把声音留给歌曲本体。
2. **全局默认动态封面**：`Documents/Videos/_default.mp4`（或 `.mov`/`.m4v`）；
   所有没有专属视频的歌都会播放它。
3. **没有任何视频**：封面自动变成由歌曲名+路径哈希种子驱动的**确定性极光画面**
   （每次打开还是同一套配色与轨迹，不会闪、不会跳）。

> 导入视频的方法：先用“文件”App 里分享功能把 mp4 放进 TunePlayer 的 Documents/Videos，
> 再触发重新扫描（下拉刷新资料库，或重启 App）即可。

## 🫗 iOS 26 Liquid Glass

全屏播放页控制键、底部迷你播放条、导航栏 “+” 都是 iOS 26 液态玻璃（`.glassEffect` / `.buttonStyle`，
`GlassChrome.swift`）。在低于 iOS 26 的设备上会自动退回磨砂玻璃（`.ultraThinMaterial`），无需两套代码。
**想要最佳效果，请在 iPhone 上运行 iOS 26 并在 Xcode 里选择 iOS 26 SDK 构建。**

## 导入你的音乐

App 内“资料库”首页：

- 点右上角 **+** → 从“文件”选择 mp3/flac/m4a/wav 等 → 复制导入
- 或在“文件”App 中长按音频文件 → 分享 → 选择 **TunePlayer**（会回到 app 导入）

应用不访问系统音乐库，所以未经导入的歌不会出现。

## 分发给朋友

| 方案 | 费用 | 过期时间 | 朋友要做的 |
|---|---|---|---|
| **免费 Apple ID + 个人团队** | 免费 | 7 天（需重新签安装） | 安装时信任开发者证书；或让每位朋友在 Mac 上自行 `git pull && xcodegen && ▶ Run` |
| **Apple Developer Program + TestFlight** | 99 美元/年 | 90 天（构建有效期） | 在 TestFlight 点安装，打开即可用 |
| **Ad Hoc（付费开发者）** | 99 美元/年 | 1 年 | 你需要把朋友 iPhone 的 UDID 加入开发者账号再打包分发 |

结论：**最实用**的方式——朋友各自用免费 Apple ID 在各自 Mac 上自己签（`git clone && xcodegen` 即可），或者你（或你）付 99 美元开发者账号走 TestFlight。

## ☁️ 没有 Mac？云 Mac 方案

| 方案 | 计费 | 参考价 | 适合 |
|---|---|---|---|
| **GitHub Actions 公开仓库** | 按 runner 计时 | 公开仓库全免费；私有仓免费 2,000 分钟/月（macOS 系数 10×） | ✅ 最省心最便宜 |
| **Codemagic** | 按分钟 | 个人版免费 **500 分钟/月**（M2），超出 $0.095/min | ✅ 免费额够用 |
| **MacinCloud** | 小时/月 | Managed 起约 **$25/月**；macOS Tahoe、Xcode 预装、Windows RDP 可连 | ✅ 想远程看 Simulator 时选 |
| **AWS EC2 Mac 裸金属** | 专用主机，24 小时起订 | 约 $1–2/小时 | ❌ 个人过剩 |
| **MacStadium** | 企业裸金属包月 | 报价靠销售，$100+/月 | ❌ 企业才用 |
| **阿里/华为/腾讯 Mac 裸金属** | 定制申请 | 企业购买居多 | ❌ 个人通常拿不到 |

**⚠️ 云端 Mac 无法直接连上你的 iPhone**——云上只能：编译 → 产物下载 → 用免费 Apple ID 重新签名装到 iPhone（Sideloadly / AltStore / 3uTools），7 天过期重签一次。

### 路线 1（推荐，零成本）：GitHub Actions 自动编译 + Windows 侧载

`ios_player/.github/workflows/build.yml` 已经写好了，流程是：

```bash
# 1) 在 https://github.com 新建一个公开仓库（比如 tuneplayer）
# 2) 本地把该目录作为仓库根 push 上去（ios_player/ 即为仓库根）
git init && git add . && git commit -m "init" && git branch -M main
git remote add origin https://github.com/<你的用户名>/tuneplayer.git
git push -u origin main
# 3) 打开 GitHub → Actions → "Build iOS App" → 等一轮 macOS runner 跑完，下载 artifact
```

然后在 Windows PC 上：下载并安装 **[Sideloadly](https://sideloadly.io)** → 把 artifact 里的 `TunePlayer.app` 拖进去 → 输你的 Apple ID（免费） → 签名并自动装到 iPhone 上。第 1 次会让你在 iPhone 上信任证书（设置→通用→VPN 与设备管理）。
> 免费 Apple ID 签的 app 每 7 天过期，到期再签一次就行（同一台 PC 上同一天，只要 1 分钟）。

### 路线 2（付费，想远程看实机效果）：MacinCloud

1. 到 macincloud.com 注册、选 Managed 套餐（macOS Tahoe 选 macOS，配好 Xcode）
2. 用 Windows 的“远程桌面连接”或 VNC 登录到云 Mac
3. 按本 README 的「从零到手机上」步骤，在云端 Mac 上 `xcodegen` + ▶ Run（Simulator）
4. **注意**：云端 Mac 连不了你手机的 USB 线，所以正式真机测试还得靠产物下载 + Sideloadly 的方式走

## 🔧 在 Mac 上编译时可能遇到的问题（照着改就好）

本机（Windows）不能编译 Swift，所有代码都经过静态检查。第一次 Run 万一有小问题，按下面查：

1. **iOS 26 SDK：`.glassEffect` 符号名不对** → 改 `GlassChrome.swift` 里那几行即可；旧系统会自动退回磨砂玻璃
2. **`xcodegen` 报错** → 确认装了 `brew install xcodegen`；在 `ios_player` 目录下运行 `xcodegen`
3. **图标警告** → AppIcon 全套 9 个尺寸 + 1024 marketing 已随工程带，不应该报错
4. **锁屏两边两块信息** → 封面首次播放没有（缓存未热），暂停一次再播一次即自动补齐；或装了歌就直接能看见

## 📁 项目目录

```
ios_player/
├── project.yml            # XcodeGen 工程描述
├── Sources/
│   ├── TunePlayerApp.swift  # 入口（暗色模式 + 注入 AudioPlayerModel）
│   ├── Song.swift           # 歌曲模型（含 videoURL 动态封面字段）
│   ├── LibraryScanner.swift # 扫描 / 元数据（标题、艺术家、专辑、时长）+ 文件导入 + 视频解析
│   ├── DynamicVideoResolver.swift # 动态视频查找：同目录同名 → Documents/Videos/同名 → _default.*
│   ├── LoopingVideoView.swift     # UIViewRepresentable: AVQueuePlayer + AVPlayerLooper 无缝循环
│   ├── DynamicArtworkCanvas.swift # 没视频时的确定性流光画面（TimelineView+Canvas）
│   ├── ArtworkStore.swift   # 读取 ID3 专辑封面 + NSCache 缓存
│   ├── ArtworkView.swift    # 封面视图（有封面填充，无封面稳定色兜底）
│   ├── FavoritesStore.swift # 收藏持久化（按文件路径，UserDefaults JSON）
│   ├── AudioPlayerModel.swift # AVPlayer 封装 + 会话 + 锁屏（含 artwork）+ 队列 + shuffle/repeat
│   ├── GlassChrome.swift    # iOS 26 Liquid Glass（#available 回退磨砂玻璃）
│   ├── LibraryView.swift    # 资料库列表 + 真实封面 + 爱心收藏 + 全部/已收藏筛选
│   ├── QueueView.swift      # 播放队列 Up Next Sheet（拖动重排 + 点击跳转 + 当前曲高亮）
│   ├── NowPlayingView.swift # 全屏播放页（动态封面 + Liquid Glass 控制键 + 队列入口）
│   ├── RootView.swift       # Tab 根 + 迷你播放条（Liquid Glass 底部叠放）
│   └── Assets.xcassets/     # AppIcon（9 个标准尺寸 + 1024 marketing）
├── README.md
└── _tools/gen_icons.py      # 图标生成脚本（可选保留，不依赖 CI）
```

## 里程碑（下一阶段你关心的）

- [x] 🫗 iOS 26 Liquid Glass 全套按键（#available 回退磨砂玻璃）
- [x] 🎨 **动态专辑视频**（同名 mp4/mov + `_default` + 确定性 Canvas 兜底）
- [x] 🖼️ **真实 ID3 封面**（NSCache 缓存，无封面则稳定色兜底）
- [x] ❤️ **收藏 + 全部/已收藏筛选**
- [x] ⏯ **续播记忆**（听完自动清除）
- [x] ⏭️ **播放队列 Up Next**（拖动重排 + 点击跳转；筛选视图播收藏队列）
- [x] 🔀 **随机播放 + 循环/单曲循环**
- [x] 🔒 **锁屏专辑封面**（MPNowPlayingInfoCenter 带 artwork）
- [ ] 在 Mac 上 `xcodegen` + Run，确认 Liquid Glass 与动态封面在 iPhone 上跑起来
- [ ] 播放列表 / 收藏（local JSON 或 SwiftData）
- [ ] 歌词（lrc 同步滚动）可选
- [ ] TestFlight 分发

## 归档

旧版 Flutter 跨平台工程已移到工作区的 `archive/music_player/` 目录，不再维护；如需对照 UI/配色，可以从那里参考。

## 许可

个人的学习/使用/朋友间分发，随你的项目自由调整。
