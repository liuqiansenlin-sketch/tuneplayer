// LyricsView.swift
// 一键歌词：加载同名 .lrc（支持 [mm:ss.xx] 时间轴；同时间戳的第二行视为翻译行），
// Apple Music 风格滚动 + 当前行渐变高亮。
// 歌词目录：Documents/Lyrics/<歌曲名>.lrc（页面内可导入），或与音频同目录同名 .lrc
import SwiftUI
import Foundation
import UniformTypeIdentifiers

struct LyricLine: Identifiable {
    let id: Int
    let time: TimeInterval
    let text: String
    let translation: String?
}

enum LyricsLoader {
    /// Documents/Lyrics（不存在则创建）
    static func folderURL() -> URL? {
        guard let docs = try? FileManager.default.url(for: .documentDirectory,
                                                      in: .userDomainMask,
                                                      appropriateFor: nil,
                                                      create: true) else { return nil }
        let dir = docs.appendingPathComponent("Lyrics", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    static func lyricsURL(for songURL: URL) -> URL? {
        // 1) 与音频同目录同名 .lrc
        let sibling = songURL.deletingPathExtension().appendingPathExtension("lrc")
        if FileManager.default.fileExists(atPath: sibling.path) { return sibling }
        // 2) Documents/Lyrics/<歌曲名>.lrc
        if let dir = folderURL() {
            let name = songURL.deletingPathExtension().lastPathComponent + ".lrc"
            let candidate = dir.appendingPathComponent(name)
            if FileManager.default.fileExists(atPath: candidate.path) { return candidate }
        }
        return nil
    }

    @discardableResult
    static func importFile(from sourceURL: URL, for song: Song) throws -> URL {
        guard let dir = folderURL() else {
            throw NSError(domain: "Lyrics", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "无法创建歌词目录"])
        }
        let dest = dir.appendingPathComponent(song.url.deletingPathExtension().lastPathComponent + ".lrc")
        if FileManager.default.fileExists(atPath: dest.path) {
            try FileManager.default.removeItem(at: dest)
        }
        let needStop = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if needStop { sourceURL.stopAccessingSecurityScopedResource() }
        }
        try FileManager.default.copyItem(at: sourceURL, to: dest)
        return dest
    }

    static func load(for song: Song) -> [LyricLine] {
        guard let url = lyricsURL(for: song.url),
              let data = try? Data(contentsOf: url) else { return [] }
        let text = decode(data)
        guard let text else { return [] }
        return parse(text)
    }

    private static func decode(_ data: Data) -> String? {
        if let s = String(data: data, encoding: .utf8) { return s }
        if let s = String(data: data, encoding: .utf16) { return s }
        // GB18030（兼容 GBK）兜底：0x0632 = kCFStringEncodingGB_18030_2000
        let gbEnc = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(0x0632)))
        if let s = String(data: data, encoding: gbEnc) { return s }
        return String(data: data, encoding: .isoLatin1)
    }

    /// 解析 LRC：一行可有多个时间戳；相同时间戳的相邻两行 = 原文 + 翻译
    static func parse(_ text: String) -> [LyricLine] {
        let pattern = "\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\]"
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }

        var entries: [(time: TimeInterval, text: String)] = []

        for rawLine in text.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            guard !line.isEmpty else { continue }
            let ns = line as NSString
            let matches = regex.matches(in: line, range: NSRange(location: 0, length: ns.length))
            guard let last = matches.last else { continue }
            let contentStart = last.range.location + last.range.length
            let content = ns.substring(from: contentStart).trimmingCharacters(in: .whitespaces)
            guard !content.isEmpty else { continue }

            for match in matches {
                let minutes = Double(ns.substring(with: match.range(at: 1))) ?? 0
                let seconds = Double(ns.substring(with: match.range(at: 2))) ?? 0
                var fraction = 0.0
                if match.range(at: 3).location != NSNotFound {
                    let fracString = ns.substring(with: match.range(at: 3))
                    if let value = Double(fracString) {
                        fraction = value / pow(10, Double(fracString.count))
                    }
                }
                entries.append((minutes * 60 + seconds + fraction, content))
            }
        }

        entries.sort { $0.time < $1.time }

        var result: [LyricLine] = []
        var index = 0
        var nextID = 0
        while index < entries.count {
            let current = entries[index]
            var translation: String?
            if index + 1 < entries.count, abs(entries[index + 1].time - current.time) < 0.02 {
                translation = entries[index + 1].text
                index += 2
            } else {
                index += 1
            }
            result.append(LyricLine(id: nextID, time: current.time, text: current.text, translation: translation))
            nextID += 1
        }
        return result
    }
}

struct LyricsView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @Environment(\.dismiss) private var dismiss

    @State private var lines: [LyricLine] = []
    @State private var showImporter = false
    @State private var message: String?
    @State private var dragOffset: CGFloat = 0

    private var song: Song? { player.currentSong }

    private var currentIndex: Int {
        guard !lines.isEmpty else { return 0 }
        var idx = 0
        for (i, line) in lines.enumerated() {
            if line.time <= player.currentTime + 0.15 {
                idx = i
            } else {
                break
            }
        }
        return idx
    }

    var body: some View {
        ZStack {
            background
            VStack(spacing: 0) {
                header
                content
            }
        }
        .offset(y: dragOffset)
        .gesture(
            DragGesture(minimumDistance: 10)
                .updating($dragOffset) { value, gestureState, _ in
                    gestureState = max(0, value.translation.height)
                }
                .onEnded { value in
                    let height = value.translation.height
                    let velocity = value.predictedEndTranslation.height - height
                    if height > 120 || velocity > 300 {
                        withAnimation(.interpolatingSpring(stiffness: 280, damping: 32)) {
                            dragOffset = UIScreen.main.bounds.height
                        }
                        dismiss()
                    } else {
                        withAnimation(.interpolatingSpring(stiffness: 350, damping: 36)) {
                            dragOffset = 0
                        }
                    }
                }
        )
        .onAppear(perform: reload)
        .onChange(of: player.currentSong?.url) { _ in reload() }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: lrcTypes,
                      allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first, let currentSong = self.song else { return }
                do {
                    try LyricsLoader.importFile(from: url, for: currentSong)
                    reload()
                    message = nil
                } catch {
                    message = "导入失败：\(error.localizedDescription)"
                }
            case .failure(let error):
                message = "选择文件失败：\(error.localizedDescription)"
            }
        }
    }

    private func reload() {
        if let song {
            lines = LyricsLoader.load(for: song)
        } else {
            lines = []
        }
    }

    private var lrcTypes: [UTType] {
        if let lrc = UTType(filenameExtension: "lrc") {
            return [lrc, .plainText]
        }
        return [.plainText]
    }

    // MARK: - 顶部

    private var header: some View {
        HStack(spacing: 12) {
            GlassIconButton(systemName: "chevron.down",
                            font: .system(size: 14, weight: .semibold),
                            size: 38,
                            action: { dismiss() })

            VStack(alignment: .leading, spacing: 2) {
                Text(song?.title ?? "未在播放")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(song?.artist ?? "未知艺人")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            GlassIconButton(systemName: "square.and.arrow.down",
                            font: .system(size: 15, weight: .semibold),
                            size: 38,
                            action: { showImporter = true })
        }
        .padding(.horizontal, 18)
        .padding(.top, 12)
        .padding(.bottom, 6)
    }

    // MARK: - 歌词主体

    @ViewBuilder
    private var content: some View {
        if song == nil {
            VStack {
                Spacer()
                Text("先在资料库里播放一首歌")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.75))
                Spacer()
            }
        } else if lines.isEmpty {
            VStack(spacing: 14) {
                Spacer()
                Text("还没有这首歌的歌词")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.75))
                Text("把 <歌名>.lrc 放到“文件”App 的 TunePlayer/Lyrics 里，\n或者点右上角按钮导入。")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.45))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                if let message {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }
                Spacer()
            }
        } else {
            lyricScroll
        }
    }

    private var lyricScroll: some View {
        ScrollViewReader { proxy in
            ScrollView(.vertical, showsIndicators: false) {
                LazyVStack(spacing: 6) {
                    Color.clear.frame(height: 120)
                    ForEach(lines.indices, id: \.self) { index in
                        lineView(lines[index], index: index)
                            .id(lines[index].id)
                    }
                    Color.clear.frame(height: 220)
                }
                .padding(.horizontal, 22)
            }
            .onAppear {
                if let first = lines[safe: currentIndex] {
                    proxy.scrollTo(first.id, anchor: .center)
                }
            }
            .onChange(of: currentIndex) { idx in
                guard lines.indices.contains(idx) else { return }
                withAnimation(.easeInOut(duration: 0.32)) {
                    proxy.scrollTo(lines[idx].id, anchor: .center)
                }
            }
            .mask(
                LinearGradient(
                    colors: [.clear, .black, .black, .black, .clear],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
        }
    }

    @ViewBuilder
    private func lineView(_ line: LyricLine, index: Int) -> some View {
        let isCurrent = index == currentIndex
        let isPast = index < currentIndex

        VStack(spacing: 5) {
            Text(line.text)
                .font(.system(size: isCurrent ? 27 : 23, weight: isCurrent ? .bold : .semibold))
                .foregroundStyle(lineStyle(isCurrent: isCurrent, isPast: isPast))
                .multilineTextAlignment(.center)
                .lineSpacing(2)
                .scaleEffect(isCurrent ? 1.0 : 0.98, anchor: .center)
                .animation(.spring(response: 0.35, dampingFraction: 0.8), value: currentIndex)

            if let translation = line.translation {
                Text(translation)
                    .font(.system(size: isCurrent ? 16 : 15, weight: .regular))
                    .foregroundStyle(.white.opacity(isCurrent ? 0.78 : (isPast ? 0.22 : 0.4)))
                    .multilineTextAlignment(.center)
                    .lineSpacing(2)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .opacity(isPast ? 0.45 : 1)
        .onTapGesture {
            player.seek(to: max(0, line.time))
        }
    }

    private func lineStyle(isCurrent: Bool, isPast: Bool) -> AnyShapeStyle {
        if isCurrent {
            return AnyShapeStyle(
                LinearGradient(
                    colors: [.white, .white.opacity(0.55)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
        }
        return AnyShapeStyle(Color.white.opacity(isPast ? 0.28 : 0.62))
    }

    private var background: some View {
        LinearGradient(
            colors: [
                Color(red: 0.16, green: 0.06, blue: 0.10),
                Color(red: 0.05, green: 0.02, blue: 0.04),
                .black
            ],
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea()
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
