// MetadataStore.swift
// 用户手动覆盖的元数据（专辑名等），持久化到 UserDefaults，
// 重启后依然有效。扫描资料库时优先应用这里的覆盖值。
import Foundation

enum MetadataStore {
    private static let key = "AlbumOverrides"
    private static var cache: [String: String]?

    private static func load() -> [String: String] {
        if let cached = cache { return cached }
        guard let data = UserDefaults.standard.data(forKey: key),
              let dict = try? JSONDecoder().decode([String: String].self, from: data) else {
            cache = [:]
            return [:]
        }
        cache = dict
        return dict
    }

    private static func save(_ dict: [String: String]) {
        cache = dict
        if let data = try? JSONEncoder().encode(dict) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    /// 获取某首歌的专辑名覆盖值（返回 nil 表示不覆盖，使用原始标签）
    static func album(for url: URL) -> String? {
        load()[url.path]
    }

    /// 设置（或清空）某首歌的专辑名覆盖值
    static func setAlbum(_ album: String?, for url: URL) {
        var dict = load()
        if let album = album, !album.isEmpty {
            dict[url.path] = album
        } else {
            dict.removeValue(forKey: url.path)
        }
        save(dict)
    }

    /// 重命名文件后迁移覆盖键（旧文件名 -> 新文件名）
    static func migrateAlbum(from oldURL: URL, to newURL: URL) {
        var dict = load()
        if let album = dict.removeValue(forKey: oldURL.path) {
            dict[newURL.path] = album
        }
        save(dict)
    }
}
