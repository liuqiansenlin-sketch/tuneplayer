// SongEditSheet.swift
// 编辑歌曲信息：改名 / 修改所属专辑 / 给专辑加封面
// 用 .sheet 呈现并自动聚焦输入框，保证键盘弹出（原来的 .alert 不带输入框，无法输入）
import SwiftUI
import UniformTypeIdentifiers

struct SongEditSheet: View {
    @EnvironmentObject var player: AudioPlayerModel
    @Environment(\.dismiss) private var dismiss

    let song: Song

    @State private var titleText: String
    @State private var albumText: String
    @State private var showAlbumArtworkImporter = false
    @State private var artworkHint: String?

    @FocusState private var focusedField: Field?

    private enum Field { case title, album }

    init(song: Song) {
        self.song = song
        _titleText = State(initialValue: song.title)
        _albumText = State(initialValue: song.album ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    LabeledContent("歌曲名称") {
                        TextField("歌曲名称", text: $titleText)
                            .multilineTextAlignment(.trailing)
                            .focused($focusedField, equals: .title)
                            .submitLabel(.next)
                            .onSubmit { focusedField = .album }
                    }
                    LabeledContent("所属专辑") {
                        TextField("输入专辑名称", text: $albumText)
                            .multilineTextAlignment(.trailing)
                            .focused($focusedField, equals: .album)
                            .submitLabel(.done)
                            .onSubmit { focusedField = nil }
                    }
                } header: {
                    Text("歌曲信息")
                } footer: {
                    Text("输入专辑名后，该专辑会自动出现在“资料库 → 专辑”里。")
                }

                Section {
                    Button {
                        focusedField = nil
                        showAlbumArtworkImporter = true
                    } label: {
                        Label("为专辑添加封面图片", systemImage: "photo.on.rectangle")
                    }
                    if let artworkHint {
                        Text(artworkHint)
                            .font(.footnote)
                            .foregroundStyle(.green)
                    }
                } header: {
                    Text("专辑封面")
                } footer: {
                    Text("选择的图片会作为“\(albumText.isEmpty ? (song.album ?? "该专辑") : albumText)”的专辑封面显示。")
                }
            }
            .navigationTitle("编辑歌曲")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { applyChanges() }
                        .fontWeight(.semibold)
                }
            }
            .fileImporter(isPresented: $showAlbumArtworkImporter,
                          allowedContentTypes: [.image],
                          allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    let album = albumText.trimmingCharacters(in: .whitespacesAndNewlines)
                    let target = album.isEmpty ? (song.album ?? "") : album
                    guard !target.isEmpty else {
                        artworkHint = "请先填写专辑名称"
                        return
                    }
                    player.addAlbumArtwork(target, from: url)
                    artworkHint = "专辑封面已更新"
                case .failure(let error):
                    print("选择封面失败：\(error)")
                }
            }
            .task {
                // 稍等一帧再聚焦，确保 sheet 动画结束后键盘能正常弹出
                try? await Task.sleep(nanoseconds: 350_000_000)
                focusedField = .title
            }
        }
    }

    private func applyChanges() {
        let newTitle = titleText.trimmingCharacters(in: .whitespacesAndNewlines)
        let newAlbum = albumText.trimmingCharacters(in: .whitespacesAndNewlines)

        // 先改专辑（不改文件名），再改名（改名会重建 Song 与 URL）
        if !newAlbum.isEmpty, newAlbum != song.album {
            player.setAlbumOverride(song, album: newAlbum)
        }
        if !newTitle.isEmpty, newTitle != song.title {
            player.renameSong(song, to: newTitle)
        }
        dismiss()
    }
}