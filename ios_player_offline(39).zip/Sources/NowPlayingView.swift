// NowPlayingView.swift
// Apple Music 风格全屏播放页：
//   模糊封面背景（缓慢呼吸）+ 压暗渐变 + 大封面卡片 + 标题/艺人 + 心形收藏
//   + 进度条（拖动精确 seek）+ shuffle / 上一首 / 播放暂停 / 下一首 / 循环
//   + 音量滑块 + 底部「歌词 / 即将播放」+ 顶部「⋯」更多菜单
//   页面内下滑 = 跟随手指返回
import SwiftUI
import UIKit
import UniformTypeIdentifiers
import MediaPlayer

struct NowPlayingView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme

    @State private var isDraggingSlider = false
    @State private var dragSeconds: TimeInterval = 0
    @State private var showQueue = false
    @State private var showLyrics = false
    @State private var showEditSheet = false
    @State private var showCoverImporter = false
    @State private var coverVersion = UUID()

    // 下滑返回状态：跟随手指移动的透明框
    @GestureState private var dragOffset: CGFloat = 0
    @State private var finalDragOffset: CGFloat = 0

    private var song: Song? { player.currentSong }

    private var isFavorite: Bool {
        if let url = song?.url { return favorites.isFavorite(url) }
        return false
    }

    private var totalSeconds: TimeInterval { max(player.duration, 1) }

    private var progressValue: Binding<TimeInterval> {
        Binding(
            get: { isDraggingSlider ? dragSeconds : player.currentTime },
            set: { dragSeconds = $0 }
        )
    }

    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea()

            // 封面放大强模糊 + 缓慢呼吸漂浮（Apple Music 歌词页风格背景动效）
            BlurredArtworkBackdrop(url: song?.url, seed: song?.url.path ?? "", album: song?.album, version: coverVersion)
                .ignoresSafeArea()

            // 压暗渐变，保证控件可读
            LinearGradient(
                colors: colorScheme == .dark
                    ? [Color.black.opacity(0.30), Color.black.opacity(0.62)]
                    : [Color.black.opacity(0.12), Color.black.opacity(0.38)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                topBar
                Spacer(minLength: 2)
                artwork
                songInfo
                progress
                controls
                volumeSlider
                bottomRow
            }
            .padding(.horizontal, 24)
            // 下滑时整个内容跟随手指下移，并向后收缩（模仿 Apple Music 后退效果）
            .offset(y: finalDragOffset + dragOffset)
            .scaleEffect(max(0.92, 1.0 - ((finalDragOffset + dragOffset) / 2500)))
        }
        .appearZoom()
        .sheet(isPresented: $showQueue) {
            QueueView()
                .environmentObject(player)
        }
        .fullScreenCover(isPresented: $showLyrics) {
            LyricsView()
                .environmentObject(player)
        }
        .sheet(isPresented: $showEditSheet) {
            if let song {
                SongEditSheet(song: song)
                    .environmentObject(player)
            }
        }
        .fileImporter(isPresented: $showCoverImporter,
                      allowedContentTypes: [.image, .movie],
                      allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first, let current = self.song else { return }
                do {
                    try CoverStore.importCover(from: url, for: current)
                    coverVersion = UUID()
                } catch {
                    print("添加封面失败：\(error.localizedDescription)")
                }
            case .failure(let error):
                print("选择文件失败：\(error.localizedDescription)")
            }
        }
        // 页面内任意位置下滑返回（跟随手指，不松手不返回，松手有过渡动画）
        .gesture(
            DragGesture(minimumDistance: 10)
                .updating($dragOffset) { value, gestureState, _ in
                    gestureState = max(0, value.translation.height)
                }
                .onEnded { value in
                    let height = value.translation.height
                    let velocity = value.predictedEndTranslation.height - height
                    if height > 120 || velocity > 300 {
                        withAnimation(.interpolatingSpring(stiffness: 280, damping: 32)) {
                            finalDragOffset = UIScreen.main.bounds.height
                            dismiss()
                        }
                    } else {
                        withAnimation(.interpolatingSpring(stiffness: 350, damping: 36)) {
                            finalDragOffset = 0
                        }
                    }
                }
        )
    }

    // MARK: - 顶部栏（收起 / 正在播放 / 更多菜单）

    private var topBar: some View {
        HStack {
            Button {
                Haptics.light()
                dismiss()
            } label: {
                Image(systemName: "chevron.down")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("收起播放页")

            VStack(spacing: 2) {
                Text("正在播放")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                Text(song?.album ?? "资料库")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            Menu {
                Button {
                    if let song { favorites.toggleFavorite(song.url) }
                } label: {
                    Label(isFavorite ? "取消收藏" : "收藏", systemImage: isFavorite ? "heart.slash" : "heart")
                }
                Button {
                    showCoverImporter = true
                } label: {
                    Label("添加封面", systemImage: "photo.on.rectangle")
                }
                if song != nil {
                    Button {
                        showEditSheet = true
                    } label: {
                        Label("编辑信息", systemImage: "pencil")
                    }
                }
                Button {
                    showQueue = true
                } label: {
                    Label("即将播放", systemImage: "list.bullet")
                }
                Button {
                    showLyrics = true
                } label: {
                    Label("歌词", systemImage: "quote.bubble")
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("更多操作")
        }
    }

    // MARK: - 大封面（播放中呼吸缩放）

    @ViewBuilder
    private var artwork: some View {
        if let song {
            ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 16, album: song.album)
                .id(coverVersion)
                .frame(maxWidth: .infinity)
                .frame(height: 300)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .shadow(color: .black.opacity(0.35), radius: 20, y: 10)
                .breathing(player.isPlaying)
        } else {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.glassHighlight(0.10))
                .frame(maxWidth: .infinity)
                .frame(height: 300)
                .overlay(
                    Image(systemName: "music.note")
                        .font(.system(size: 40, weight: .semibold))
                        .foregroundStyle(.secondary)
                )
        }
    }

    // MARK: - 标题 + 艺人 + 心形

    private var songInfo: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(song?.title ?? "未在播放")
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(song?.artist ?? "未知艺人")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            Button {
                Haptics.medium()
                if let song { favorites.toggleFavorite(song.url) }
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(isFavorite ? Color.red : Color.primary)
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel(isFavorite ? "取消收藏" : "收藏")
        }
    }

    // MARK: - 进度条（拖动精确 seek）

    private var progress: some View {
        VStack(spacing: 6) {
            Slider(value: progressValue, in: 0...totalSeconds) { editing in
                isDraggingSlider = editing
                if !editing { player.seek(to: dragSeconds) }
            }
            .tint(.red)

            HStack {
                Text(formatTime(isDraggingSlider ? dragSeconds : player.currentTime))
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(.secondary)
                Spacer(minLength: 0)
                Text(formatTime(totalSeconds))
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - 控制键（随机 / 上一首 / 播放暂停 / 下一首 / 循环）

    private var controls: some View {
        HStack(spacing: 28) {
            Button {
                Haptics.selection()
                player.toggleShuffle()
            } label: {
                Image(systemName: "shuffle")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(player.isShuffle ? Color.red : Color.primary)
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("随机播放")

            Button {
                Haptics.light()
                player.playPrevious()
            } label: {
                Image(systemName: "backward.end.fill")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("上一首")

            Button {
                Haptics.medium()
                player.togglePlayPause()
            } label: {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 30, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 68, height: 68)
                    .background(Color.red)
                    .clipShape(Circle())
            }
            .buttonStyle(PressableButtonStyle(scale: 0.92))
            .accessibilityLabel(player.isPlaying ? "暂停" : "播放")

            Button {
                Haptics.light()
                player.playNext()
            } label: {
                Image(systemName: "forward.end.fill")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("下一首")

            Button {
                Haptics.selection()
                player.toggleRepeat()
            } label: {
                Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(player.repeatMode == .none ? Color.primary : Color.red)
                    .frame(width: 40, height: 40)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("循环模式")
        }
    }

    // MARK: - 音量滑块（MPVolumeView，系统原生音量条）

    private var volumeSlider: some View {
        VolumeSliderView()
            .frame(height: 44)
            .padding(.horizontal, 4)
    }

    // MARK: - 底部：歌词 / 即将播放

    private var bottomRow: some View {
        HStack {
            Button {
                Haptics.light()
                showLyrics = true
            } label: {
                Image(systemName: "quote.bubble")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("歌词")

            Spacer(minLength: 0)

            Button {
                Haptics.light()
                showQueue = true
            } label: {
                Image(systemName: "list.bullet")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(PressableButtonStyle(scale: 0.88))
            .accessibilityLabel("即将播放")
        }
    }

    // MARK: - 工具

    private func formatTime(_ t: TimeInterval) -> String {
        let total = Int(max(0, t).rounded())
        let m = total / 60
        let s = total % 60
        return String(format: "%d:%02d", m, s)
    }
}

// MARK: - 系统音量滑块（MPVolumeView 包装）

private struct VolumeSliderView: UIViewRepresentable {
    func makeUIView(context: Context) -> MPVolumeView {
        let view = MPVolumeView(frame: .zero)
        view.showsVolumeSlider = true
        return view
    }

    func updateUIView(_ uiView: MPVolumeView, context: Context) {}
}
