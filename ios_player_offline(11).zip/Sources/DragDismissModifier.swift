import SwiftUI

/// 下滑返回上一级：整个内容跟随手指下移，松手有弹簧过渡。
/// 搜索页不使用本 modifier（搜索页用速度检测快滑返回）。
struct DragDismissModifier: ViewModifier {
    @Environment(\.dismiss) private var dismiss
    @State private var offset: CGFloat = 0

    func body(content: Content) -> some View {
        content
            .offset(y: offset)
            .simultaneousGesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { value in
                        let height = value.translation.height
                        if height > 0 { offset = height }
                    }
                    .onEnded { value in
                        let height = value.translation.height
                        let velocity = value.predictedEndTranslation.height - height
                        if height > 120 || velocity > 300 {
                            withAnimation(.interpolatingSpring(stiffness: 280, damping: 32)) {
                                offset = UIScreen.main.bounds.height
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                                dismiss()
                            }
                        } else {
                            withAnimation(.interpolatingSpring(stiffness: 350, damping: 36)) {
                                offset = 0
                            }
                        }
                    }
            )
    }
}

extension View {
    func dragDismiss(threshold: CGFloat = 120) -> some View {
        modifier(DragDismissModifier())
    }
}