// LibraryView.swift
// 资料库：Apple Music「Library」风格 —— 大标题 + 分类入口（歌曲/专辑/艺人/已收藏）+ 全部歌曲
import SwiftUI
import UniformTypeIdentifiers

// MARK: - 分类

enum LibraryCategory: String, CaseIterable, Identifiable {
    case songs, albums, artists, favorites

    var id: String { rawValue }

    var title: String {
        switch self {
        case .songs: return "歌曲"
        case .albums: return "专辑"
        case .artists: return "艺人"
        case .favorites: return "已收藏"
        }
    }

    var icon: String {
        switch self {
        case .songs: return "music.note"
        case .albums: return "square.stack"
        case .artists: return "person.2"
        case .favorites: return "heart.fill"
        }
    }

    var color: Color {
        switch self {
        case .songs: return .red
        case .albums: return .blue
        case .artists: return .orange
        case .favorites: return .pink
        }
    }
}

// MARK: - 资料库首页

struct LibraryView: View {
    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore
    @State private var showImporter = false

    var body: some View {
        NavigationStack {
            Group {
                if player.songs.isEmpty {
                    emptyState
                } else {
                    libraryList
                }
            }
            .navigationTitle("资料库")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    // 只保留一个干净的“+”，没有底色、没有外框
                    Button { showImporter = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundStyle(.red)
                            .frame(width: 44, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("导入音乐")
                }
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [.audio],
                          allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls):
                    Task { await player.importMusic(from: urls) }
                case .failure(let error):
                    print("导入失败：\(error)")
                }
            }
            .refreshable { await player.loadLibrary() }
            .background(Color.black)
        }
        .task { await player.loadLibrary() }
    }

    private var libraryList: some View {
        List {
            Section {
                ForEach(LibraryCategory.allCases) { category in
                    NavigationLink {
                        LibraryCategoryView(category: category)
                            .environmentObject(player)
                            .environmentObject(favorites)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: category.icon)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(.white)
                                .frame(width: 30, height: 30)
                                .background(category.color,
                                            in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            Text(category.title)
                                .font(.body.weight(.medium))
                                .foregroundStyle(.white)
                            Spacer(minLength: 0)
                            Text(countText(for: category))
                                .font(.subheadline)
                                .foregroundStyle(.gray)
                        }
                        .padding(.vertical, 3)
                    }
                    .listRowBackground(Color.black)
                }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        // 给底部迷你播放条 + 三键栏留出空间，列表最后一行不被遮住
        .safeAreaInset(edge: .bottom) {
            Color.clear.frame(height: 150)
        }
    }

    private func countText(for category: LibraryCategory) -> String {
        switch category {
        case .songs:
            return "\(player.songs.count)"
        case .albums:
            let albums = Set(player.songs.compactMap { $0.album }.filter { !$0.isEmpty })
            return "\(albums.count)"
        case .artists:
            let artists = Set(player.songs.compactMap { $0.artist }.filter { !$0.isEmpty })
            return "\(artists.count)"
        case .favorites:
            let count = player.songs.filter { favorites.isFavorite($0.url) }.count
            return "\(count)"
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text("还没有歌曲")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text("点右上角 “+” 从文件导入音乐，\n或通过“文件”App 分享到 TunePlayer")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
            Button("导入音乐") { showImporter = true }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.top, 6)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - 歌曲行（列表与分类页共用）

struct SongRowView: View {
    let song: Song
    let songs: [Song]

    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    var body: some View {
        HStack(spacing: 8) {
            Button { player.playSong(song, in: songs) } label: {
                HStack(spacing: 12) {
                    ArtworkView(url: song.url, seed: song.url.path, cornerRadius: 8)
                        .frame(width: 52, height: 52)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(song.title)
                            .font(.body.weight(.semibold))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text([song.artist, song.album].compactMap { $0 }.joined(separator: " · "))
                            .font(.subheadline)
                            .foregroundStyle(.gray)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .contextMenu {
                Button {
                    player.insertSongAfterCurrent(song)
                } label: {
                    Label("插播", systemImage: "play.circle")
                }
                Button {
                    player.addToQueue(song)
                } label: {
                    Label("加入队列", systemImage: "plus.circle")
                }
                Button(role: .destructive) {
                    player.deleteSong(song)
                } label: {
                    Label("删除", systemImage: "trash")
                }
            }

            Button {
                favorites.toggleFavorite(song.url)
            } label: {
                Image(systemName: favorites.isFavorite(song.url) ? "heart.fill" : "heart")
                    .font(.system(size: 18))
                    .foregroundStyle(.red)
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(favorites.isFavorite(song.url) ? "取消收藏" : "收藏")
        }
    }
}

// MARK: - 分类详情页

private struct SongGroup: Identifiable {
    let id: String
    let songs: [Song]
}

struct LibraryCategoryView: View {
    let category: LibraryCategory

    @EnvironmentObject var player: AudioPlayerModel
    @EnvironmentObject var favorites: FavoritesStore

    private var filteredSongs: [Song] {
        category == .favorites
            ? player.songs.filter { favorites.isFavorite($0.url) }
            : player.songs
    }

    private var groups: [SongGroup] {
        let keyed: [String: [Song]]
        switch category {
        case .albums:
            keyed = Dictionary(grouping: filteredSongs) { song in
                let album = song.album?.trimmingCharacters(in: .whitespaces) ?? ""
                return album.isEmpty ? "未知专辑" : album
            }
        case .artists:
            keyed = Dictionary(grouping: filteredSongs) { song in
                let artist = song.artist?.trimmingCharacters(in: .whitespaces) ?? ""
                return artist.isEmpty ? "未知艺人" : artist
            }
        default:
            return []
        }
        return keyed.keys.sorted().map { SongGroup(id: $0, songs: keyed[$0] ?? []) }
    }

    var body: some View {
        Group {
            if filteredSongs.isEmpty {
                emptyState
            } else {
                List {
                    if category == .albums || category == .artists {
                        ForEach(groups) { group in
                            Section {
                                ForEach(group.songs) { song in
                                    SongRowView(song: song, songs: group.songs)
                                        .listRowBackground(Color.black)
                                }
                            } header: {
                                Text(group.id)
                                    .font(.footnote.weight(.semibold))
                                    .foregroundStyle(.gray)
                                    .textCase(nil)
                            }
                        }
                    } else {
                        ForEach(filteredSongs) { song in
                            SongRowView(song: song, songs: filteredSongs)
                                .listRowBackground(Color.black)
                        }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
            }
        }
        .navigationTitle(category.title)
        .navigationBarTitleDisplayMode(.inline)
        .background(Color.black.ignoresSafeArea())
        .dragDismiss(threshold: 120)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: category.icon)
                .font(.system(size: 52))
                .foregroundStyle(.gray)
            Text(category == .favorites ? "还没有收藏的歌" : "这里还没有内容")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text(category == .favorites ? "点列表行右侧的 ♡ 给歌曲加收藏" : "先去导入一些歌曲吧")
                .font(.subheadline)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
