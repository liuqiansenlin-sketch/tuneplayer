// CoverStore.swift
// 歌曲自定义封面：用户可为某首歌单独添加一张照片或一段视频作为封面
// 存放：Documents/Covers/<歌曲文件名>.<jpg|png|heic|mp4|mov>
import Foundation
import UIKit

enum CoverStore {
    static let folderName = "Covers"
    private static let imageExtensions = ["jpg", "jpeg", "png", "heic", "heif"]
    private static let videoExtensions = ["mp4", "mov", "m4v"]

    static func folderURL() -> URL? {
        guard let docs = try? FileManager.default.url(for: .documentDirectory,
                                                      in: .userDomainMask,
                                                      appropriateFor: nil,
                                                      create: true) else { return nil }
        let dir = docs.appendingPathComponent(folderName, isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    static func baseName(for song: Song) -> String {
        song.url.deletingPathExtension().lastPathComponent
    }

    static func imageURL(for song: Song) -> URL? {
        find(song, extensions: imageExtensions)
    }

    static func videoURL(for song: Song) -> URL? {
        find(song, extensions: videoExtensions)
    }

    private static func find(_ song: Song, extensions: [String]) -> URL? {
        guard let dir = folderURL() else { return nil }
        let base = baseName(for: song)
        for ext in extensions {
            let candidate = dir.appendingPathComponent(base + "." + ext)
            if FileManager.default.fileExists(atPath: candidate.path) { return candidate }
        }
        return nil
    }

    /// 复制用户选择的照片/视频作为这首歌的封面（会替换旧封面）
    @discardableResult
    static func importCover(from sourceURL: URL, for song: Song) throws -> URL {
        guard let dir = folderURL() else {
            throw NSError(domain: "CoverStore", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "无法创建封面目录"])
        }
        let ext = sourceURL.pathExtension.lowercased()
        let dest = dir.appendingPathComponent(baseName(for: song) + "." + ext)
        removeCover(for: song)
        let needStop = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if needStop { sourceURL.stopAccessingSecurityScopedResource() }
        }
        try FileManager.default.copyItem(at: sourceURL, to: dest)
        return dest
    }

    static func removeCover(for song: Song) {
        if let url = imageURL(for: song) { try? FileManager.default.removeItem(at: url) }
        if let url = videoURL(for: song) { try? FileManager.default.removeItem(at: url) }
    }
}
